# v1.1.8 PauseFix LiteUI

- Baseline: v1.1.7 SelfEventFix behavior.
- USER_PAUSE is a hard state: watchdog skips it, pending scan runnable is cancelled, and no new D1-D7 gesture can be scheduled while paused.
- Resume clears stale settle/self-click state and resets the watchdog clock before polling restarts.
- Manual date-row protection remains 3500 ms.
- Self-event grace remains 800 ms.
- Empty-page target cadence is approximately 0.6-1.0 second per date; ambiguous pages get a short confirmation window rather than rapid repeated taps.
- Lite UI removes amount, miles and $/mi controls/displays without removing underlying offer-page recognition signals.
- Offer sound, vibration, notification, overlay and freeze-on-offer behavior retained.
