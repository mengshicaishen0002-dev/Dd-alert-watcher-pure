# v1.1.9 Stability+Speed

Audit/fix release based on v1.1.8 PauseFix LiteUI.

## Definite bug fixes
- Fixed duplicate-offer suppression path that could return from `scanTick()` without scheduling the next scan after the user resumed, later producing `WATCHDOG_STALL`.
- Watchdog now resets its baseline while Dasher/Offers is not the active context, avoiding false stalls after the user temporarily leaves the Offers page.
- Removed the overly broad empty-page token `not available`, which could classify unrelated UI text as an empty Offers page.

## Reliability
- Offer evidence prefers Claim/View Delivery controls, then money+delivery evidence, then structural delivery-card evidence.
- Added `view delivery`, `deliver by`, and `pickup by` evidence.
- Kept hard USER_PAUSE behavior, pending-scan cancellation, stale callback state gates, resume watchdog reset, and 3500ms manual date-row yield.
- Core behavior remains alert-only; no automatic Claim.

## Speed
- Debounced redundant Accessibility Compose event snapshots to reduce repeated full-tree traversal.
- Empty-page first settle: 650ms -> 600ms.
- Recheck: 160ms -> 140ms.
- Max settle: 1000ms -> 900ms.
- Round pause: 450ms -> 300ms.
- State confirmation and DATE_EMPTY_FAST_SETTLED logic retained.

## UI
- LiteUI retained: no amount, miles, or $/mi controls.
