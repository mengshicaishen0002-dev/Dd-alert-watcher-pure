# DD Alert Watcher v1.1.7.1 Pure Alert

Baseline: v1.1.7 SelfEventFix behavior.

- Keeps the v1.1.7 D1–D7 polling flow and overlay controls.
- Keeps the v1.1.7 manual date-row handoff: about 3.5 seconds, then automatic scanning resumes.
- USER_PAUSE is a hard pause: pending polling is cancelled and watchdog is completely inert.
- A short 1.2 s guard after Pause prevents an adjacent/duplicate touch from being interpreted as Stop; the overlay UI itself is unchanged.
- Watchdog also ignores the intentional manual-yield window and a healthy date-settle window.
- Pure Alert: any Offer on any enabled D1–D7 date immediately triggers sound/vibration/notification and freezes scanning.
- No automatic Claim and no opening offer details to calculate miles.
- Amount / miles / $/mi inputs remain removed.
- Only a light timing optimization: ~620 ms first settle, 140 ms recheck, 1050 ms max settle, 400 ms round pause. Target remains roughly 5–6 seconds per full 7-day round on a normally responsive page.
- Offer detection / notification path otherwise remains unchanged.


## Corrected v1.1.7.1 baseline rule
- Manual date intervention follows the stable v1.1.7 SelfEventFix behavior: manual D1–D7 click yields for ~3.5 s, then polling resumes.
- No new physical-touch heuristic was added to manual-date detection.
- Overlay Pause / Continue / Stop behavior is not rewritten.
- USER_PAUSE makes watchdog inert because watchdog only operates in RUNNING.
- Manual 3.5 s yield is also excluded from watchdog stall handling.
- D1–D7 polling remains the same structure, with only a light timing change (600 ms first settle, 140 ms recheck, 900 ms max settle, 300 ms round pause), targeting about 5–6 s/round on the tested page.
- Offer alert path is unchanged: any detected Offer triggers sound/vibration/notification and freezes scanning; no detail opening and no miles calculation.
- Amount / miles / $/mi inputs remain removed.


## Handled Offer resume fix
- When an Offer freezes scanning, manually handle it in DoorDash and press Continue.
- Continue marks that exact Offer fingerprint as handled.
- The same visible/stale card is ignored instead of freezing the scanner again.
- D1-D7 polling continues normally.
- If that Offer disappears or the fingerprint changes, suppression is released.
- A genuinely different/new Offer can alert and freeze normally.
- v1.1.7 manual-intervention, pause/resume, 3.5 s yield, overlay, and alert chain are otherwise unchanged.


## v1.1.7.2 Manual Yield Fix
- Manual D1-D7 click is processed before the transient Offers-page snapshot check.
- A valid manual date-row click immediately cancels pending polling and starts the original ~3.5 s handoff.
- In-flight automatic gesture callbacks are invalidated, so they cannot restart scanning during the manual handoff.
- Watchdog baseline resets on manual handoff and remains inert during the hold.
- Offer handled-ignore behavior from v1.1.7.1 is preserved.
- No change to Claim behavior; alerts still freeze and require manual action.


## v1.1.7.3 DoorDash Error Layer Fix
- Detects DoorDash's "Something went wrong / An unexpected error occurred / Retry" sheet.
- Immediately freezes D1-D7 polling and invalidates pending automatic gesture callbacks.
- Never clicks Retry automatically.
- Sends an abnormal-state alert and shows `DoorDash 错误·已暂停` in the overlay.
- Watchdog does not soft-restart through the error sheet.
- Pressing Continue while the error sheet is still visible is blocked.
- After the user manually clears/retries the DoorDash error, pressing Continue resumes normal polling.
- v1.1.7 manual yield and v1.1.7.1 handled-offer suppression remain preserved.


## v1.1.7.4 Offers Tab Guard
- D1-D7 automatic date switching is allowed only when the DoorDash Schedule **Offers** tab is actually active.
- Seeing the word `Offers` somewhere in the accessibility tree is no longer enough.
- Accessibility selected/checked state is preferred for Offers / Dash / My schedule.
- Fallback detection uses only Offers-specific content such as claim text, empty-offer text, or `$xx offer`.
- When Dash or My schedule is active, polling becomes idle and logs `NOT_OFFERS_TAB_SCAN_BLOCKED` once.
- No automatic D1-D7 gestures are sent outside Offers.
- Manual date-row yield is also ignored outside the active Offers tab.
- v1.1.7 manual handoff, handled-offer suppression, and DoorDash error-layer pause are preserved.


## v1.1.7.5 Speed Tune
- USER_STOP overlay semantics are unchanged; USER_STOP is treated as a real manual stop.
- Only scanner timing was lightly optimized:
  - first settle: 600 ms -> 500 ms
  - settle recheck: 140 ms -> 110 ms
  - max settle: 900 ms -> 760 ms
  - round pause: 300 ms -> 220 ms
  - gesture-cancel retry: 350 ms -> 260 ms
- Target: roughly 5–6 seconds per D1–D7 round on the same page, without aggressive rapid tapping.
- v1.1.7 manual 3.5 s handoff is unchanged.
- Offers-tab guard, handled-offer ignore, DoorDash error-layer pause, watchdog behavior, overlay, Pause/Resume/Stop are unchanged.
