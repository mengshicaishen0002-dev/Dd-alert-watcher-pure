package com.ddalertwatcher.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class OfferAccessibilityService extends AccessibilityService {
    private static volatile OfferAccessibilityService INSTANCE;
    private static final String DASHER_PACKAGE = "com.doordash.driverapp";
    private static final String PREFS = MainActivity.PREFS;
    private static final String CHANNEL_OFFER = "offer_alert";
    private static final String CHANNEL_ERROR = "monitor_error";

    private static final long MANUAL_HOLD_MS = 3500L;
    private static final long SELF_EVENT_WINDOW_MS = 800L;
    private static final long WATCHDOG_STALL_MS = 18_000L;
    private static final long WATCHDOG_TICK_MS = 2_000L;
    private static final long EMPTY_FAST_MS = 650L;
    private static final long SLOW_RECHECK_MS = 650L;
    private static final long MAX_SETTLE_MS = 1_900L;

    private enum State {
        RUNNING,
        WAITING_OFFERS_PAGE,
        USER_PAUSED,
        SCHEDULE_WAIT,
        SCHEDULE_ENDED,
        OFFER_FROZEN,
        ERROR_PAUSED,
        STOPPED
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private State state = State.STOPPED;
    private WindowManager wm;
    private View overlay;
    private TextView overlayStatus;
    private WindowManager.LayoutParams overlayLp;

    private int currentDateIndex = 0;
    private int currentRoundScanned = 0;
    private long expectedAutoDateEventUntil = 0L;
    private int expectedAutoDateIndex = -1;
    private long selfGestureTouchSuppressUntil = 0L;
    private long manualHoldUntil = 0L;
    private long lastProgressAt = 0L;
    private long scanStartedAt = 0L;
    private long settleDeadlineAt = 0L;
    private int settleStage = 0;
    private boolean scanScheduled = false;
    private final Runnable scanRunnable = new Runnable() {
        @Override public void run() {
            scanScheduled = false;
            scanTick();
        }
    };
    private boolean dasherForeground = false;
    private boolean onOffersPage = false;
    private boolean waitingPageLogged = false;
    private boolean errorNotified = false;
    private boolean scheduleDueNotified = false;
    private long lastOfferAlertAt = 0L;
    private String lastOfferFingerprint = "";

    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            try {
                refreshOverlayIfNeeded();
                processExternalCommand();
                evaluateSchedule();
                if (state == State.RUNNING && isScheduleAllowedNow() && dasherForeground && onOffersPage) {
                    long now = System.currentTimeMillis();
                    // v1.1.7 behavior: genuine user interaction gets a short yield window.
                    // The watchdog must never convert that yield (or USER_PAUSE) into a stall/stop.
                    if (now < manualHoldUntil) {
                        return;
                    }
                    if (lastProgressAt > 0 && now - lastProgressAt >= WATCHDOG_STALL_MS) {
                        log("WATCHDOG_STALL idleMs=" + (now - lastProgressAt));
                        increment("stat_stall");
                        alertError("监控停滞", "18秒未检测到有效扫描进展，已软重启扫描器");
                        softRestartScanner();
                    }
                }
            } catch (Throwable t) {
                log("WATCHDOG_ERROR " + t.getClass().getSimpleName());
                increment("stat_error");
                alertError("监控异常", "Watchdog 发生异常，请检查 DD Alert Watcher");
            } finally {
                handler.postDelayed(this, WATCHDOG_TICK_MS);
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannels();
        ensureOverlay();
        lastProgressAt = System.currentTimeMillis();
        prefs.edit().putString("service_state", "已连接 · Pure Alert v1.1.7.2").apply();
        log("SERVICE_CONNECTED pure-alert-v1.1.7.2");
        state = isScheduleAllowedNow() ? State.RUNNING : State.SCHEDULE_WAIT;
        updateOverlay();
        handler.removeCallbacks(watchdog);
        handler.post(watchdog);
        scheduleScan(250L);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence pkg = event.getPackageName();
        dasherForeground = pkg != null && DASHER_PACKAGE.contentEquals(pkg);

        if (!dasherForeground) {
            leaveOffersPage("APP_BACKGROUND");
            updateOverlay();
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        Snapshot snap = Snapshot.from(root);
        boolean strictOffers = snap.looksLikeOffersPageStrict(
                getResources().getDisplayMetrics().widthPixels,
                getResources().getDisplayMetrics().heightPixels);

        if (!strictOffers) {
            leaveOffersPage("PAGE_NOT_OFFERS");
            updateOverlay();
            return;
        }

        enterOffersPageIfNeeded();

        if (snap.hasErrorLayer()) {
            if (state != State.ERROR_PAUSED) {
                state = State.ERROR_PAUSED;
                cancelPendingScan();
                log("DOORDASH_ERROR retry-layer");
                increment("stat_error");
                alertError("DoorDash 页面异常", "检测到 Something went wrong / Retry。已暂停，请人工处理后点继续监控。");
                errorNotified = true;
                updateOverlay();
            }
            return;
        } else if (errorNotified) {
            errorNotified = false;
        }

        if (state == State.RUNNING) {
            if (detectAndAlertOffer(snap)) return;

            int type = event.getEventType();
            long now = System.currentTimeMillis();
            if (type == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START && now > selfGestureTouchSuppressUntil) {
                beginManualHold("TOUCH");
            } else {
                handleManualDateEvent(event, snap);
            }
        }

        if (state == State.SCHEDULE_WAIT && isScheduleAllowedNow()) {
            state = State.RUNNING;
            scheduleDueNotified = false;
            resetWatchdogClock();
            log("SCHEDULE_RESUME_ON_OFFERS");
            scheduleScan(100L);
        }
        updateOverlay();
    }

    @Override
    public void onInterrupt() {
        log("SERVICE_INTERRUPTED");
    }

    @Override
    public void onDestroy() {
        cancelPendingScan();
        handler.removeCallbacks(watchdog);
        removeOverlay();
        if (prefs != null) prefs.edit().putString("service_state", "服务已停止").apply();
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }

    private void beginManualHold(String reason) {
        if (state != State.RUNNING || !onOffersPage) return;
        long now = System.currentTimeMillis();
        manualHoldUntil = Math.max(manualHoldUntil, now + MANUAL_HOLD_MS);
        cancelPendingScan();
        // A real user touch takes priority over an in-flight auto date switch.
        settleDeadlineAt = 0L;
        settleStage = 0;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        resetWatchdogClock();
        log("USER_INTERACTION_HOLD reason=" + reason + " yield=" + MANUAL_HOLD_MS + "ms");
        scheduleScan(manualHoldUntil - now + 50L);
        updateOverlay();
    }

    private void handleManualDateEvent(AccessibilityEvent event, Snapshot snap) {
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_VIEW_CLICKED &&
                type != AccessibilityEvent.TYPE_VIEW_SELECTED) return;

        AccessibilityNodeInfo src = event.getSource();
        int eventDate = dateIndexFromNode(src);
        long now = System.currentTimeMillis();

        // Ignore the accessibility event caused by our own injected date tap.
        if (eventDate >= 0 && expectedAutoDateIndex == eventDate && now <= expectedAutoDateEventUntil) {
            return;
        }

        // Any genuine click/selection on the date row is human priority, including
        // clicking the same date that the scanner had just visited.
        if (eventDate >= 0 || (src != null && looksLikeDateRowNode(src))) {
            beginManualHold(eventDate >= 0 ? "DATE_D" + (eventDate + 1) : "DATE_ROW");
        }
    }

    private void leaveOffersPage(String reason) {
        onOffersPage = false;
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        settleStage = 0;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        selfGestureTouchSuppressUntil = 0L;

        if (state == State.RUNNING || state == State.WAITING_OFFERS_PAGE) {
            cancelPendingScan();
            state = State.WAITING_OFFERS_PAGE;
            if (!waitingPageLogged) {
                log("WAITING_OFFERS_PAGE reason=" + reason);
                waitingPageLogged = true;
            }
        }
    }

    private void enterOffersPageIfNeeded() {
        boolean wasOnOffers = onOffersPage;
        onOffersPage = true;
        if (!wasOnOffers || state == State.WAITING_OFFERS_PAGE) {
            waitingPageLogged = false;
            if (state == State.WAITING_OFFERS_PAGE) {
                if (isScheduleAllowedNow()) {
                    state = State.RUNNING;
                    resetWatchdogClock();
                    log("OFFERS_PAGE_RESUME");
                    scheduleScan(120L);
                } else {
                    state = State.SCHEDULE_WAIT;
                    log("OFFERS_PAGE_WAIT_SCHEDULE");
                }
            }
        }
    }

    private boolean detectAndAlertOffer(Snapshot snap) {
        if (snap.emptyPage || snap.loadingLike || snap.errorLayer) return false;
        if (!snap.offerCandidate) return false;

        String fingerprint = snap.fingerprint();
        long now = System.currentTimeMillis();
        if (fingerprint.equals(lastOfferFingerprint) && now - lastOfferAlertAt < 60_000L) return true;

        lastOfferFingerprint = fingerprint;
        lastOfferAlertAt = now;
        state = State.OFFER_FROZEN;
        cancelPendingScan();
        increment("stat_offer");
        log("OFFER_CANDIDATE date=D" + (currentDateIndex + 1));
        log("OFFER_CONFIRMED source=" + snap.offerEvidence);
        log("ALERT_SENT");
        log("AUTO_SCAN_FROZEN reason=offer");
        sendOfferAlert("发现 Offer！", "请立即查看 Dasher。Pure Alert 已冻结扫描，处理后手动点继续监控。");
        updateOverlay();
        return true;
    }

    private void scheduleScan(long delayMs) {
        if (scanScheduled) return;
        scanScheduled = true;
        handler.postDelayed(scanRunnable, Math.max(0L, delayMs));
    }

    private void cancelPendingScan() {
        handler.removeCallbacks(scanRunnable);
        scanScheduled = false;
    }

    private void processExternalCommand() {
        if (prefs == null) return;
        String cmd = prefs.getString("command", "");
        if (cmd == null || cmd.isEmpty()) return;
        prefs.edit().remove("command").apply();
        if ("pause".equals(cmd)) pauseByUser();
        else if ("resume".equals(cmd)) resumeByUser();
        else if ("reload".equals(cmd)) {
            if (overlay != null) overlay.setKeepScreenOn(prefs.getBoolean("keep_awake", true));
            updateOverlay();
        }
    }

    private void scanTick() {
        long now = System.currentTimeMillis();
        evaluateSchedule();
        if (state != State.RUNNING) return;
        if (!isScheduleAllowedNow()) return;
        if (!dasherForeground || !onOffersPage) {
            state = State.WAITING_OFFERS_PAGE;
            cancelPendingScan();
            updateOverlay();
            return;
        }
        if (now < manualHoldUntil) {
            scheduleScan(manualHoldUntil - now + 50L);
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        Snapshot snap = Snapshot.from(root);
        if (!snap.looksLikeOffersPageStrict(
                getResources().getDisplayMetrics().widthPixels,
                getResources().getDisplayMetrics().heightPixels)) {
            leaveOffersPage("SCAN_GATE");
            updateOverlay();
            return;
        }
        if (snap.hasErrorLayer()) {
            state = State.ERROR_PAUSED;
            log("DOORDASH_ERROR retry-layer-scan");
            increment("stat_error");
            alertError("DoorDash 页面异常", "检测到 Retry 错误层，已暂停。请人工处理后点继续监控。");
            updateOverlay();
            return;
        }
        if (detectAndAlertOffer(snap)) return;

        if (settleDeadlineAt > 0L) {
            if (snap.emptyPage) {
                markProgress();
                settleDeadlineAt = 0L;
                settleStage = 0;
                advanceDate();
                return;
            }
            if (snap.dateStateChanged(expectedAutoDateIndex)) {
                markProgress();
                if (detectAndAlertOffer(snap)) return;
                if (settleStage == 0) {
                    settleStage = 1;
                    scheduleScan(300L);
                    return;
                }
            }
            if (now >= settleDeadlineAt) {
                log("DATE_SETTLE_NO_SIGNAL expected=D" + (expectedAutoDateIndex + 1));
                markProgress();
                settleDeadlineAt = 0L;
                settleStage = 0;
                advanceDate();
                return;
            }
            settleStage++;
            scheduleScan(settleStage <= 2 ? SLOW_RECHECK_MS : Math.max(100L, settleDeadlineAt - now));
            return;
        }

        int next = findNextEnabledDate(currentDateIndex);
        if (next < 0) {
            state = State.USER_PAUSED;
            log("NO_SCAN_DAYS_ENABLED");
            alertError("未选择扫描日期", "请在 DD Alert Watcher 中至少选择一个 D1–D7 日期。");
            updateOverlay();
            return;
        }
        currentDateIndex = next;
        tapDate(currentDateIndex);
    }

    private void tapDate(int index) {
        // Preserve the coordinates verified on the user's Samsung / Dasher Schedule layout.
        // D1..D7: x=101,236,371,506,641,776,911; y=349.
        float x = 101f + 135f * index;
        float y = 349f;

        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, 60);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        expectedAutoDateIndex = index;
        long gestureNow = System.currentTimeMillis();
        expectedAutoDateEventUntil = gestureNow + SELF_EVENT_WINDOW_MS;
        // Injected gestures can generate touch-interaction callbacks on some Samsung builds.
        // Keep this window short so real human touches still take priority almost immediately.
        selfGestureTouchSuppressUntil = gestureNow + 220L;
        scanStartedAt = gestureNow;
        settleDeadlineAt = scanStartedAt + MAX_SETTLE_MS;
        settleStage = 0;
        dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
                scheduleScan(EMPTY_FAST_MS);
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
                log("DATE_CLICK_FAIL D" + (index + 1));
                increment("stat_error");
                scheduleScan(500L);
            }
        }, null);
    }

    private void advanceDate() {
        currentRoundScanned++;
        currentDateIndex = (currentDateIndex + 1) % 7;
        if (currentRoundScanned >= enabledDateCount()) {
            currentRoundScanned = 0;
            long pause = 500L;
            scheduleScan(pause);
        } else {
            scheduleScan(10L);
        }
    }

    private int findNextEnabledDate(int start) {
        for (int i = 0; i < 7; i++) {
            int idx = (start + i) % 7;
            if (prefs.getBoolean("scan_d" + (idx + 1), true)) return idx;
        }
        return -1;
    }

    private int enabledDateCount() {
        int count = 0;
        for (int i = 0; i < 7; i++) if (prefs.getBoolean("scan_d" + (i + 1), true)) count++;
        return Math.max(1, count);
    }

    private void markProgress() {
        lastProgressAt = System.currentTimeMillis();
    }

    private void resetWatchdogClock() {
        lastProgressAt = System.currentTimeMillis();
    }

    private void softRestartScanner() {
        cancelPendingScan();
        settleDeadlineAt = 0L;
        settleStage = 0;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        selfGestureTouchSuppressUntil = 0L;
        currentRoundScanned = 0;
        resetWatchdogClock();
        scheduleScan(300L);
    }

    private void evaluateSchedule() {
        if (prefs == null) return;
        long now = System.currentTimeMillis();
        long tempUntil = prefs.getLong("temp_until", 0L);
        if (tempUntil > now) return;
        if (tempUntil > 0L && tempUntil <= now) prefs.edit().remove("temp_until").apply();

        boolean enabled = prefs.getBoolean("schedule_enabled", false);
        if (!enabled) return;

        boolean allowed = isScheduleAllowedNow();
        if (!allowed && state == State.RUNNING) {
            state = State.SCHEDULE_ENDED;
            cancelPendingScan();
            log("SCHEDULE_END");
            notifyInfo("定时监控已结束", "已安全停止 Pure Alert 扫描。", 3005);
            updateOverlay();
        } else if (allowed && (state == State.SCHEDULE_ENDED || state == State.SCHEDULE_WAIT)) {
            if (state == State.USER_PAUSED || state == State.OFFER_FROZEN || state == State.ERROR_PAUSED) return;
            if (dasherForeground && onOffersPage) {
                state = State.RUNNING;
                scheduleDueNotified = false;
                resetWatchdogClock();
                log("SCHEDULE_START");
                scheduleScan(100L);
            } else if (!scheduleDueNotified) {
                scheduleDueNotified = true;
                notifyInfo("定时运行时间已到", "请打开 Dasher → Schedule → Offers。程序不会自动打开 DoorDash。", 3004);
            }
        }
    }

    private boolean isScheduleAllowedNow() {
        if (prefs == null) return true;
        long nowMs = System.currentTimeMillis();
        if (prefs.getLong("temp_until", 0L) > nowMs) return true;
        if (!prefs.getBoolean("schedule_enabled", false)) return true;

        Calendar c = Calendar.getInstance();
        int minute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        int start = parseMinutes(prefs.getString("schedule_start", "10:30"));
        int end = parseMinutes(prefs.getString("schedule_end", "21:30"));
        if (start == end) return dayEnabled(c);
        if (start < end) return dayEnabled(c) && minute >= start && minute < end;
        // Cross-midnight: 22:00→02:00 belongs to the day on which the window started.
        if (minute >= start) return dayEnabled(c);
        if (minute < end) {
            Calendar previous = (Calendar) c.clone();
            previous.add(Calendar.DAY_OF_YEAR, -1);
            return dayEnabled(previous);
        }
        return false;
    }

    private boolean dayEnabled(Calendar c) {
        int javaDow = c.get(Calendar.DAY_OF_WEEK);
        int idx = javaDow == Calendar.SUNDAY ? 6 : javaDow - Calendar.MONDAY;
        return prefs.getBoolean("schedule_day_" + idx, true);
    }

    private int parseMinutes(String hhmm) {
        try {
            String[] p = hhmm.split(":");
            return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
        } catch (Throwable t) {
            return 0;
        }
    }

    private void ensureOverlay() {
        if (overlay != null || wm == null) return;
        try {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(14, 10, 14, 10);
            box.setBackgroundColor(Color.argb(210, 35, 35, 35));
            box.setKeepScreenOn(prefs == null || prefs.getBoolean("keep_awake", true));

            overlayStatus = new TextView(this);
            overlayStatus.setTextColor(Color.WHITE);
            overlayStatus.setTextSize(13);
            box.addView(overlayStatus);

            LinearLayout buttons = new LinearLayout(this);
            Button pause = new Button(this);
            pause.setText("暂停");
            pause.setOnClickListener(v -> pauseByUser());
            Button resume = new Button(this);
            resume.setText("继续");
            resume.setOnClickListener(v -> resumeByUser());
            Button stop = new Button(this);
            stop.setText("停止");
            stop.setOnClickListener(v -> stopByUser());
            buttons.addView(resume);
            buttons.addView(pause);
            buttons.addView(stop);
            box.addView(buttons);

            overlayLp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            overlayLp.gravity = Gravity.TOP | Gravity.START;
            overlayLp.x = prefs.getInt("overlay_x", 520);
            overlayLp.y = prefs.getInt("overlay_y", 650);

            box.setOnTouchListener(new View.OnTouchListener() {
                private float downX, downY;
                private int startX, startY;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downX = e.getRawX(); downY = e.getRawY();
                            startX = overlayLp.x; startY = overlayLp.y;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            overlayLp.x = startX + Math.round(e.getRawX() - downX);
                            overlayLp.y = startY + Math.round(e.getRawY() - downY);
                            wm.updateViewLayout(box, overlayLp);
                            return true;
                        case MotionEvent.ACTION_UP:
                            prefs.edit().putInt("overlay_x", overlayLp.x).putInt("overlay_y", overlayLp.y).apply();
                            return true;
                    }
                    return false;
                }
            });
            wm.addView(box, overlayLp);
            overlay = box;
            updateOverlay();
        } catch (Throwable t) {
            log("OVERLAY_CREATE_FAIL " + t.getClass().getSimpleName());
            increment("stat_error");
            alertError("悬浮窗异常", "主悬浮窗创建失败，请检查无障碍服务。");
        }
    }

    private void refreshOverlayIfNeeded() {
        if (overlay == null) ensureOverlay();
        else updateOverlay();
    }

    private void removeOverlay() {
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Throwable ignored) {}
        }
        overlay = null;
        overlayStatus = null;
    }

    private void updateOverlay() {
        if (overlayStatus == null) return;
        String label;
        switch (state) {
            case RUNNING:
                label = System.currentTimeMillis() < manualHoldUntil ? "人工让路" : "运行中";
                break;
            case WAITING_OFFERS_PAGE: label = "等待 Offers 页面"; break;
            case USER_PAUSED: label = "人工暂停"; break;
            case SCHEDULE_WAIT: label = "定时等待"; break;
            case SCHEDULE_ENDED: label = "定时结束"; break;
            case OFFER_FROZEN: label = "Offer 已发现"; break;
            case ERROR_PAUSED: label = "异常暂停"; break;
            default: label = "已停止";
        }
        String extra = "";
        if (prefs != null && prefs.getBoolean("schedule_enabled", false)) {
            extra = " | " + prefs.getString("schedule_start", "10:30") + "-" + prefs.getString("schedule_end", "21:30");
        }
        long age = lastProgressAt == 0 ? 0 : Math.max(0, (System.currentTimeMillis() - lastProgressAt) / 1000);
        overlayStatus.setText("DD Alert: " + label + " | D" + (currentDateIndex + 1) + extra + "\n最后进展 " + age + "s 前");
    }

    private void pauseByUser() {
        state = State.USER_PAUSED;
        cancelPendingScan();
        log("USER_PAUSE");
        updateOverlay();
    }

    private void resumeByUser() {
        if (!isScheduleAllowedNow()) {
            state = State.SCHEDULE_WAIT;
            log("USER_RESUME_BLOCKED schedule");
            updateOverlay();
            return;
        }
        manualHoldUntil = 0L;
        errorNotified = false;
        resetWatchdogClock();
        if (dasherForeground && onOffersPage) {
            state = State.RUNNING;
            log("USER_RESUME");
            scheduleScan(100L);
        } else {
            state = State.WAITING_OFFERS_PAGE;
            log("USER_RESUME_WAIT_OFFERS_PAGE");
        }
        updateOverlay();
    }

    private void stopByUser() {
        state = State.STOPPED;
        cancelPendingScan();
        log("USER_STOP overlay");
        updateOverlay();
    }

    private int dateIndexFromNode(AccessibilityNodeInfo node) {
        if (node == null) return -1;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.isEmpty()) return -1;
        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;
        int cy = r.centerY();
        if (cy < height * 0.20 || cy > height * 0.43) return -1;
        float first = width * 0.094f;
        float step = width * 0.125f;
        int idx = Math.round((r.centerX() - first) / step);
        return idx >= 0 && idx < 7 ? idx : -1;
    }

    private boolean looksLikeDateRowNode(AccessibilityNodeInfo node) {
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        int h = getResources().getDisplayMetrics().heightPixels;
        return !r.isEmpty() && r.centerY() > h * 0.20 && r.centerY() < h * 0.43;
    }

    private void sendOfferAlert(String title, String body) {
        if (prefs.getBoolean("vibrate", true)) vibrate();
        if (prefs.getBoolean("sound", true)) playSound();
        notifyMessage(CHANNEL_OFFER, title, body, 2001, NotificationManager.IMPORTANCE_HIGH);
    }

    private void alertError(String title, String body) {
        vibrate();
        notifyMessage(CHANNEL_ERROR, "DD Alert Watcher：" + title, body, 2002, NotificationManager.IMPORTANCE_HIGH);
    }

    private void notifyInfo(String title, String body, int id) {
        notifyMessage(CHANNEL_ERROR, title, body, id, NotificationManager.IMPORTANCE_DEFAULT);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel offer = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
        offer.enableVibration(true);
        offer.setDescription("Any Offer alerts from DD Alert Watcher");
        NotificationChannel error = new NotificationChannel(CHANNEL_ERROR, "Monitor Errors", NotificationManager.IMPORTANCE_HIGH);
        error.enableVibration(true);
        nm.createNotificationChannel(offer);
        nm.createNotificationChannel(error);
    }

    private void notifyMessage(String channel, String title, String body, int id, int importance) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(this, channel)
                : new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(id, b.build());
    }

    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 350, 180, 350, 180, 700}, -1));
            else v.vibrate(new long[]{0, 350, 180, 350, 180, 700}, -1);
        } catch (Throwable ignored) {}
    }

    private void playSound() {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) {}
    }

    private void increment(String key) {
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply();
    }

    private void log(String msg) {
        if (prefs == null) return;
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = ts + " " + msg;
        String old = prefs.getString("logs", "");
        String all = line + (old.isEmpty() ? "" : "\n" + old);
        String[] lines = all.split("\n");
        StringBuilder sb = new StringBuilder();
        int max = Math.min(lines.length, 200);
        for (int i = 0; i < max; i++) {
            if (i > 0) sb.append('\n');
            sb.append(lines[i]);
        }
        prefs.edit().putString("logs", sb.toString()).apply();
    }

    public static void requestPause(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.pauseByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "pause").apply();
    }

    public static void requestResume(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.resumeByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("command", "resume")
                .putString("service_state", "请回到 Dasher Offers；若服务已启用会自动继续")
                .apply();
    }

    public static void requestReload(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) {
            if (s.overlay != null) s.overlay.setKeepScreenOn(s.prefs.getBoolean("keep_awake", true));
            s.updateOverlay();
            return;
        }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "reload").apply();
    }

    public static void requestTestAlert(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true); nm.createNotificationChannel(ch);
        }
        Vibrator v = (Vibrator) c.getSystemService(VIBRATOR_SERVICE);
        if (v != null) {
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 300, 150, 500}, -1));
            else v.vibrate(new long[]{0, 300, 150, 500}, -1);
        }
        try {
            Ringtone r = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            if (r != null) r.play();
        } catch (Throwable ignored) {}
        Intent intent = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, CHANNEL_OFFER) : new android.app.Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("测试：发现 Offer！")
                .setContentText("声音、震动、系统通知链工作正常。真实 Offer 会冻结扫描等待人工处理。")
                .setContentIntent(pi).setAutoCancel(true);
        nm.notify(2099, b.build());
    }

    private static class Snapshot {
        final List<String> texts = new ArrayList<>();
        final List<Node> nodes = new ArrayList<>();
        boolean emptyPage;
        boolean errorLayer;
        boolean loadingLike;
        boolean offerCandidate;
        String offerEvidence = "none";

        static Snapshot from(AccessibilityNodeInfo root) {
            Snapshot s = new Snapshot();
            if (root == null) return s;
            ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
            q.add(root);
            int guard = 0;
            while (!q.isEmpty() && guard++ < 1200) {
                AccessibilityNodeInfo n = q.removeFirst();
                String t = safe(n.getText());
                String d = safe(n.getContentDescription());
                Rect r = new Rect(); n.getBoundsInScreen(r);
                boolean clickable = n.isClickable();
                if (!t.isEmpty()) s.texts.add(t);
                if (!d.isEmpty() && !d.equals(t)) s.texts.add(d);
                s.nodes.add(new Node(t, d, clickable, r));
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) q.addLast(c);
                }
            }
            s.classify();
            return s;
        }

        void classify() {
            String all = String.join(" \n ", texts).toLowerCase(Locale.US);
            emptyPage = containsAny(all,
                    "nothing available to schedule",
                    "there's nothing available",
                    "there is nothing available",
                    "no offers available");
            errorLayer = (all.contains("something went wrong") || all.contains("unexpected error")) && all.contains("retry");
            loadingLike = all.contains("loading") || all.contains("please wait");

            if (emptyPage || errorLayer || loadingLike) return;
            boolean offersTab = all.contains("offers") && (all.contains("schedule") || all.contains("my schedule") || all.contains("dash"));
            boolean money = all.matches("(?s).*\\$\\s*\\d+(?:\\.\\d{1,2})?.*");
            boolean claim = containsAny(all, "claim", "claim and schedule", "acknowledge");
            boolean deliveryWords = containsAny(all, "pickup", "dropoff", "delivery", "catering", "customer", "miles", " mi ");
            int clickableContent = 0;
            for (Node n : nodes) {
                if (n.clickable && (!n.text.isEmpty() || !n.desc.isEmpty())) clickableContent++;
            }
            if (offersTab && money) { offerCandidate = true; offerEvidence = "money"; }
            else if (offersTab && claim) { offerCandidate = true; offerEvidence = "claim"; }
            else if (offersTab && deliveryWords && clickableContent >= 3) { offerCandidate = true; offerEvidence = "structure"; }
        }

        boolean looksLikeOffersPageStrict(int width, int height) {
            String all = String.join(" ", texts).toLowerCase(Locale.US);
            if (!all.contains("offers")) return false;

            // The Offers screen used by this build always exposes the D1–D7 date strip.
            // Merely seeing the global "Offers" navigation label is not enough: other
            // Dasher pages can contain that label too, which caused v1.1.7.1 to keep running
            // after the user navigated away. Verify several date-strip columns instead.
            boolean[] slot = new boolean[7];
            int slots = 0;
            float scaleX = width > 0 ? width / 1080f : 1f;
            float yMin = Math.max(170f, height * 0.12f);
            float yMax = Math.min(620f, height * 0.36f);
            for (Node n : nodes) {
                if (n.bounds.isEmpty()) continue;
                float cy = n.bounds.centerY();
                if (cy < yMin || cy > yMax) continue;
                float cx = n.bounds.centerX();
                for (int i = 0; i < 7; i++) {
                    float targetX = (101f + 135f * i) * scaleX;
                    if (Math.abs(cx - targetX) <= 82f * scaleX) {
                        if (!slot[i] && (!n.text.isEmpty() || !n.desc.isEmpty() || n.clickable)) {
                            slot[i] = true;
                            slots++;
                        }
                        break;
                    }
                }
            }
            return slots >= 4;
        }

        boolean hasErrorLayer() { return errorLayer; }

        boolean dateStateChanged(int expectedIndex) {
            // Compose versions do not expose a stable selected-state identifier; content events plus
            // empty/offer detection are the primary confirmation. This method intentionally remains conservative.
            return !texts.isEmpty();
        }

        String fingerprint() {
            StringBuilder sb = new StringBuilder();
            int n = Math.min(texts.size(), 24);
            for (int i = 0; i < n; i++) sb.append(texts.get(i)).append('|');
            return Integer.toHexString(sb.toString().hashCode());
        }

        static String safe(CharSequence c) { return c == null ? "" : c.toString().trim(); }
        static boolean containsAny(String s, String... parts) {
            for (String p : parts) if (s.contains(p)) return true;
            return false;
        }
    }

    private static class Node {
        final String text;
        final String desc;
        final boolean clickable;
        final Rect bounds;
        Node(String text, String desc, boolean clickable, Rect bounds) {
            this.text = text; this.desc = desc; this.clickable = clickable; this.bounds = new Rect(bounds);
        }
    }
}
