package com.ddalertwatcher.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Map;
import java.util.LinkedHashMap;
import java.util.Iterator;
import java.util.regex.Pattern;
import java.util.LinkedHashSet;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class OfferAccessibilityService extends AccessibilityService {
    private static volatile OfferAccessibilityService INSTANCE;

    private static final String DASHER_PACKAGE = "com.doordash.driverapp";
    private static final String PREFS = MainActivity.PREFS;
    private static final String CHANNEL_OFFER = "offer_alert";
    private static final String CHANNEL_MONITOR = "monitor_alert";

    // v1.1.7 SelfEventFix behavior: delayed Compose/self events were seen around 0.5-0.65 s.
    private static final long SELF_EVENT_GRACE_MS = 800L;
    private static final long USER_INTERACTION_HOLD_MS = 3500L;

    // Light speed-up only. Obvious empty pages settle around 0.65 s/date; ambiguous pages get up to ~1 s.
    private static final long FIRST_SETTLE_MS = 320L;
    private static final long SETTLE_RECHECK_MS = 80L;
    private static final long MAX_SETTLE_MS = 550L;
    private static final long ROUND_PAUSE_MS = 60L;

    private static final long WATCHDOG_MS = 18_000L;
    private static final long WATCHDOG_TICK_MS = 2_000L;

    private enum State { RUNNING, USER_PAUSED, OFFER_FROZEN, ERROR_PAUSED, STOPPED }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable scanRunnable = new Runnable() {
        @Override public void run() {
            scanScheduled = false;
            scanTick();
        }
    };
    private final Runnable watchdogRunnable = new Runnable() {
        @Override public void run() {
            try {
                processExternalCommand();

                // Offer freeze: reminder only; never restart polling or click anything.
                if (state == State.OFFER_FROZEN) {
                    long reminderNow = System.currentTimeMillis();
                    if (!offerManualInterventionSeen && nextOfferReminderAt > 0L &&
                            reminderNow >= nextOfferReminderAt) {
                        nextOfferReminderAt = reminderNow + OFFER_REMINDER_INTERVAL_MS;
                        offerReminderCount++;
                        log("OFFER_REMINDER_SENT count=" + offerReminderCount + " card=" + lastOfferFingerprint);
                        sendOfferAlert("Offer 仍待人工处理（第 " + offerReminderCount + " 次提醒）",
                                "扫描保持冻结；请查看 DoorDash，处理后点继续。");
                    }
                    return;
                }
                // PauseFix: watchdog is completely inert outside RUNNING.
                if (state != State.RUNNING) return;

                ActiveContext ctx = activeContext();

                if (ctx.dasher && ctx.snapshot != null && ctx.snapshot.hasDoorDashErrorLayer()) {
                    pauseForDoorDashError();
                    return;
                }

                if (!ctx.dasher || !ctx.offersLike) {
                    // Time outside the Offers page must not count as a scanner stall.
                    resetWatchdogClock();
                    return;
                }

                long now = System.currentTimeMillis();

                // Stable v1.1.7 manual-yield semantics: while the user is inside the
                // 3.5 s date-row handoff, watchdog must not interpret the intentional
                // quiet period as a stalled scanner.
                if (now < manualHoldUntil) {
                    resetWatchdogClock();
                    return;
                }

                // A date gesture can legitimately be waiting for its settle confirmation.
                // Do not restart the scanner while that confirmation window is still healthy.
                if (settleDeadlineAt > 0L && now <= settleDeadlineAt + 1500L) {
                    return;
                }

                if (lastProgressAt > 0L && now - lastProgressAt >= WATCHDOG_MS) {
                    log("WATCHDOG_STALL idleMs=" + (now - lastProgressAt));
                    increment("stat_stall");
                    if (++consecutiveScannerStalls >= MAX_STALL_RESTARTS) {
                        pauseForScannerFailure("WATCHDOG_REPEATED_STALL");
                    } else {
                        softRestartScanner();
                    }
                }
            } catch (Throwable t) {
                log("WATCHDOG_ERROR " + t.getClass().getSimpleName());
            } finally {
                handler.postDelayed(this, WATCHDOG_TICK_MS);
            }
        }
    };

    private SharedPreferences prefs;
    private WindowManager wm;
    private LinearLayout overlay;
    private TextView overlayStatus;

    private State state = State.STOPPED;
    private boolean scanScheduled = false;
    private int currentDateIndex = 0;
    private int roundScanned = 0;

    private int expectedAutoDateIndex = -1;
    private long expectedAutoDateEventUntil = 0L;
    private long manualHoldUntil = 0L;
    private int interactionGeneration = 0;

    private long settleDeadlineAt = 0L;
    private long dateTapStartedAt = 0L;
    private long roundStartedAt = 0L;
    private String preClickFingerprint = "";
    private boolean stateChangeLogged = false;

    private long lastProgressAt = 0L;
    private long runTimerStartedAt = 0L;
    private long runTimerDurationMs = 0L;
    private boolean runTimerAutoStopped = false;
    private static final long OFFER_REMINDER_INTERVAL_MS = 30_000L;
    private long nextOfferReminderAt = 0L;
    private int consecutiveScannerStalls = 0;
    private int consecutiveLoadingChecks = 0;
    private static final int MAX_STALL_RESTARTS = 2;
    private static final int MAX_LOADING_CHECKS = 12;
    private int offerReminderCount = 0;
    private boolean offerManualInterventionSeen = false;
    private long lastOfferAlertAt = 0L;
    private String lastOfferFingerprint = "";

    // After an Offer alert freezes scanning, the user may manually handle that card and
    // press Continue.  The same card can still remain visible in Compose for a while.
    // Keep that just-handled fingerprint suppressed until it disappears or changes,
    // so Continue really means "ignore this one and keep polling".
    private String handledOfferFingerprint = "";
    private boolean ignoreHandledOfferUntilChanged = false;

    // Handled card fingerprints survive all D1-D7 page changes/manual intervention for this service session.
    // The same exact D#|card cannot alert again merely because DoorDash briefly changes pages.
    private final LinkedHashMap<String, Long> recentlyHandledOffers = new LinkedHashMap<>();
    // Hard persistent ignore: once the user handles a D#|card, keep it suppressed
    // for the whole service session. No transitional/empty frame may release it.
    private static final int MAX_HANDLED_OFFERS = 128;
    private String lastHandledStateLog = "";
    private long lastHandledStateLogAt = 0L;
    private boolean offOffersTabLogged = false;
    private long lastEventSnapshotAt = 0L;
    private static final long EVENT_SNAPSHOT_DEBOUNCE_MS = 90L;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannels();

        boolean stopped = prefs.getBoolean("user_stopped", false);
        state = stopped ? State.STOPPED : State.RUNNING;
        resetWatchdogClock();
        prefs.edit().putString("service_state", stopped ?
                "已停止 · v1.1.7.9 Pure Alert" : "已连接/运行中 · v1.1.7.9 Pure Alert").apply();
        log("SERVICE_CONNECTED pure-alert-v1.1.7.9 state=" + state.name());
        if (state == State.RUNNING) resetRunTimerFromSettings();

        ensureOverlay();
        updateOverlay();
        handler.removeCallbacks(watchdogRunnable);
        handler.post(watchdogRunnable);
        if (state == State.RUNNING) scheduleScan(200L);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || prefs == null) return;
        processExternalCommand();

        CharSequence pkg = event.getPackageName();
        if (pkg == null || !DASHER_PACKAGE.contentEquals(pkg)) return;

        // Accessibility can emit bursts of nearly-identical Compose events. Building a full
        // snapshot for every callback wastes time and can make date polling feel sluggish.
        // Click/selected events bypass the debounce so manual-date protection remains immediate.
        int type = event.getEventType();
        long now = System.currentTimeMillis();
        boolean manualRelevant = type == AccessibilityEvent.TYPE_VIEW_CLICKED ||
                type == AccessibilityEvent.TYPE_VIEW_SELECTED;
        // A Dasher click while frozen is evidence of human intervention; stop repeat alerts.
        // A passive page update alone must not count as intervention.
        if (state == State.OFFER_FROZEN && type == AccessibilityEvent.TYPE_VIEW_CLICKED &&
                !offerManualInterventionSeen) {
            offerManualInterventionSeen = true;
            nextOfferReminderAt = 0L;
            log("OFFER_MANUAL_INTERVENTION_REMINDER_STOP");
        }
        if (!manualRelevant && now - lastEventSnapshotAt < EVENT_SNAPSHOT_DEBOUNCE_MS) return;
        lastEventSnapshotAt = now;

        // IMPORTANT: process a human date-row click before rebuilding the page snapshot.
        // During a real manual date switch, Compose can temporarily stop matching
        // looksLikeOffersPage().  If we wait for that check first, the manual click is missed
        // and the auto scanner can click again on top of the user, which can trigger the
        // DoorDash error layer.  This restores the intended v1.1.7 "human gets priority" behavior.
        handleManualDateEvent(event);

        // Once a manual date-row click is accepted, do nothing else during the handoff.
        if (state == State.RUNNING && System.currentTimeMillis() < manualHoldUntil) {
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        Snapshot snap = Snapshot.from(root);

        if (state == State.RUNNING && snap.hasDoorDashErrorLayer()) {
            pauseForDoorDashError();
            return;
        }

        // Offer recognition stays live between polling ticks. It never auto-claims.
        if (state == State.RUNNING && snap.looksLikeOffersPage()) {
            if (detectAndAlertOffer(snap)) return;
        }
    }

    @Override public void onInterrupt() { log("SERVICE_INTERRUPTED"); }

    @Override
    public void onDestroy() {
        cancelPendingPolling();
        handler.removeCallbacks(watchdogRunnable);
        removeOverlay();
        if (prefs != null) prefs.edit().putString("service_state", "服务已停止").apply();
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }

    private void handleManualDateEvent(AccessibilityEvent event) {
        if (state != State.RUNNING) return;

        // Stable v1.1.7 manual-intervention behavior.
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_VIEW_CLICKED &&
                type != AccessibilityEvent.TYPE_VIEW_SELECTED) return;

        AccessibilityNodeInfo src = event.getSource();
        int eventDate = dateIndexFromNode(src);
        if (eventDate < 0) return;

        ActiveContext manualCtx = activeContext();
        if (!manualCtx.dasher || !manualCtx.offersLike) return;

        long now = System.currentTimeMillis();

        // Ignore the delayed Accessibility event caused by our own automatic date tap.
        if (expectedAutoDateIndex == eventDate && now <= expectedAutoDateEventUntil) {
            return;
        }

        manualHoldUntil = now + USER_INTERACTION_HOLD_MS;
        interactionGeneration++;
        cancelPendingPolling();

        if (expectedAutoDateIndex >= 0 && expectedAutoDateIndex != eventDate) {
            log("MANUAL_DATE_OVERRIDE D" + (eventDate + 1));
        } else {
            log("MANUAL_DATE_ROW_CLICK expectedAuto=" +
                    (expectedAutoDateIndex < 0 ? "none" : "D" + (expectedAutoDateIndex + 1)));
        }

        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;

        resetWatchdogClock();
        log("USER_INTERACTION_HOLD date-row-click yield=3500ms");
        scheduleScan(USER_INTERACTION_HOLD_MS + 50L);
    }

    private void resetRunTimerFromSettings() {
        int minutes = prefs.getInt("run_duration_minutes", 0);
        if (minutes < 0) minutes = 0;
        if (minutes > 720) minutes = 720;
        runTimerDurationMs = minutes == 0 ? 0L : minutes * 60_000L;
        runTimerStartedAt = System.currentTimeMillis();
        runTimerAutoStopped = false;
        log(minutes == 0 ? "RUN_TIMER unlimited" : "RUN_TIMER start=" + minutes + "min");
    }

    private boolean checkRunTimer() {
        if (state != State.RUNNING || runTimerDurationMs <= 0L || runTimerAutoStopped) return false;
        long elapsed = System.currentTimeMillis() - runTimerStartedAt;
        if (elapsed < runTimerDurationMs) return false;

        runTimerAutoStopped = true;
        state = State.STOPPED;
        nextOfferReminderAt = 0L;
        offerManualInterventionSeen = true;
        cancelPendingPolling();
        log("RUN_TIMER_FINISHED_AUTO_STOP");
        prefs.edit().putBoolean("user_stopped", true)
                .putString("service_state", "计时结束 · 已停止 · v1.1.7.9 Pure Alert").apply();
        sendOfferAlert("DD Alert Watcher", "设定运行时间已结束，扫描已停止。");
        updateOverlay();
        return true;
    }

    private String runTimerLabel() {
        if (runTimerDurationMs <= 0L) return "";
        long remaining = Math.max(0L,
                runTimerDurationMs - (System.currentTimeMillis() - runTimerStartedAt));
        long totalSec = remaining / 1000L;
        return String.format(Locale.US, " | %02d:%02d", totalSec / 60L, totalSec % 60L);
    }

    private void scanTick() {
        processExternalCommand();
        if (state != State.RUNNING) return;
        if (checkRunTimer()) return;

        long now = System.currentTimeMillis();
        if (now < manualHoldUntil) {
            scheduleScan(manualHoldUntil - now + 50L);
            return;
        }

        ActiveContext ctx = activeContext();
        if (!ctx.dasher) {
            offOffersTabLogged = false;
            scheduleScan(700L);
            return;
        }

        if (!ctx.offersLike) {
            // Never switch D1-D7 while Dash or My schedule is active.
            // Stay idle and wait until the user returns to Offers.
            cancelSettleOnly();
            if (!offOffersTabLogged) {
                log("NOT_OFFERS_TAB_SCAN_BLOCKED");
                offOffersTabLogged = true;
            }
            scheduleScan(700L);
            return;
        }

        offOffersTabLogged = false;
        Snapshot snap = ctx.snapshot;

        if (snap.hasDoorDashErrorLayer()) {
            pauseForDoorDashError();
            return;
        }

        if (detectAndAlertOffer(snap)) return;

        // Only count consecutive loading observations while actively scanning Offers.
        // A transient page change does not warrant a restart or automatic Retry.
        if (snap.loadingLike) {
            if (++consecutiveLoadingChecks >= MAX_LOADING_CHECKS) {
                pauseForScannerFailure("REPEATED_LOADING");
                return;
            }
        } else {
            consecutiveLoadingChecks = 0;
        }

        if (settleDeadlineAt > 0L) {
            if (snap.emptyPage) {
                markProgress();
                finishDateAndAdvance();
                return;
            }

            String fp = snap.fingerprint();
            if (!stateChangeLogged && !fp.equals(preClickFingerprint)) {
                stateChangeLogged = true;
            }

            // We have already waited the first ~620 ms. If content changed and no Offer was
            // detected, that is sufficient page confirmation; move on without aggressive re-clicking.
            if (stateChangeLogged) {
                markProgress();
                finishDateAndAdvance();
                return;
            }

            if (now >= settleDeadlineAt) {
                markProgress();
                finishDateAndAdvance();
                return;
            }

            scheduleScan(Math.min(SETTLE_RECHECK_MS, Math.max(60L, settleDeadlineAt - now)));
            return;
        }

        int next = findNextEnabledDate(currentDateIndex);
        if (next < 0) {
            pauseByUser();
            log("NO_SCAN_DAYS_ENABLED");
            return;
        }
        currentDateIndex = next;
        tapDate(next, snap);
    }

    private void cancelSettleOnly() {
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
    }

    private void tapDate(final int index, Snapshot before) {
        if (state != State.RUNNING) return;

        // Same tested Samsung/Dasher date-row anchors used by the stable baseline.
        int width = getResources().getDisplayMetrics().widthPixels;
        float scale = width / 1080f;
        float x = (101f + 135f * index) * scale;
        float y = 349f * scale;

        preClickFingerprint = before == null ? "" : before.fingerprint();
        stateChangeLogged = false;
        expectedAutoDateIndex = index;
        long now = System.currentTimeMillis();
        expectedAutoDateEventUntil = now + SELF_EVENT_GRACE_MS;
        settleDeadlineAt = now + MAX_SETTLE_MS;
        dateTapStartedAt = now;
        if (roundScanned == 0 && roundStartedAt == 0L) roundStartedAt = now;

        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 55))
                .build();

        final int gestureGeneration = interactionGeneration;
        dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);

                // A human date click may arrive while this automatic gesture is completing.
                // Never let a stale callback re-arm scanning during the 3.5 s manual handoff.
                long callbackNow = System.currentTimeMillis();
                if (gestureGeneration != interactionGeneration) return;
                if (callbackNow < manualHoldUntil) return;

                // PauseFix: a gesture callback arriving after USER_PAUSE cannot restart polling.
                if (state == State.RUNNING) scheduleScan(FIRST_SETTLE_MS);
            }

            @Override public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);

                long callbackNow = System.currentTimeMillis();
                if (gestureGeneration != interactionGeneration) return;
                if (callbackNow < manualHoldUntil) return;

                log("DATE_CLICK_FAIL D" + (index + 1));
                if (state == State.RUNNING) scheduleScan(260L);
            }
        }, null);
    }

    private void finishDateAndAdvance() {
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;

        if (dateTapStartedAt > 0L) {
            log("DATE_SCAN_MS D" + (currentDateIndex + 1) + "=" +
                    (System.currentTimeMillis() - dateTapStartedAt));
            dateTapStartedAt = 0L;
        }
        roundScanned++;
        currentDateIndex = (currentDateIndex + 1) % 7;
        if (roundScanned >= enabledDateCount()) {
            roundScanned = 0;
            increment("stat_round");
            log("ROUND " + prefs.getInt("stat_round", 0) + " complete" +
                    (roundStartedAt > 0L ? " durationMs=" +
                            (System.currentTimeMillis() - roundStartedAt) : ""));
            roundStartedAt = 0L;
            scheduleScan(ROUND_PAUSE_MS);
        } else {
            scheduleScan(20L);
        }
    }

    private String scopedOfferKey(int dateIndex, String cardFp) {
        return "D" + (dateIndex + 1) + "|" + (cardFp == null ? "" : cardFp);
    }

    private void pruneHandledOffers(long now) {
        // No time-based expiry. Long-lived DoorDash Offers may remain posted well
        // beyond 15 minutes, so TTL expiry would incorrectly alert the same card again.
        // Never evict an explicitly handled card during this service session.
        // Eviction would make an old, still-visible card alert again.
    }

    private void rememberHandledOffer(String scopedKey) {
        if (scopedKey == null || scopedKey.isEmpty()) return;
        long now = System.currentTimeMillis();
        pruneHandledOffers(now);
        recentlyHandledOffers.remove(scopedKey);
        recentlyHandledOffers.put(scopedKey, now);
        handledOfferFingerprint = scopedKey;
        ignoreHandledOfferUntilChanged = true;
        log("OFFER_HANDLED_PERSIST_ADD " + scopedKey);
    }

    private boolean isRecentlyHandledOffer(String scopedKey, long now) {
        if (scopedKey == null || scopedKey.isEmpty()) return false;
        pruneHandledOffers(now);
        return recentlyHandledOffers.containsKey(scopedKey);
    }

    private void logHandledState(int total, int handled, int unhandled) {
        long now = System.currentTimeMillis();
        String stateKey = "D" + (currentDateIndex + 1) + ":" + total + ":" + handled + ":" + unhandled;
        if (!stateKey.equals(lastHandledStateLog) || now - lastHandledStateLogAt >= 3000L) {
            lastHandledStateLog = stateKey;
            lastHandledStateLogAt = now;
            log("HANDLED_STATE D" + (currentDateIndex + 1) +
                    " total=" + total +
                    " handled=" + handled +
                    " unhandled=" + unhandled);
        }
    }

    private boolean detectAndAlertOffer(Snapshot snap) {
        if (state != State.RUNNING || snap == null) return false;

        List<String> cards = snap.offerCardFingerprints();

        if (cards.isEmpty() && snap.offerCandidate && !snap.emptyPage && !snap.loadingLike) {
            cards.add(snap.fingerprint());
        }

        if (snap.loadingLike) {
            return false;
        }

        // Hard persistent ignore: do not release handled cards from page-transition frames.
        if (cards.isEmpty() || snap.emptyPage) {
            return false;
        }

        long now = System.currentTimeMillis();
        int handledCount = 0;
        int unhandledCount = 0;
        String candidateCardFp = "";

        // Evaluate all visible cards before choosing the next candidate.
        for (String cardFp : cards) {
            String scopedKey = scopedOfferKey(currentDateIndex, cardFp);
            if (isRecentlyHandledOffer(scopedKey, now)) {
                handledCount++;
            } else {
                unhandledCount++;
                if (candidateCardFp.isEmpty()) candidateCardFp = cardFp;
            }
        }

        logHandledState(cards.size(), handledCount, unhandledCount);

        if (candidateCardFp.isEmpty()) {
            return false;
        }

        String candidateKey = scopedOfferKey(currentDateIndex, candidateCardFp);

        // Duplicate-frame protection is date-scoped.
        if (candidateKey.equals(lastOfferFingerprint) && now - lastOfferAlertAt < 60_000L) {
            return false;
        }

        lastOfferFingerprint = candidateKey;
        lastOfferAlertAt = now;
        offerManualInterventionSeen = false;
        offerReminderCount = 0;
        nextOfferReminderAt = now + OFFER_REMINDER_INTERVAL_MS;
        state = State.OFFER_FROZEN;
        cancelPendingPolling();
        increment("stat_offer");

        log("OFFER_FOUND D" + (currentDateIndex + 1) +
                " card=" + candidateCardFp +
                " total=" + cards.size() +
                " handled=" + handledCount +
                " unhandled=" + unhandledCount);
        log("ALERT_SENT + SCAN_FROZEN");

        sendOfferAlert("发现 Offer！",
                unhandledCount > 1
                        ? "本日期还有 " + unhandledCount + " 张未处理 Offer；当前一张已报警。处理后点继续，会继续检查下一张。"
                        : "请立即查看 Dasher；扫描已冻结，处理后手动点继续。");

        prefs.edit().putString("service_state",
                "Offer 已发现/已冻结 · v1.1.7.9").apply();
        ensureOverlay();
        updateOverlay();
        return true;
    }

    private void pauseForScannerFailure(String reason) {
        if (state != State.RUNNING) return;
        state = State.ERROR_PAUSED;
        cancelPendingPolling();
        interactionGeneration++;
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        nextOfferReminderAt = 0L;
        resetWatchdogClock();
        log("SCANNER_FAILURE_PAUSED reason=" + reason);
        prefs.edit().putString("service_state", "扫描异常 · 已暂停 · 请人工检查").apply();
        sendOfferAlert("DD 监控已暂停", "连续加载失败或扫描卡住；请检查 DoorDash 页面，确认后点继续。");
        ensureOverlay();
        updateOverlay();
    }

    private void pauseForDoorDashError() {
        if (state == State.STOPPED || state == State.ERROR_PAUSED) return;

        state = State.ERROR_PAUSED;
        cancelPendingPolling();
        interactionGeneration++;
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        resetWatchdogClock();

        log("DOORDASH_ERROR_LAYER_DETECTED");
        log("ERROR_PAUSED_NO_AUTO_RETRY");
        prefs.edit().putString("service_state",
                "DoorDash 错误页 · 已暂停 · v1.1.7.9 Pure Alert").apply();

        // Do not click Retry automatically. Alert the user once and freeze scanning.
        sendOfferAlert("DoorDash 页面错误",
                "检测到 Something went wrong。扫描已暂停，不会自动点 Retry；请人工处理后再点继续。");
        ensureOverlay();
        updateOverlay();
    }

    private void pauseByUser() {
        if (state == State.STOPPED) return;
        if (state != State.USER_PAUSED) log("USER_PAUSE");

        state = State.USER_PAUSED;
        consecutiveScannerStalls = 0;
        consecutiveLoadingChecks = 0;
        nextOfferReminderAt = 0L;
        offerManualInterventionSeen = true;
        // Hard pause: remove pending scan work and clear pre-pause settle/self-click state.
        cancelPendingPolling();
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;

        prefs.edit().putString("service_state", "人工暂停 · v1.1.7.9 Pure Alert").apply();
        ensureOverlay();
        updateOverlay();
    }

    private void resumeByUser() {
        if (state == State.STOPPED) {
            log("RESUME_FROM_STOPPED_BLOCKED");
            return;
        }
        // If DoorDash's error sheet is still on screen, Continue must not restart D1-D7.
        // User must manually dismiss/Retry in DoorDash first.
        if (state == State.ERROR_PAUSED) {
            ActiveContext errorCheck = activeContext();
            if (errorCheck.dasher && errorCheck.snapshot != null &&
                    errorCheck.snapshot.hasDoorDashErrorLayer()) {
                log("ERROR_STILL_PRESENT_CONTINUE_BLOCKED");
                prefs.edit().putString("service_state",
                        "DoorDash 错误仍在 · 请先人工 Retry · v1.1.7.9").apply();
                updateOverlay();
                return;
            }
            log("DOORDASH_ERROR_CLEARED_MANUAL_RESUME");
        }

        // A failed scanner can only resume after the user returns to the Offers page.
        if (state == State.ERROR_PAUSED) {
            ActiveContext checked = activeContext();
            if (!checked.dasher || !checked.offersLike || checked.snapshot == null) {
                log("ERROR_RESUME_BLOCKED_NOT_OFFERS");
                updateOverlay();
                return;
            }
        }
        consecutiveScannerStalls = 0;
        consecutiveLoadingChecks = 0;

        // If Continue is pressed after an Offer freeze, treat only that exact card as handled.
        // Another Offer card already visible on the same date can alert next.
        boolean resumedFromOfferFreeze = (state == State.OFFER_FROZEN);
        if (resumedFromOfferFreeze && lastOfferFingerprint != null && !lastOfferFingerprint.isEmpty()) {
            rememberHandledOffer(lastOfferFingerprint);
            log("OFFER_HANDLED_IGNORE_CURRENT " + lastOfferFingerprint);
        }

        // Stop reminders on explicit Continue; do not auto-handle the Offer before this.
        nextOfferReminderAt = 0L;
        offerManualInterventionSeen = true;
        // Remove any stale work first; then reset watchdog baseline before RUNNING resumes.
        cancelPendingPolling();
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        roundScanned = 0;

        prefs.edit().putBoolean("user_stopped", false).apply();
        state = State.RUNNING;
        resetRunTimerFromSettings();
        resetWatchdogClock();
        log("USER_RESUME");
        prefs.edit().putString("service_state", "运行中 · v1.1.7.9 Pure Alert").apply();
        ensureOverlay();
        updateOverlay();
        scheduleScan(120L);
    }

    private void stopByUser() {
        if (state != State.STOPPED) log("USER_STOP overlay");
        state = State.STOPPED;
        cancelPendingPolling();
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        prefs.edit().putBoolean("user_stopped", true)
                .putString("service_state", "已停止 · v1.1.7.9 Pure Alert").apply();
        updateOverlay();
    }

    private void softRestartScanner() {
        if (state != State.RUNNING) return;
        cancelPendingPolling();
        settleDeadlineAt = 0L;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        roundScanned = 0;
        resetWatchdogClock();
        scheduleScan(250L);
    }

    private void cancelPendingPolling() {
        handler.removeCallbacks(scanRunnable);
        scanScheduled = false;
    }

    private void scheduleScan(long delayMs) {
        // Central gate prevents any stale callback from rearming polling during pause/freeze/stop.
        if (state != State.RUNNING || scanScheduled) return;
        scanScheduled = true;
        handler.postDelayed(scanRunnable, Math.max(0L, delayMs));
    }

    private void processExternalCommand() {
        if (prefs == null) return;
        String cmd = prefs.getString("command", "");
        if (cmd == null || cmd.isEmpty()) return;
        prefs.edit().remove("command").apply();
        if ("pause".equals(cmd)) pauseByUser();
        else if ("resume".equals(cmd)) resumeByUser();
        else if ("stop".equals(cmd)) stopByUser();
        else if ("reload".equals(cmd)) {
            if (overlay != null) overlay.setKeepScreenOn(prefs.getBoolean("keep_awake", true));
            if (state == State.RUNNING) {
                resetRunTimerFromSettings();
                log("RUN_TIMER_SETTINGS_APPLIED");
            }
            updateOverlay();
        }
    }

    private ActiveContext activeContext() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return new ActiveContext(false, false, Snapshot.empty());
            CharSequence pkg = root.getPackageName();
            boolean dasher = pkg != null && DASHER_PACKAGE.contentEquals(pkg);
            Snapshot snap = Snapshot.from(root);
            return new ActiveContext(
                    dasher,
                    dasher && (snap.looksLikeOffersPage() || snap.hasDoorDashErrorLayer()),
                    snap);
        } catch (Throwable t) {
            return new ActiveContext(false, false, Snapshot.empty());
        }
    }

    private int findNextEnabledDate(int start) {
        for (int i = 0; i < 7; i++) {
            int idx = (start + i) % 7;
            if (prefs.getBoolean("scan_d" + (idx + 1), true)) return idx;
        }
        return -1;
    }

    private int enabledDateCount() {
        int count = 0;
        for (int i = 0; i < 7; i++) if (prefs.getBoolean("scan_d" + (i + 1), true)) count++;
        return Math.max(1, count);
    }

    private int dateIndexFromNode(AccessibilityNodeInfo node) {
        if (node == null) return -1;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.isEmpty()) return -1;

        int width = getResources().getDisplayMetrics().widthPixels;
        float scale = width / 1080f;
        float expectedY = 349f * scale;
        float toleranceY = 120f * scale;
        if (Math.abs(r.centerY() - expectedY) > toleranceY) return -1;

        float first = 101f * scale;
        float step = 135f * scale;
        int idx = Math.round((r.centerX() - first) / step);
        return idx >= 0 && idx < 7 ? idx : -1;
    }

    private void ensureOverlay() {
        if (overlay != null || wm == null || state == State.STOPPED) return;
        try {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(12, 8, 12, 8);
            box.setBackgroundColor(Color.argb(205, 35, 35, 35));
            box.setKeepScreenOn(prefs.getBoolean("keep_awake", true));

            overlayStatus = new TextView(this);
            overlayStatus.setTextColor(Color.WHITE);
            overlayStatus.setTextSize(13);
            box.addView(overlayStatus);

            LinearLayout buttons = new LinearLayout(this);
            Button resume = new Button(this);
            resume.setText("继续");
            resume.setOnClickListener(v -> resumeByUser());
            Button pause = new Button(this);
            pause.setText("暂停");
            pause.setOnClickListener(v -> pauseByUser());
            Button stop = new Button(this);
            stop.setText("停止");
            stop.setOnClickListener(v -> stopByUser());
            buttons.addView(resume);
            buttons.addView(pause);
            buttons.addView(stop);
            box.addView(buttons);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            lp.y = 90;
            wm.addView(box, lp);
            overlay = box;
            log("OVERLAY_CREATED");
            updateOverlay();
        } catch (Throwable t) {
            log("OVERLAY_CREATE_FAIL " + t.getClass().getSimpleName());
        }
    }

    private void removeOverlay() {
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Throwable ignored) {}
        }
        overlay = null;
        overlayStatus = null;
    }

    private void updateOverlay() {
        if (state == State.STOPPED) {
            removeOverlay();
            return;
        }
        if (overlayStatus == null) return;
        String label;
        if (state == State.USER_PAUSED) label = "人工暂停";
        else if (state == State.OFFER_FROZEN) label = "Offer 已发现";
        else if (state == State.ERROR_PAUSED) label = "DoorDash 错误·已暂停";
        else label = "运行中";
        overlayStatus.setText("DD Alert " + label + " | D" + (currentDateIndex + 1) + runTimerLabel());
    }

    private void resetWatchdogClock() { lastProgressAt = System.currentTimeMillis(); }
    private void markProgress() { lastProgressAt = System.currentTimeMillis(); }

    private void sendOfferAlert(String title, String body) {
        if (prefs.getBoolean("vibrate", true)) vibrate();
        if (prefs.getBoolean("sound", true)) playSound();
        notifyMessage(CHANNEL_OFFER, title, body, 2001);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel offer = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
        offer.enableVibration(true);
        NotificationChannel monitor = new NotificationChannel(CHANNEL_MONITOR, "Monitor Alerts", NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(offer);
        nm.createNotificationChannel(monitor);
    }

    private void notifyMessage(String channel, String title, String body, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(this, channel)
                : new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(id, b.build());
    }

    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 350, 160, 350, 160, 650}, -1));
            else v.vibrate(new long[]{0, 350, 160, 350, 160, 650}, -1);
        } catch (Throwable ignored) {}
    }

    private void playSound() {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) {}
    }

    private void increment(String key) {
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply();
    }

    private void log(String msg) {
        if (prefs == null) return;
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = ts + " " + msg;
        String old = prefs.getString("logs", "");
        String all = line + (old.isEmpty() ? "" : "\n" + old);
        String[] lines = all.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(lines.length, 180); i++) {
            if (i > 0) sb.append('\n');
            sb.append(lines[i]);
        }
        prefs.edit().putString("logs", sb.toString()).apply();
    }

    public static void requestPause(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.pauseByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "pause").apply();
    }

    public static void requestResume(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.resumeByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("user_stopped", false)
                .putString("command", "resume")
                .putString("service_state", "等待无障碍服务连接后继续").apply();
    }

    public static void requestStop(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.stopByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("user_stopped", true)
                .putString("command", "stop")
                .putString("service_state", "已停止 · v1.1.7.9 Pure Alert").apply();
    }

    public static void requestReload(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) {
            if (s.overlay != null) s.overlay.setKeepScreenOn(s.prefs.getBoolean("keep_awake", true));
            if (s.state == State.RUNNING) {
                s.resetRunTimerFromSettings();
                s.log("RUN_TIMER_SETTINGS_APPLIED");
            }
            s.updateOverlay();
            return;
        }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "reload").apply();
    }

    public static void requestTestAlert(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }
        try {
            Vibrator v = (Vibrator) c.getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 250, 120, 450}, -1));
                else v.vibrate(new long[]{0, 250, 120, 450}, -1);
            }
            Ringtone r = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            if (r != null) r.play();
        } catch (Throwable ignored) {}
        Intent intent = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(c, CHANNEL_OFFER)
                : new android.app.Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("测试：发现 Offer！")
                .setContentText("声音、震动和系统通知正常。")
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(2099, b.build());
    }

    private static class ActiveContext {
        final boolean dasher;
        final boolean offersLike;
        final Snapshot snapshot;
        ActiveContext(boolean dasher, boolean offersLike, Snapshot snapshot) {
            this.dasher = dasher;
            this.offersLike = offersLike;
            this.snapshot = snapshot;
        }
    }

    private static class Snapshot {
        final List<String> texts = new ArrayList<>();
        final List<Node> nodes = new ArrayList<>();
        boolean emptyPage;
        boolean loadingLike;
        boolean offerCandidate;
        boolean errorLayer;
        String offerEvidence = "none";

        static Snapshot empty() { return new Snapshot(); }

        static Snapshot from(AccessibilityNodeInfo root) {
            Snapshot s = new Snapshot();
            if (root == null) return s;
            ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
            q.add(root);
            int guard = 0;
            while (!q.isEmpty() && guard++ < 1200) {
                AccessibilityNodeInfo n = q.removeFirst();
                String t = safe(n.getText());
                String d = safe(n.getContentDescription());
                Rect r = new Rect();
                n.getBoundsInScreen(r);
                if (!t.isEmpty()) s.texts.add(t);
                if (!d.isEmpty() && !d.equals(t)) s.texts.add(d);
                s.nodes.add(new Node(t, d, n.isClickable(), n.isSelected(), n.isChecked(), r));
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) q.addLast(c);
                }
            }
            s.classify();
            return s;
        }

        void classify() {
            String all = String.join(" \n ", texts).toLowerCase(Locale.US);

            // DoorDash transient error sheet:
            // "Something went wrong" / "An unexpected error occurred" + Retry.
            // Detect this before loading/empty/offer classification so the scanner never
            // continues date tapping underneath the error layer.
            errorLayer =
                    containsAny(all, "something went wrong", "an unexpected error occurred") &&
                    containsAny(all, "retry", "try again later");
            if (errorLayer) return;

            emptyPage = containsAny(all,
                    "nothing available to schedule",
                    "there's nothing available",
                    "there is nothing available",
                    "no offers available");
            loadingLike = containsAny(all, "loading", "please wait");
            if (emptyPage || loadingLike) return;

            // Keep the same broad evidence classes used by the existing alert chain:
            // money, Claim/Acknowledge, or delivery-card structure on the Offers page.
            boolean offersContext = looksLikeOffersPage();
            boolean money = all.matches("(?s).*\\$\\s*\\d+(?:\\.\\d{1,2})?.*");
            boolean claim = containsAny(all, "claim and schedule", "claim", "acknowledge", "confirm claim", "view delivery");
            boolean deliveryWords = containsAny(all, "pickup", "dropoff", "delivery", "catering", "customer", "miles", " mi ", "deliver by", "pickup by");
            int clickableContent = 0;
            for (Node n : nodes) if (n.clickable && (!n.text.isEmpty() || !n.desc.isEmpty())) clickableContent++;

            if (offersContext && claim) { offerCandidate = true; offerEvidence = "claim"; }
            else if (offersContext && money && deliveryWords) { offerCandidate = true; offerEvidence = "money+delivery"; }
            else if (offersContext && deliveryWords && clickableContent >= 3) { offerCandidate = true; offerEvidence = "structure"; }
        }

        boolean looksLikeOffersPage() {
            String all = String.join(" ", texts).toLowerCase(Locale.US);

            // First preference: use Accessibility selected/checked state on the
            // Schedule tabs. Merely seeing the word "Offers" is NOT enough because
            // DoorDash keeps all three tab labels in the tree even when Dash or
            // My schedule is active.
            boolean sawTabSelectionState = false;
            boolean offersSelected = false;

            for (Node n : nodes) {
                String label = (n.text + " " + n.desc).trim().toLowerCase(Locale.US);
                boolean isOffers = label.equals("offers") || label.startsWith("offers ");
                boolean isDash = label.equals("dash") || label.startsWith("dash ");
                boolean isMySchedule = label.equals("my schedule") || label.startsWith("my schedule ");

                if (isOffers || isDash || isMySchedule) {
                    if (n.selected || n.checked) {
                        sawTabSelectionState = true;
                        if (isOffers) offersSelected = true;
                    }
                }
            }

            if (sawTabSelectionState) return offersSelected;

            // Fallback only to content that is specific to the Offers tab.
            // Do NOT fall back to all.contains("offers").
            return all.contains("available to schedule today") ||
                    all.contains("nothing available to schedule") ||
                    all.contains("there's nothing available") ||
                    all.contains("there is nothing available") ||
                    all.contains("claim and schedule") ||
                    all.contains("confirm claim") ||
                    all.matches("(?s).*\\$\\s*\\d+(?:\\.\\d{1,2})?\\s+offer.*");
        }

        boolean hasDoorDashErrorLayer() {
            return errorLayer;
        }


        List<String> offerCardFingerprints() {
            List<String> result = new ArrayList<>();
            LinkedHashSet<String> seen = new LinkedHashSet<>();

            Pattern offerTitle = Pattern.compile(
                    "(?i)^\\$\\s*\\d+(?:\\.\\d{1,2})?\\s*offer\\b.*");
            Pattern pickupLine = Pattern.compile(
                    "(?i).*pick\\s*up\\s*by\\s+.*");

            for (int i = 0; i < texts.size(); i++) {
                String raw = texts.get(i);
                if (raw == null) continue;

                String title = raw.trim();
                if (!offerTitle.matcher(title).matches()) continue;

                String merchant = "";
                String pickup = "";
                String typeLine = "";

                for (int j = i + 1; j < texts.size() && j <= i + 6; j++) {
                    String next = texts.get(j);
                    if (next == null) continue;
                    next = next.trim();
                    if (next.isEmpty()) continue;
                    if (offerTitle.matcher(next).matches()) break;

                    String low = next.toLowerCase(Locale.US);
                    if (low.equals("offers") || low.equals("dash") ||
                            low.equals("my schedule") || low.equals("schedule")) {
                        continue;
                    }

                    if (pickup.isEmpty() && pickupLine.matcher(next).matches()) {
                        pickup = normalizeCardText(next);
                        continue;
                    }

                    if (typeLine.isEmpty() &&
                            (low.contains("catering") || low.contains("lof") || low.contains("large"))) {
                        typeLine = normalizeCardText(next);
                    }

                    if (merchant.isEmpty() &&
                            !low.startsWith("ca:") &&
                            !low.matches(".*\\b(?:mon|tue|wed|thu|fri|sat|sun)\\b.*")) {
                        merchant = normalizeCardText(next);
                    }
                }

                String identity = normalizeCardText(title) + "|" +
                        merchant + "|" + typeLine + "|" + pickup;

                String fp = Integer.toHexString(identity.hashCode());
                if (seen.add(fp)) result.add(fp);
            }

            return result;
        }

        static String normalizeCardText(String value) {
            if (value == null) return "";
            return value.trim()
                    .toLowerCase(Locale.US)
                    .replaceAll("\\s+", " ");
        }

        String fingerprint() {
            StringBuilder sb = new StringBuilder();
            int n = Math.min(texts.size(), 30);
            for (int i = 0; i < n; i++) sb.append(texts.get(i)).append('|');
            return Integer.toHexString(sb.toString().hashCode());
        }

        static String safe(CharSequence c) { return c == null ? "" : c.toString().trim(); }
        static boolean containsAny(String s, String... parts) {
            for (String p : parts) if (s.contains(p)) return true;
            return false;
        }
    }

    private static class Node {
        final String text;
        final String desc;
        final boolean clickable;
        final boolean selected;
        final boolean checked;
        final Rect bounds;

        Node(String text, String desc, boolean clickable, boolean selected, boolean checked, Rect bounds) {
            this.text = text;
            this.desc = desc;
            this.clickable = clickable;
            this.selected = selected;
            this.checked = checked;
            this.bounds = new Rect(bounds);
        }
    }
}
