# DD Alert Watcher v1.1.7.1 Pure Alert

Baseline: v1.1.7 SelfEventFix behavior.

- Keeps the v1.1.7 D1–D7 polling flow and overlay controls.
- Keeps the v1.1.7 manual date-row handoff: about 3.5 seconds, then automatic scanning resumes.
- USER_PAUSE is a hard pause: pending polling is cancelled and watchdog is completely inert.
- A short 1.2 s guard after Pause prevents an adjacent/duplicate touch from being interpreted as Stop; the overlay UI itself is unchanged.
- Watchdog also ignores the intentional manual-yield window and a healthy date-settle window.
- Pure Alert: any Offer on any enabled D1–D7 date immediately triggers sound/vibration/notification and freezes scanning.
- No automatic Claim and no opening offer details to calculate miles.
- Amount / miles / $/mi inputs remain removed.
- Only a light timing optimization: ~620 ms first settle, 140 ms recheck, 1050 ms max settle, 400 ms round pause. Target remains roughly 5–6 seconds per full 7-day round on a normally responsive page.
- Offer detection / notification path otherwise remains unchanged.


## Corrected v1.1.7.1 baseline rule
- Manual date intervention follows the stable v1.1.7 SelfEventFix behavior: manual D1–D7 click yields for ~3.5 s, then polling resumes.
- No new physical-touch heuristic was added to manual-date detection.
- Overlay Pause / Continue / Stop behavior is not rewritten.
- USER_PAUSE makes watchdog inert because watchdog only operates in RUNNING.
- Manual 3.5 s yield is also excluded from watchdog stall handling.
- D1–D7 polling remains the same structure, with only a light timing change (600 ms first settle, 140 ms recheck, 900 ms max settle, 300 ms round pause), targeting about 5–6 s/round on the tested page.
- Offer alert path is unchanged: any detected Offer triggers sound/vibration/notification and freezes scanning; no detail opening and no miles calculation.
- Amount / miles / $/mi inputs remain removed.


## Handled Offer resume fix
- When an Offer freezes scanning, manually handle it in DoorDash and press Continue.
- Continue marks that exact Offer fingerprint as handled.
- The same visible/stale card is ignored instead of freezing the scanner again.
- D1-D7 polling continues normally.
- If that Offer disappears or the fingerprint changes, suppression is released.
- A genuinely different/new Offer can alert and freeze normally.
- v1.1.7 manual-intervention, pause/resume, 3.5 s yield, overlay, and alert chain are otherwise unchanged.


## v1.1.7.6 Stable Rollback
- Rolled scanner/page gating back to the last phone-tested branch that actually ran: v1.1.7.1 HandledOfferFix.
- Removed the strict Offers-tab selected/checked gate introduced later, because DoorDash Compose may not expose that state reliably and it can block all scanning.
- Preserves the original v1.1.7 manual 3.5 s yield, overlay, Pause/Resume/Stop, D1-D7 loop, and handled-offer suppression.
- Adds only a lightweight DoorDash error-layer pause; it never auto-clicks Retry.
- Applies only a mild timing tune, not the aggressive v1.1.7.5 timings.
