package com.ddalertwatcher.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final String PREFS = "dd_alert_prefs";

    private SharedPreferences prefs;
    private TextView status;
    private final CheckBox[] scanDays = new CheckBox[7];
    private CheckBox sound;
    private CheckBox vibrate;
    private CheckBox keepAwake;
    private EditText runMinutes;
    private Spinner scanSpeed;
    private CheckBox dailyScheduleEnabled;
    private EditText dailyStart, dailyEnd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        requestNotificationPermission();
        setContentView(buildUi());
        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(30, 24, 30, 42);
        scroll.addView(root);

        root.addView(text("DD Alert Watcher · v1.1.7.10 Pure Alert", 21));
        TextView note = text("以 v1.1.7 扫描行为为基线：D1–D7 任一天出现任何 Offer，立即声音/震动/通知并冻结扫描；不打开详情、不计算 miles，最终 Claim 仍由你手动完成。", 14);
        note.setPadding(0, 8, 0, 10);
        root.addView(note);

        status = text("服务状态：读取中…", 15);
        status.setPadding(0, 8, 0, 10);
        root.addView(status);

        root.addView(button("打开无障碍设置", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        TextView scanTitle = text("扫描日期", 17);
        scanTitle.setPadding(0, 18, 0, 4);
        root.addView(scanTitle);

        LinearLayout days = new LinearLayout(this);
        days.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            CheckBox cb = new CheckBox(this);
            cb.setText("D" + (i + 1));
            cb.setChecked(prefs.getBoolean("scan_d" + (i + 1), true));
            scanDays[i] = cb;
            days.addView(cb, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        }
        root.addView(days);

        TextView speedTitle = text("扫描速度", 17);
        speedTitle.setPadding(0, 18, 0, 4);
        root.addView(speedTitle);
        scanSpeed = new Spinner(this);
        String[] speedLabels = new String[]{
                "标准（当前约 330ms/日期，默认）",
                "快速（约 270ms/日期，手动选择）",
                "稳定（约 420ms/日期）"
        };
        ArrayAdapter<String> speedAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, speedLabels);
        speedAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        scanSpeed.setAdapter(speedAdapter);
        String savedSpeed = prefs.getString("scan_speed_mode", "standard");
        scanSpeed.setSelection("fast".equals(savedSpeed) ? 1 : ("stable".equals(savedSpeed) ? 2 : 0));
        root.addView(scanSpeed);
        root.addView(text("标准模式保持目前约 330ms/日期；只有你主动选择“快速”才会进一步提速。这个设置只调整页面稳定等待，不改变 Offer 报警、人工介入或 Claim 方式。", 13));

        sound = checkbox("声音提醒", prefs.getBoolean("sound", true));
        vibrate = checkbox("震动提醒", prefs.getBoolean("vibrate", true));
        keepAwake = checkbox("监控时保持屏幕常亮", prefs.getBoolean("keep_awake", true));
        root.addView(sound);
        root.addView(vibrate);
        root.addView(keepAwake);

        TextView timerTitle = text("运行计时", 17);
        timerTitle.setPadding(0, 18, 0, 4);
        root.addView(timerTitle);
        runMinutes = new EditText(this);
        runMinutes.setHint("运行分钟数，0 = 不限时");
        runMinutes.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        runMinutes.setSingleLine(true);
        runMinutes.setText(String.valueOf(prefs.getInt("run_duration_minutes", 0)));
        root.addView(runMinutes);

        TextView scheduleTitle = text("每日定时运行（优先于运行计时）", 17);
        scheduleTitle.setPadding(0, 18, 0, 4);
        root.addView(scheduleTitle);
        dailyScheduleEnabled = checkbox("启用每日定时运行", prefs.getBoolean("daily_schedule_enabled", false));
        root.addView(dailyScheduleEnabled);
        dailyStart = new EditText(this);
        dailyStart.setSingleLine(true);
        dailyStart.setHint("开始时间 HH:mm，例如 09:00");
        dailyStart.setInputType(android.text.InputType.TYPE_CLASS_DATETIME);
        dailyStart.setText(prefs.getString("daily_schedule_start", "09:00"));
        root.addView(dailyStart);
        dailyEnd = new EditText(this);
        dailyEnd.setSingleLine(true);
        dailyEnd.setHint("结束时间 HH:mm，例如 11:00");
        dailyEnd.setInputType(android.text.InputType.TYPE_CLASS_DATETIME);
        dailyEnd.setText(prefs.getString("daily_schedule_end", "11:00"));
        root.addView(dailyEnd);
        root.addView(text("启用后，在设定时段内不受运行分钟数限制；人工暂停/停止及 Offer 冻结不自动解除。跨午夜时段支持。需保持无障碍服务连接，后台触发时间可能受系统限制。", 13));

        root.addView(button("保存设置", v -> saveSettings(true)));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(button("开始/继续", v -> {
            // Important: persist the value currently typed in "运行计时" before starting.
            // Previously, if the user changed 6 to another value but did not tap
            // "保存设置" first, the old saved value (for example 6) was reused.
            saveSettings(false);
            prefs.edit().putBoolean("daily_schedule_armed", dailyScheduleEnabled.isChecked()).apply();
            OfferAccessibilityService.requestResume(this);
            Toast.makeText(this, "已按当前设置开始/继续监控", Toast.LENGTH_SHORT).show();
            refreshStatus();
        }), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        actions.addView(button("人工暂停", v -> {
            OfferAccessibilityService.requestPause(this);
            Toast.makeText(this, "已人工暂停", Toast.LENGTH_SHORT).show();
            refreshStatus();
        }), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        root.addView(actions);

        root.addView(button("停止监控", v -> {
            OfferAccessibilityService.requestStop(this);
            Toast.makeText(this, "监控已停止", Toast.LENGTH_SHORT).show();
            refreshStatus();
        }));
        root.addView(button("测试 Offer 提醒", v -> OfferAccessibilityService.requestTestAlert(this)));
        root.addView(button("查看最近日志", v -> showLogs()));
        root.addView(button("清空日志/统计", v -> {
            prefs.edit().remove("logs").remove("stat_offer").remove("stat_stall").remove("stat_round").apply();
            Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show();
        }));

        TextView lite = text("Pure Alert：已移除金额、miles、$/mi 输入框和无关扫描日志；日期轮询、悬浮窗、暂停/继续沿用 v1.1.7 行为，仅修复人工检测/Watchdog并轻微提速；新增运行计时，0 分钟表示不限时。", 13);
        lite.setPadding(0, 18, 0, 0);
        root.addView(lite);
        return scroll;
    }

    private static boolean validClock(String v) {
        if (v == null || !v.matches("(?:[01][0-9]|2[0-3]):[0-5][0-9]")) return false;
        return true;
    }

    private void saveSettings(boolean showToast) {
        int minutes = 0;
        try {
            minutes = Integer.parseInt(runMinutes.getText().toString().trim());
        } catch (Exception ignored) {}
        if (minutes < 0) minutes = 0;
        if (minutes > 720) minutes = 720;

        String start = dailyStart.getText().toString().trim();
        String end = dailyEnd.getText().toString().trim();
        if (!validClock(start) || !validClock(end) || start.equals(end)) {
            Toast.makeText(this, "定时时间须为不同的 HH:mm，例如 09:00 和 11:00", Toast.LENGTH_LONG).show();
            return;
        }
        String speedMode = "standard";
        if (scanSpeed != null) {
            int speedPos = scanSpeed.getSelectedItemPosition();
            if (speedPos == 1) speedMode = "fast";
            else if (speedPos == 2) speedMode = "stable";
        }

        SharedPreferences.Editor e = prefs.edit()
                .putString("scan_speed_mode", speedMode)
                .putBoolean("daily_schedule_enabled", dailyScheduleEnabled.isChecked())
                .putBoolean("daily_schedule_armed", dailyScheduleEnabled.isChecked() && prefs.getBoolean("daily_schedule_armed", false))
                .putString("daily_schedule_start", start)
                .putString("daily_schedule_end", end)
                .putBoolean("sound", sound.isChecked())
                .putBoolean("vibrate", vibrate.isChecked())
                .putBoolean("keep_awake", keepAwake.isChecked())
                .putInt("run_duration_minutes", minutes);
        for (int i = 0; i < 7; i++) e.putBoolean("scan_d" + (i + 1), scanDays[i].isChecked());
        e.apply();
        OfferAccessibilityService.requestReload(this);
        if (showToast) {
            String speedText = scanSpeed == null ? "标准" :
                    (scanSpeed.getSelectedItemPosition() == 1 ? "快速" :
                    (scanSpeed.getSelectedItemPosition() == 2 ? "稳定" : "标准"));
            Toast.makeText(this, "设置已保存 · 扫描 " + speedText + " · 运行计时 " +
                    (minutes == 0 ? "不限时" : minutes + " 分钟"), Toast.LENGTH_SHORT).show();
        }
    }

    private void showLogs() {
        String logs = prefs.getString("logs", "暂无日志");
        int offers = prefs.getInt("stat_offer", 0);
        int stalls = prefs.getInt("stat_stall", 0);
        int rounds = prefs.getInt("stat_round", 0);
        new AlertDialog.Builder(this)
                .setTitle("关键日志 · Round " + rounds + " · Offer " + offers + " · Stall " + stalls)
                .setMessage(logs)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void refreshStatus() {
        if (status == null) return;
        status.setText("服务状态：" + prefs.getString("service_state", "未连接"));
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
    }

    private TextView text(String value, int sp) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        return t;
    }

    private CheckBox checkbox(String label, boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setChecked(checked);
        return c;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(listener);
        return b;
    }
}
