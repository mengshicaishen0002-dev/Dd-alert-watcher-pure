# DD Alert Watcher v1.1.7.1 Pure Alert

Baseline: v1.1.7 SelfEventFix behavior.

- Keeps the v1.1.7 D1–D7 polling flow and overlay controls.
- Keeps the v1.1.7 manual date-row handoff: about 3.5 seconds, then automatic scanning resumes.
- USER_PAUSE is a hard pause: pending polling is cancelled and watchdog is completely inert.
- A short 1.2 s guard after Pause prevents an adjacent/duplicate touch from being interpreted as Stop; the overlay UI itself is unchanged.
- Watchdog also ignores the intentional manual-yield window and a healthy date-settle window.
- Pure Alert: any Offer on any enabled D1–D7 date immediately triggers sound/vibration/notification and freezes scanning.
- No automatic Claim and no opening offer details to calculate miles.
- Amount / miles / $/mi inputs remain removed.
- Only a light timing optimization: ~620 ms first settle, 140 ms recheck, 1050 ms max settle, 400 ms round pause. Target remains roughly 5–6 seconds per full 7-day round on a normally responsive page.
- Offer detection / notification path otherwise remains unchanged.
