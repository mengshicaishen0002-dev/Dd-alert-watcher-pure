# DD Alert Watcher — Pure Alert v1.1.7.1 source

This is the **clean source project** for the Pure Alert branch going forward.

## Important provenance note

Earlier Pure Alert APKs were produced by patching/repacking an existing APK. A clean Android Studio/GitHub source repository was **not preserved**. This project is therefore a **clean-room reconstruction based on the verified behavior of v1.1.7**, not a byte-for-byte recovery of the original Java source.

Reference APK SHA-256 (v1.1.7):

`60a087f9328ef70f8d04e51b0f16821f197ccdae35c76e2a19db286ef821bb07`

From v1.1.7.1 onward, changes should be made in this source tree first and the source ZIP should be kept together with every APK build.

## Pure Alert behavior

- D1–D7 automatic date-page monitoring on the Dasher Schedule → Offers screen.
- Any detected Offer freezes automatic scanning immediately.
- Sound + vibration + Android notification on Offer detection.
- No automatic Claim.
- No automatic opening of details.
- No amount, miles, or \$/mi filtering.
- Manual Pause / Continue / Stop overlay.
- Manual pause is excluded from watchdog stall detection.
- DoorDash “Something went wrong / Retry” is treated as an error state: scanning stops, the user is notified, Retry is never auto-clicked.
- 18-second watchdog health check runs only while monitoring is actually RUNNING, within the allowed schedule, with Dasher Offers in the foreground.
- Watchdog can soft-restart the scanner after a real stall.
- Scheduled operation: start time, end time, weekdays, cross-midnight windows, and a temporary run duration.
- Scheduled start never launches DoorDash automatically; it notifies the user to open Dasher Offers.
- Offer alert requires the user to press Continue before scanning resumes.

## UI cleanup in v1.1.8

Removed from the Pure Alert UI:

- Minimum amount
- Maximum miles
- Minimum \$/mi
- Detail parsing controls
- Amount/miles filter statistics

## Build on GitHub

1. Create a new GitHub repository.
2. Upload the contents of this ZIP to the repository root.
3. Open **Actions → Build APK → Run workflow**.
4. When the run finishes, download the artifact named **DD-Alert-Watcher-Pure-v1.1.7.1-debug**.
5. The APK inside is `app-debug.apk`.

The workflow uses JDK 17, Gradle 8.9 and Android Gradle Plugin 8.7.3.

## Device calibration

The D1–D7 tap coordinates are intentionally preserved from the Samsung/Dasher layout already verified in the runtime logs:

- D1 x=101
- D2 x=236
- D3 x=371
- D4 x=506
- D5 x=641
- D6 x=776
- D7 x=911
- y=349

If DoorDash changes the Schedule UI, these should be moved into a calibration setting rather than patched in the APK.

## Safety / account handling

The app is designed as an alerting assistant. Final Claim remains manual. It does not contain anti-detection, fingerprint spoofing, or automatic Claim logic.
