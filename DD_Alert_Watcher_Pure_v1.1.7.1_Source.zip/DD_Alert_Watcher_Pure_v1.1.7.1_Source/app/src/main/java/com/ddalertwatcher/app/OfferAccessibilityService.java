package com.ddalertwatcher.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class OfferAccessibilityService extends AccessibilityService {
    private static volatile OfferAccessibilityService INSTANCE;

    private static final String DASHER_PACKAGE = "com.doordash.driverapp";
    private static final String PREFS = MainActivity.PREFS;
    private static final String CHANNEL_OFFER = "offer_alert";
    private static final String CHANNEL_MONITOR = "monitor_alert";

    // v1.1.7 SelfEventFix behavior: delayed Compose/self events were seen around 0.5-0.65 s.
    private static final long SELF_EVENT_GRACE_MS = 800L;
    private static final long USER_INTERACTION_HOLD_MS = 3500L;

    // Light speed-up only. Obvious empty pages settle around 0.65 s/date; ambiguous pages get up to ~1 s.
    private static final long FIRST_SETTLE_MS = 620L;
    private static final long SETTLE_RECHECK_MS = 140L;
    private static final long MAX_SETTLE_MS = 1050L;
    private static final long ROUND_PAUSE_MS = 400L;

    private static final long WATCHDOG_MS = 18_000L;
    private static final long WATCHDOG_TICK_MS = 2_000L;

    private enum State { RUNNING, USER_PAUSED, OFFER_FROZEN, STOPPED }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable scanRunnable = new Runnable() {
        @Override public void run() {
            scanScheduled = false;
            scanTick();
        }
    };
    private final Runnable watchdogRunnable = new Runnable() {
        @Override public void run() {
            try {
                processExternalCommand();

                // PauseFix: watchdog is completely inert outside RUNNING.
                // No stall accounting, no soft restart, no automatic resume while USER_PAUSED.
                if (state != State.RUNNING) return;

                ActiveContext ctx = activeContext();
                if (!ctx.dasher || !ctx.offersLike) {
                    // Time outside the Offers page must not count as a scanner stall.
                    resetWatchdogClock();
                    return;
                }

                long now = System.currentTimeMillis();

                // Stable v1.1.7 manual-yield semantics: while the user is inside the
                // 3.5 s date-row handoff, watchdog must not interpret the intentional
                // quiet period as a stalled scanner.
                if (now < manualHoldUntil) {
                    resetWatchdogClock();
                    return;
                }

                // A date gesture can legitimately be waiting for its settle confirmation.
                // Do not restart the scanner while that confirmation window is still healthy.
                if (settleDeadlineAt > 0L && now <= settleDeadlineAt + 1500L) {
                    return;
                }

                if (lastProgressAt > 0L && now - lastProgressAt >= WATCHDOG_MS) {
                    log("WATCHDOG_STALL idleMs=" + (now - lastProgressAt));
                    increment("stat_stall");
                    softRestartScanner();
                }
            } catch (Throwable t) {
                log("WATCHDOG_ERROR " + t.getClass().getSimpleName());
            } finally {
                handler.postDelayed(this, WATCHDOG_TICK_MS);
            }
        }
    };

    private SharedPreferences prefs;
    private WindowManager wm;
    private LinearLayout overlay;
    private TextView overlayStatus;

    private State state = State.STOPPED;
    private boolean scanScheduled = false;
    private int currentDateIndex = 0;
    private int roundScanned = 0;

    private int expectedAutoDateIndex = -1;
    private long expectedAutoDateEventUntil = 0L;
    private long manualHoldUntil = 0L;

    private long settleDeadlineAt = 0L;
    private String preClickFingerprint = "";
    private boolean stateChangeLogged = false;

    private long lastProgressAt = 0L;
    private long lastOfferAlertAt = 0L;
    private String lastOfferFingerprint = "";
    private long lastEventSnapshotAt = 0L;
    private static final long EVENT_SNAPSHOT_DEBOUNCE_MS = 90L;
    private long lastPhysicalTouchAt = 0L;
    private static final long MANUAL_TOUCH_WINDOW_MS = 900L;
    private static final long STOP_AFTER_PAUSE_GUARD_MS = 1200L;
    private long lastUserPauseAt = 0L;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannels();

        boolean stopped = prefs.getBoolean("user_stopped", false);
        state = stopped ? State.STOPPED : State.RUNNING;
        resetWatchdogClock();
        prefs.edit().putString("service_state", stopped ?
                "已停止 · v1.1.7.1 Pure Alert" : "已连接/运行中 · v1.1.7.1 Pure Alert").apply();
        log("SERVICE_CONNECTED pure-alert-v1.1.7.1 state=" + state.name());

        ensureOverlay();
        updateOverlay();
        handler.removeCallbacks(watchdogRunnable);
        handler.post(watchdogRunnable);
        if (state == State.RUNNING) scheduleScan(200L);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || prefs == null) return;
        processExternalCommand();

        CharSequence pkg = event.getPackageName();
        if (pkg == null || !DASHER_PACKAGE.contentEquals(pkg)) return;

        // Accessibility can emit bursts of nearly-identical Compose events. Building a full
        // snapshot for every callback wastes time and can make date polling feel sluggish.
        // Click/selected events bypass the debounce so manual-date protection remains immediate.
        int type = event.getEventType();
        long now = System.currentTimeMillis();
        if (type == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START) {
            lastPhysicalTouchAt = now;
            return;
        }
        boolean manualRelevant = type == AccessibilityEvent.TYPE_VIEW_CLICKED ||
                type == AccessibilityEvent.TYPE_VIEW_SELECTED;
        if (!manualRelevant && now - lastEventSnapshotAt < EVENT_SNAPSHOT_DEBOUNCE_MS) return;
        lastEventSnapshotAt = now;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        Snapshot snap = Snapshot.from(root);

        // Offer recognition stays live between polling ticks. It never auto-claims.
        if (state == State.RUNNING && snap.looksLikeOffersPage()) {
            if (detectAndAlertOffer(snap)) return;
            handleManualDateEvent(event);
        }
    }

    @Override public void onInterrupt() { log("SERVICE_INTERRUPTED"); }

    @Override
    public void onDestroy() {
        cancelPendingPolling();
        handler.removeCallbacks(watchdogRunnable);
        removeOverlay();
        if (prefs != null) prefs.edit().putString("service_state", "服务已停止").apply();
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }

    private void handleManualDateEvent(AccessibilityEvent event) {
        if (state != State.RUNNING) return;

        // Preserve the v1.1.7 manual-yield behavior, but do not mistake delayed
        // Compose TYPE_VIEW_SELECTED callbacks from our own date gesture for a human tap.
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_VIEW_CLICKED && type != AccessibilityEvent.TYPE_VIEW_SELECTED) return;

        AccessibilityNodeInfo src = event.getSource();
        int eventDate = dateIndexFromNode(src);
        if (eventDate < 0) return;

        long now = System.currentTimeMillis();
        if (expectedAutoDateIndex == eventDate && now <= expectedAutoDateEventUntil) {
            return; // self-generated date click
        }

        // Selected-only events are noisy on Compose. Require a recent physical touch for them.
        // Real TYPE_VIEW_CLICKED events remain accepted exactly as in the stable baseline.
        if (type == AccessibilityEvent.TYPE_VIEW_SELECTED &&
                now - lastPhysicalTouchAt > MANUAL_TOUCH_WINDOW_MS) {
            return;
        }

        manualHoldUntil = now + USER_INTERACTION_HOLD_MS;
        cancelPendingPolling();
        log("MANUAL_DATE D" + (eventDate + 1));
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        log("USER_INTERACTION_HOLD 3500ms");
        scheduleScan(USER_INTERACTION_HOLD_MS + 50L);
    }

    private void scanTick() {
        processExternalCommand();
        if (state != State.RUNNING) return;

        long now = System.currentTimeMillis();
        if (now < manualHoldUntil) {
            scheduleScan(manualHoldUntil - now + 50L);
            return;
        }

        ActiveContext ctx = activeContext();
        if (!ctx.dasher || !ctx.offersLike) {
            scheduleScan(700L);
            return;
        }

        Snapshot snap = ctx.snapshot;
        if (detectAndAlertOffer(snap)) return;

        if (settleDeadlineAt > 0L) {
            if (snap.emptyPage) {
                markProgress();
                finishDateAndAdvance();
                return;
            }

            String fp = snap.fingerprint();
            if (!stateChangeLogged && !fp.equals(preClickFingerprint)) {
                stateChangeLogged = true;
            }

            // We have already waited the first ~620 ms. If content changed and no Offer was
            // detected, that is sufficient page confirmation; move on without aggressive re-clicking.
            if (stateChangeLogged) {
                markProgress();
                finishDateAndAdvance();
                return;
            }

            if (now >= settleDeadlineAt) {
                markProgress();
                finishDateAndAdvance();
                return;
            }

            scheduleScan(Math.min(SETTLE_RECHECK_MS, Math.max(60L, settleDeadlineAt - now)));
            return;
        }

        int next = findNextEnabledDate(currentDateIndex);
        if (next < 0) {
            pauseByUser();
            log("NO_SCAN_DAYS_ENABLED");
            return;
        }
        currentDateIndex = next;
        tapDate(next, snap);
    }

    private void tapDate(final int index, Snapshot before) {
        if (state != State.RUNNING) return;

        // Same tested Samsung/Dasher date-row anchors used by the stable baseline.
        int width = getResources().getDisplayMetrics().widthPixels;
        float scale = width / 1080f;
        float x = (101f + 135f * index) * scale;
        float y = 349f * scale;

        preClickFingerprint = before == null ? "" : before.fingerprint();
        stateChangeLogged = false;
        expectedAutoDateIndex = index;
        long now = System.currentTimeMillis();
        expectedAutoDateEventUntil = now + SELF_EVENT_GRACE_MS;
        settleDeadlineAt = now + MAX_SETTLE_MS;

        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 55))
                .build();

        dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
                // PauseFix: a gesture callback arriving after USER_PAUSE cannot restart polling.
                if (state == State.RUNNING) scheduleScan(FIRST_SETTLE_MS);
            }

            @Override public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
                log("DATE_CLICK_FAIL D" + (index + 1));
                if (state == State.RUNNING) scheduleScan(350L);
            }
        }, null);
    }

    private void finishDateAndAdvance() {
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;

        roundScanned++;
        currentDateIndex = (currentDateIndex + 1) % 7;
        if (roundScanned >= enabledDateCount()) {
            roundScanned = 0;
            increment("stat_round");
            log("ROUND " + prefs.getInt("stat_round", 0) + " complete");
            scheduleScan(ROUND_PAUSE_MS);
        } else {
            scheduleScan(20L);
        }
    }

    private boolean detectAndAlertOffer(Snapshot snap) {
        if (state != State.RUNNING || snap == null) return false;
        if (!snap.offerCandidate || snap.emptyPage || snap.loadingLike) return false;

        String fp = snap.fingerprint();
        long now = System.currentTimeMillis();
        if (fp.equals(lastOfferFingerprint) && now - lastOfferAlertAt < 60_000L) {
            // Important: after the user handles an alert and taps Continue, a stale Compose
            // frame can remain briefly. Treating this duplicate as "handled=true" used to
            // exit scanTick without scheduling anything, eventually causing WATCHDOG_STALL.
            // Suppress the duplicate alert but keep scanning.
            return false;
        }

        lastOfferFingerprint = fp;
        lastOfferAlertAt = now;
        state = State.OFFER_FROZEN;
        cancelPendingPolling();
        increment("stat_offer");
        log("OFFER_FOUND D" + (currentDateIndex + 1));
        log("ALERT_SENT + SCAN_FROZEN");
        sendOfferAlert("发现 Offer！", "请立即查看 Dasher；扫描已冻结，处理后手动点继续。 ");
        prefs.edit().putString("service_state", "Offer 已发现/已冻结 · v1.1.7.1").apply();
        ensureOverlay();
        updateOverlay();
        return true;
    }

    private void pauseByUser() {
        if (state == State.STOPPED) return;
        if (state != State.USER_PAUSED) log("USER_PAUSE");

        state = State.USER_PAUSED;
        lastUserPauseAt = System.currentTimeMillis();
        // Hard pause: remove pending scan work and clear pre-pause settle/self-click state.
        cancelPendingPolling();
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;

        prefs.edit().putString("service_state", "人工暂停 · v1.1.7.1 Pure Alert").apply();
        ensureOverlay();
        updateOverlay();
    }

    private void resumeByUser() {
        // Remove any stale work first; then reset watchdog baseline before RUNNING resumes.
        cancelPendingPolling();
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        roundScanned = 0;

        prefs.edit().putBoolean("user_stopped", false).apply();
        state = State.RUNNING;
        resetWatchdogClock();
        log("USER_RESUME");
        prefs.edit().putString("service_state", "运行中 · v1.1.7.1 Pure Alert").apply();
        ensureOverlay();
        updateOverlay();
        scheduleScan(120L);
    }

    private void stopByUser() {
        long now = System.currentTimeMillis();
        // Do not let the same/adjacent touch that just paused monitoring immediately
        // fall through to Stop. The overlay layout and normal Stop behavior stay unchanged.
        if (lastUserPauseAt > 0L && now - lastUserPauseAt < STOP_AFTER_PAUSE_GUARD_MS) {
            log("STOP_IGNORED_AFTER_PAUSE");
            return;
        }
        if (state != State.STOPPED) log("USER_STOP overlay");
        state = State.STOPPED;
        cancelPendingPolling();
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        prefs.edit().putBoolean("user_stopped", true)
                .putString("service_state", "已停止 · v1.1.7.1 Pure Alert").apply();
        updateOverlay();
    }

    private void softRestartScanner() {
        if (state != State.RUNNING) return;
        cancelPendingPolling();
        settleDeadlineAt = 0L;
        expectedAutoDateIndex = -1;
        expectedAutoDateEventUntil = 0L;
        preClickFingerprint = "";
        stateChangeLogged = false;
        roundScanned = 0;
        resetWatchdogClock();
        scheduleScan(250L);
    }

    private void cancelPendingPolling() {
        handler.removeCallbacks(scanRunnable);
        scanScheduled = false;
    }

    private void scheduleScan(long delayMs) {
        // Central gate prevents any stale callback from rearming polling during pause/freeze/stop.
        if (state != State.RUNNING || scanScheduled) return;
        scanScheduled = true;
        handler.postDelayed(scanRunnable, Math.max(0L, delayMs));
    }

    private void processExternalCommand() {
        if (prefs == null) return;
        String cmd = prefs.getString("command", "");
        if (cmd == null || cmd.isEmpty()) return;
        prefs.edit().remove("command").apply();
        if ("pause".equals(cmd)) pauseByUser();
        else if ("resume".equals(cmd)) resumeByUser();
        else if ("stop".equals(cmd)) stopByUser();
        else if ("reload".equals(cmd)) {
            if (overlay != null) overlay.setKeepScreenOn(prefs.getBoolean("keep_awake", true));
            updateOverlay();
        }
    }

    private ActiveContext activeContext() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return new ActiveContext(false, false, Snapshot.empty());
            CharSequence pkg = root.getPackageName();
            boolean dasher = pkg != null && DASHER_PACKAGE.contentEquals(pkg);
            Snapshot snap = Snapshot.from(root);
            return new ActiveContext(dasher, dasher && snap.looksLikeOffersPage(), snap);
        } catch (Throwable t) {
            return new ActiveContext(false, false, Snapshot.empty());
        }
    }

    private int findNextEnabledDate(int start) {
        for (int i = 0; i < 7; i++) {
            int idx = (start + i) % 7;
            if (prefs.getBoolean("scan_d" + (idx + 1), true)) return idx;
        }
        return -1;
    }

    private int enabledDateCount() {
        int count = 0;
        for (int i = 0; i < 7; i++) if (prefs.getBoolean("scan_d" + (i + 1), true)) count++;
        return Math.max(1, count);
    }

    private int dateIndexFromNode(AccessibilityNodeInfo node) {
        if (node == null) return -1;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.isEmpty()) return -1;

        int width = getResources().getDisplayMetrics().widthPixels;
        float scale = width / 1080f;
        float expectedY = 349f * scale;
        float toleranceY = 120f * scale;
        if (Math.abs(r.centerY() - expectedY) > toleranceY) return -1;

        float first = 101f * scale;
        float step = 135f * scale;
        int idx = Math.round((r.centerX() - first) / step);
        return idx >= 0 && idx < 7 ? idx : -1;
    }

    private void ensureOverlay() {
        if (overlay != null || wm == null || state == State.STOPPED) return;
        try {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(12, 8, 12, 8);
            box.setBackgroundColor(Color.argb(205, 35, 35, 35));
            box.setKeepScreenOn(prefs.getBoolean("keep_awake", true));

            overlayStatus = new TextView(this);
            overlayStatus.setTextColor(Color.WHITE);
            overlayStatus.setTextSize(13);
            box.addView(overlayStatus);

            LinearLayout buttons = new LinearLayout(this);
            Button resume = new Button(this);
            resume.setText("继续");
            resume.setOnClickListener(v -> resumeByUser());
            Button pause = new Button(this);
            pause.setText("暂停");
            pause.setOnClickListener(v -> pauseByUser());
            Button stop = new Button(this);
            stop.setText("停止");
            stop.setOnClickListener(v -> stopByUser());
            buttons.addView(resume);
            buttons.addView(pause);
            buttons.addView(stop);
            box.addView(buttons);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            lp.y = 90;
            wm.addView(box, lp);
            overlay = box;
            log("OVERLAY_CREATED");
            updateOverlay();
        } catch (Throwable t) {
            log("OVERLAY_CREATE_FAIL " + t.getClass().getSimpleName());
        }
    }

    private void removeOverlay() {
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Throwable ignored) {}
        }
        overlay = null;
        overlayStatus = null;
    }

    private void updateOverlay() {
        if (state == State.STOPPED) {
            removeOverlay();
            return;
        }
        if (overlayStatus == null) return;
        String label;
        if (state == State.USER_PAUSED) label = "人工暂停";
        else if (state == State.OFFER_FROZEN) label = "Offer 已发现";
        else label = "运行中";
        overlayStatus.setText("DD Alert " + label + " | D" + (currentDateIndex + 1));
    }

    private void resetWatchdogClock() { lastProgressAt = System.currentTimeMillis(); }
    private void markProgress() { lastProgressAt = System.currentTimeMillis(); }

    private void sendOfferAlert(String title, String body) {
        if (prefs.getBoolean("vibrate", true)) vibrate();
        if (prefs.getBoolean("sound", true)) playSound();
        notifyMessage(CHANNEL_OFFER, title, body, 2001);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel offer = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
        offer.enableVibration(true);
        NotificationChannel monitor = new NotificationChannel(CHANNEL_MONITOR, "Monitor Alerts", NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(offer);
        nm.createNotificationChannel(monitor);
    }

    private void notifyMessage(String channel, String title, String body, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(this, channel)
                : new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(id, b.build());
    }

    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 350, 160, 350, 160, 650}, -1));
            else v.vibrate(new long[]{0, 350, 160, 350, 160, 650}, -1);
        } catch (Throwable ignored) {}
    }

    private void playSound() {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) {}
    }

    private void increment(String key) {
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply();
    }

    private void log(String msg) {
        if (prefs == null) return;
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = ts + " " + msg;
        String old = prefs.getString("logs", "");
        String all = line + (old.isEmpty() ? "" : "\n" + old);
        String[] lines = all.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(lines.length, 180); i++) {
            if (i > 0) sb.append('\n');
            sb.append(lines[i]);
        }
        prefs.edit().putString("logs", sb.toString()).apply();
    }

    public static void requestPause(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.pauseByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "pause").apply();
    }

    public static void requestResume(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.resumeByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("user_stopped", false)
                .putString("command", "resume")
                .putString("service_state", "等待无障碍服务连接后继续").apply();
    }

    public static void requestStop(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.stopByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("user_stopped", true)
                .putString("command", "stop")
                .putString("service_state", "已停止 · v1.1.7.1 Pure Alert").apply();
    }

    public static void requestReload(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) {
            if (s.overlay != null) s.overlay.setKeepScreenOn(s.prefs.getBoolean("keep_awake", true));
            s.updateOverlay();
            return;
        }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "reload").apply();
    }

    public static void requestTestAlert(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }
        try {
            Vibrator v = (Vibrator) c.getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 250, 120, 450}, -1));
                else v.vibrate(new long[]{0, 250, 120, 450}, -1);
            }
            Ringtone r = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            if (r != null) r.play();
        } catch (Throwable ignored) {}
        Intent intent = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(c, CHANNEL_OFFER)
                : new android.app.Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("测试：发现 Offer！")
                .setContentText("声音、震动和系统通知正常。")
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(2099, b.build());
    }

    private static class ActiveContext {
        final boolean dasher;
        final boolean offersLike;
        final Snapshot snapshot;
        ActiveContext(boolean dasher, boolean offersLike, Snapshot snapshot) {
            this.dasher = dasher;
            this.offersLike = offersLike;
            this.snapshot = snapshot;
        }
    }

    private static class Snapshot {
        final List<String> texts = new ArrayList<>();
        final List<Node> nodes = new ArrayList<>();
        boolean emptyPage;
        boolean loadingLike;
        boolean offerCandidate;
        String offerEvidence = "none";

        static Snapshot empty() { return new Snapshot(); }

        static Snapshot from(AccessibilityNodeInfo root) {
            Snapshot s = new Snapshot();
            if (root == null) return s;
            ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
            q.add(root);
            int guard = 0;
            while (!q.isEmpty() && guard++ < 1200) {
                AccessibilityNodeInfo n = q.removeFirst();
                String t = safe(n.getText());
                String d = safe(n.getContentDescription());
                Rect r = new Rect();
                n.getBoundsInScreen(r);
                if (!t.isEmpty()) s.texts.add(t);
                if (!d.isEmpty() && !d.equals(t)) s.texts.add(d);
                s.nodes.add(new Node(t, d, n.isClickable(), r));
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) q.addLast(c);
                }
            }
            s.classify();
            return s;
        }

        void classify() {
            String all = String.join(" \n ", texts).toLowerCase(Locale.US);
            emptyPage = containsAny(all,
                    "nothing available to schedule",
                    "there's nothing available",
                    "there is nothing available",
                    "no offers available");
            loadingLike = containsAny(all, "loading", "please wait");
            if (emptyPage || loadingLike) return;

            // Keep the same broad evidence classes used by the existing alert chain:
            // money, Claim/Acknowledge, or delivery-card structure on the Offers page.
            boolean offersContext = looksLikeOffersPage();
            boolean money = all.matches("(?s).*\\$\\s*\\d+(?:\\.\\d{1,2})?.*");
            boolean claim = containsAny(all, "claim and schedule", "claim", "acknowledge", "confirm claim", "view delivery");
            boolean deliveryWords = containsAny(all, "pickup", "dropoff", "delivery", "catering", "customer", "miles", " mi ", "deliver by", "pickup by");
            int clickableContent = 0;
            for (Node n : nodes) if (n.clickable && (!n.text.isEmpty() || !n.desc.isEmpty())) clickableContent++;

            if (offersContext && claim) { offerCandidate = true; offerEvidence = "claim"; }
            else if (offersContext && money && deliveryWords) { offerCandidate = true; offerEvidence = "money+delivery"; }
            else if (offersContext && deliveryWords && clickableContent >= 3) { offerCandidate = true; offerEvidence = "structure"; }
        }

        boolean looksLikeOffersPage() {
            String all = String.join(" ", texts).toLowerCase(Locale.US);
            return all.contains("offers") ||
                    all.contains("available to schedule today") ||
                    all.contains("nothing available to schedule") ||
                    all.contains("claim and schedule");
        }

        String fingerprint() {
            StringBuilder sb = new StringBuilder();
            int n = Math.min(texts.size(), 30);
            for (int i = 0; i < n; i++) sb.append(texts.get(i)).append('|');
            return Integer.toHexString(sb.toString().hashCode());
        }

        static String safe(CharSequence c) { return c == null ? "" : c.toString().trim(); }
        static boolean containsAny(String s, String... parts) {
            for (String p : parts) if (s.contains(p)) return true;
            return false;
        }
    }

    private static class Node {
        final String text;
        final String desc;
        final boolean clickable;
        final Rect bounds;
        Node(String text, String desc, boolean clickable, Rect bounds) {
            this.text = text;
            this.desc = desc;
            this.clickable = clickable;
            this.bounds = new Rect(bounds);
        }
    }
}
