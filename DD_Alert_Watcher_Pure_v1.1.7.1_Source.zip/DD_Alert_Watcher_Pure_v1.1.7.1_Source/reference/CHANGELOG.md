# Changelog

## v1.1.7.1 — v1.1.7 behavior-preserving Pure Alert fix
- Preserved the v1.1.7 manual intervention model and D1–D7 automatic rotation.
- Manual date click/selection yields to the user for ~3.5 seconds.
- Content-change/scroll accessibility events no longer masquerade as manual date input.
- USER_PAUSED is fully excluded from watchdog stall handling; Pause cannot become Stop.
- Watchdog also ignores the active 3.5-second manual-yield window.
- Watchdog progress now comes from real scanner progress instead of arbitrary DoorDash accessibility events.
- Soft watchdog restart first cancels any stale pending scan runnable.
- Pure Alert still detects any Offer, immediately freezes scanning, alerts by sound/vibration/notification, and never opens detail to calculate miles.
- Light scan timing optimization only: empty-page cycle targets roughly 5–6 seconds per D1–D7 round on the verified layout.
- Removed repetitive date/round debug log noise; retained manual, Offer, error, watchdog, pause/resume logs.
- Amount/miles/$/mi controls remain absent.

## v1.1.8 — Scheduled Guard source baseline
- Created first clean, maintainable Android source project for Pure Alert branch.
- Added schedule start/end times, weekday selection, cross-midnight support, temporary run duration.
- Fixed watchdog state gating so USER_PAUSED / SCHEDULE_WAIT / SCHEDULE_ENDED / OFFER_FROZEN / ERROR_PAUSED cannot generate WATCHDOG_STALL.
- Added Retry/error-layer notification and safe pause.
- Kept 18-second real-stall watchdog with soft scanner restart.
- Kept 800 ms self-event suppression for delayed DoorDash Compose events.
- Removed amount/miles/\$/mi/detail parsing UI and filtering from Pure Alert.
- Offer detection freezes scan and requires explicit user Continue.
