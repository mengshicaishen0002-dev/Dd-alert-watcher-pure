package com.ddalertwatcher.app;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    static final String PREFS = "dd_alert_prefs";
    private SharedPreferences prefs;
    private TextView status;
    private final CheckBox[] scanDays = new CheckBox[7];
    private final CheckBox[] scheduleDays = new CheckBox[7];
    private CheckBox sound, vibrate, keepAwake, scheduleEnabled;
    private Button startTime, endTime;
    private EditText tempMinutes;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        requestNotificationPermission();
        setContentView(buildUi());
        refreshStatus();
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }

    @Override public void onBackPressed() {
        // User asked that actually exiting the app must not leave a dead overlay behind.
        OfferAccessibilityService.requestStop(this);
        finish();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 22, 28, 42);
        scroll.addView(root);

        root.addView(text("DD Alert Watcher · Stable Core v1.1.12", 21));
        root.addView(text("以 v1.1.7 扫描行为为基线：D1–D7 轮询，发现任意真实 Offer 立即提醒并冻结；最终 Claim 只由人工处理。", 14));

        status = text("服务状态：读取中…", 16);
        status.setPadding(0, 14, 0, 12);
        root.addView(status);
        root.addView(button("打开无障碍设置", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        root.addView(section("扫描日期"));
        LinearLayout drow = new LinearLayout(this); drow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            CheckBox cb = new CheckBox(this); cb.setText("D" + (i + 1)); cb.setChecked(prefs.getBoolean("scan_d" + (i + 1), true));
            scanDays[i] = cb; drow.addView(cb, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        }
        root.addView(drow);
        sound = checkbox("声音提醒", prefs.getBoolean("sound", true));
        vibrate = checkbox("震动提醒", prefs.getBoolean("vibrate", true));
        keepAwake = checkbox("监控时保持屏幕常亮", prefs.getBoolean("keep_awake", true));
        root.addView(sound); root.addView(vibrate); root.addView(keepAwake);

        root.addView(section("定时运行"));
        scheduleEnabled = checkbox("启用时间表", prefs.getBoolean("schedule_enabled", false));
        root.addView(scheduleEnabled);
        LinearLayout tr = new LinearLayout(this); tr.setOrientation(LinearLayout.HORIZONTAL);
        startTime = button("开始 " + prefs.getString("schedule_start", "10:30"), v -> pickTime(true));
        endTime = button("结束 " + prefs.getString("schedule_end", "21:30"), v -> pickTime(false));
        tr.addView(startTime, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        tr.addView(endTime, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        root.addView(tr);
        LinearLayout wr = new LinearLayout(this); wr.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"一","二","三","四","五","六","日"};
        for (int i = 0; i < 7; i++) {
            CheckBox cb = new CheckBox(this); cb.setText(names[i]); cb.setChecked(prefs.getBoolean("schedule_day_" + i, true));
            scheduleDays[i] = cb; wr.addView(cb, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        }
        root.addView(wr);
        root.addView(text("支持跨午夜，例如 22:00 → 02:00；到点不会自动打开 DoorDash。", 13));

        LinearLayout temp = new LinearLayout(this); temp.setOrientation(LinearLayout.HORIZONTAL);
        tempMinutes = new EditText(this); tempMinutes.setHint("临时运行分钟"); tempMinutes.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        temp.addView(tempMinutes, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        temp.addView(button("临时运行", v -> startTempRun()));
        root.addView(temp);

        root.addView(button("保存设置", v -> saveSettings()));
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(button("开始/继续", v -> startMonitor()), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        actions.addView(button("暂停", v -> OfferAccessibilityService.requestPause(this)), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        actions.addView(button("停止", v -> OfferAccessibilityService.requestStop(this)), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        root.addView(actions);
        root.addView(button("测试 Offer 提醒", v -> OfferAccessibilityService.requestTestAlert(this)));
        root.addView(button("查看关键日志", v -> showLogs()));
        root.addView(button("清空日志/统计", v -> {
            prefs.edit().remove("logs").remove("stat_offer").remove("stat_error").remove("stat_stall").remove("stat_round").apply();
            Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show();
        }));

        TextView note = text("已去掉金额、里程、$/mi、详情解析及逐日期噪音日志。Home/切到 Dasher 会继续监控；按返回键退出或从最近任务划掉本 App，会停止监控并关闭悬浮窗。", 13);
        note.setPadding(0, 18, 0, 0); root.addView(note);
        return scroll;
    }

    private void saveSettings() {
        SharedPreferences.Editor e = prefs.edit();
        e.putBoolean("sound", sound.isChecked()).putBoolean("vibrate", vibrate.isChecked()).putBoolean("keep_awake", keepAwake.isChecked());
        e.putBoolean("schedule_enabled", scheduleEnabled.isChecked());
        for (int i = 0; i < 7; i++) {
            e.putBoolean("scan_d" + (i + 1), scanDays[i].isChecked());
            e.putBoolean("schedule_day_" + i, scheduleDays[i].isChecked());
        }
        e.apply();
        OfferAccessibilityService.requestReload(this);
        Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
    }

    private void startMonitor() {
        saveSettings();
        prefs.edit().putBoolean("user_stopped", false).apply();
        if (!OfferAccessibilityService.isServiceConnected()) {
            Toast.makeText(this, "请先开启 DD Alert Watcher 无障碍服务", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        OfferAccessibilityService.requestResume(this);
        refreshStatus();
    }

    private void startTempRun() {
        String s = tempMinutes.getText().toString().trim();
        try {
            long m = Long.parseLong(s);
            if (m < 1 || m > 1440) throw new NumberFormatException();
            prefs.edit().putLong("temp_until", System.currentTimeMillis() + m * 60_000L).putBoolean("user_stopped", false).apply();
            OfferAccessibilityService.requestResume(this);
            Toast.makeText(this, "临时运行 " + m + " 分钟", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) { Toast.makeText(this, "请输入 1–1440 分钟", Toast.LENGTH_SHORT).show(); }
    }

    private void pickTime(boolean start) {
        String key = start ? "schedule_start" : "schedule_end";
        String cur = prefs.getString(key, start ? "10:30" : "21:30");
        String[] p = cur.split(":");
        int h = Integer.parseInt(p[0]), m = Integer.parseInt(p[1]);
        new TimePickerDialog(this, (view, hour, minute) -> {
            String v = String.format(Locale.US, "%02d:%02d", hour, minute);
            prefs.edit().putString(key, v).apply();
            if (start) startTime.setText("开始 " + v); else endTime.setText("结束 " + v);
            OfferAccessibilityService.requestReload(this);
        }, h, m, true).show();
    }

    private void showLogs() {
        String logs = prefs.getString("logs", "暂无关键日志");
        int rounds = prefs.getInt("stat_round", 0), offers = prefs.getInt("stat_offer", 0), errors = prefs.getInt("stat_error", 0), stalls = prefs.getInt("stat_stall", 0);
        new AlertDialog.Builder(this).setTitle("关键日志 · Round " + rounds + " · Offer " + offers + " · Error " + errors + " · Stall " + stalls)
                .setMessage(logs).setPositiveButton("关闭", null).show();
    }

    private void refreshStatus() {
        if (status == null) return;
        boolean enabled = isAccessibilityEnabled(), connected = OfferAccessibilityService.isServiceConnected();
        String actual = connected ? "无障碍已连接" : (enabled ? "无障碍已启用，等待服务连接" : "无障碍未启用");
        status.setText("服务状态：" + prefs.getString("service_state", "未连接") + "\n" + actual);
    }

    private boolean isAccessibilityEnabled() {
        try {
            AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            if (am == null) return false;
            for (AccessibilityServiceInfo info : am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
                if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null &&
                        getPackageName().equals(info.getResolveInfo().serviceInfo.packageName) &&
                        info.getResolveInfo().serviceInfo.name != null && info.getResolveInfo().serviceInfo.name.contains("OfferAccessibilityService")) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
    }

    private TextView section(String s) { TextView t = text(s, 18); t.setPadding(0, 20, 0, 6); return t; }
    private TextView text(String s, int sp) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); return t; }
    private CheckBox checkbox(String s, boolean checked) { CheckBox c = new CheckBox(this); c.setText(s); c.setChecked(checked); return c; }
    private Button button(String s, View.OnClickListener l) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setOnClickListener(l); return b; }
}
