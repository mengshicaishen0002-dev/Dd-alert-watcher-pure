# DD Alert Watcher Pure v1.1.12

Baseline: v1.1.7 stable D1-D7 scan behavior.

## v1.1.12
- Fixes false watchdog stall seen after service startup / control-state resets.
- Watchdog is active only after the scanner has actually started, and never while a date is settling or during manual hold.
- Repeated Resume clicks are idempotent and debounced; they no longer reset a healthy scanner or spam USER_RESUME logs.
- Pause remains a hard pause: pending scan callback is cancelled and watchdog cannot restart it.
- Resume resets scanner/watchdog cleanly before polling again.
- Safe speed trim: first settle 500 ms, follow-up 260 ms, max settle 1400 ms, round pause 300 ms, inter-date gap 20 ms.
- Offer detection / freeze behavior remains unchanged; final Claim is still manual.
