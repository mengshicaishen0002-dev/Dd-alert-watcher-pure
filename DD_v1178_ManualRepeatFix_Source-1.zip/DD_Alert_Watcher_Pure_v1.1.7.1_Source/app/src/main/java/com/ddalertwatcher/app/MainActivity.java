package com.ddalertwatcher.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final String PREFS = "dd_alert_prefs";

    private SharedPreferences prefs;
    private TextView status;
    private final CheckBox[] scanDays = new CheckBox[7];
    private CheckBox sound;
    private CheckBox vibrate;
    private CheckBox keepAwake;
    private EditText runMinutes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        requestNotificationPermission();
        setContentView(buildUi());
        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(30, 24, 30, 42);
        scroll.addView(root);

        root.addView(text("DD Alert Watcher · v1.1.7.8 Pure Alert", 21));
        TextView note = text("以 v1.1.7 扫描行为为基线：D1–D7 任一天出现任何 Offer，立即声音/震动/通知并冻结扫描；不打开详情、不计算 miles，最终 Claim 仍由你手动完成。", 14);
        note.setPadding(0, 8, 0, 10);
        root.addView(note);

        status = text("服务状态：读取中…", 15);
        status.setPadding(0, 8, 0, 10);
        root.addView(status);

        root.addView(button("打开无障碍设置", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        TextView scanTitle = text("扫描日期", 17);
        scanTitle.setPadding(0, 18, 0, 4);
        root.addView(scanTitle);

        LinearLayout days = new LinearLayout(this);
        days.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            CheckBox cb = new CheckBox(this);
            cb.setText("D" + (i + 1));
            cb.setChecked(prefs.getBoolean("scan_d" + (i + 1), true));
            scanDays[i] = cb;
            days.addView(cb, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        }
        root.addView(days);

        sound = checkbox("声音提醒", prefs.getBoolean("sound", true));
        vibrate = checkbox("震动提醒", prefs.getBoolean("vibrate", true));
        keepAwake = checkbox("监控时保持屏幕常亮", prefs.getBoolean("keep_awake", true));
        root.addView(sound);
        root.addView(vibrate);
        root.addView(keepAwake);

        TextView timerTitle = text("运行计时", 17);
        timerTitle.setPadding(0, 18, 0, 4);
        root.addView(timerTitle);
        runMinutes = new EditText(this);
        runMinutes.setHint("运行分钟数，0 = 不限时");
        runMinutes.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        runMinutes.setSingleLine(true);
        runMinutes.setText(String.valueOf(prefs.getInt("run_duration_minutes", 0)));
        root.addView(runMinutes);

        root.addView(button("保存设置", v -> saveSettings()));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(button("开始/继续", v -> {
            OfferAccessibilityService.requestResume(this);
            Toast.makeText(this, "已请求开始/继续监控", Toast.LENGTH_SHORT).show();
            refreshStatus();
        }), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        actions.addView(button("人工暂停", v -> {
            OfferAccessibilityService.requestPause(this);
            Toast.makeText(this, "已人工暂停", Toast.LENGTH_SHORT).show();
            refreshStatus();
        }), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        root.addView(actions);

        root.addView(button("停止监控", v -> {
            OfferAccessibilityService.requestStop(this);
            Toast.makeText(this, "监控已停止", Toast.LENGTH_SHORT).show();
            refreshStatus();
        }));
        root.addView(button("测试 Offer 提醒", v -> OfferAccessibilityService.requestTestAlert(this)));
        root.addView(button("查看最近日志", v -> showLogs()));
        root.addView(button("清空日志/统计", v -> {
            prefs.edit().remove("logs").remove("stat_offer").remove("stat_stall").remove("stat_round").apply();
            Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show();
        }));

        TextView lite = text("Pure Alert：已移除金额、miles、$/mi 输入框和无关扫描日志；日期轮询、悬浮窗、暂停/继续沿用 v1.1.7 行为，仅修复人工检测/Watchdog并轻微提速；新增运行计时，0 分钟表示不限时。", 13);
        lite.setPadding(0, 18, 0, 0);
        root.addView(lite);
        return scroll;
    }

    private void saveSettings() {
        int minutes = 0;
        try {
            minutes = Integer.parseInt(runMinutes.getText().toString().trim());
        } catch (Exception ignored) {}
        if (minutes < 0) minutes = 0;
        if (minutes > 720) minutes = 720;

        SharedPreferences.Editor e = prefs.edit()
                .putBoolean("sound", sound.isChecked())
                .putBoolean("vibrate", vibrate.isChecked())
                .putBoolean("keep_awake", keepAwake.isChecked())
                .putInt("run_duration_minutes", minutes);
        for (int i = 0; i < 7; i++) e.putBoolean("scan_d" + (i + 1), scanDays[i].isChecked());
        e.apply();
        OfferAccessibilityService.requestReload(this);
        Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
    }

    private void showLogs() {
        String logs = prefs.getString("logs", "暂无日志");
        int offers = prefs.getInt("stat_offer", 0);
        int stalls = prefs.getInt("stat_stall", 0);
        int rounds = prefs.getInt("stat_round", 0);
        new AlertDialog.Builder(this)
                .setTitle("关键日志 · Round " + rounds + " · Offer " + offers + " · Stall " + stalls)
                .setMessage(logs)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void refreshStatus() {
        if (status == null) return;
        status.setText("服务状态：" + prefs.getString("service_state", "未连接"));
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
    }

    private TextView text(String value, int sp) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        return t;
    }

    private CheckBox checkbox(String label, boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setChecked(checked);
        return c;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(listener);
        return b;
    }
}
