# DD Alert Watcher — Stable117Rebase v1.1.11

This branch deliberately resets the runtime architecture around the field-proven `DD_Alert_Watcher_Pure_v1.1.7_SelfEventFix.apk` baseline.

Baseline SHA-256: `60a087f9328ef70f8d04e51b0f16821f197ccdae35c76e2a19db286ef821bb07`.

## Rule for this branch

The D1–D7 scanner is the baseline. Schedule, watchdog, overlay controls and exit behavior are wrappers around it; they must not participate in date selection or offer detection.

## v1.1.11 changes over the v1.1.7 behavior

- Keeps the proven Samsung D1–D7 coordinates (`101 + 135*n`, `y=349`) and bounded settle loop.
- Keeps self-event suppression; only a real `TYPE_VIEW_CLICKED` in the exact date row can trigger manual-yield. Content/selected/scroll events cannot pause the scanner.
- Removes the broad manual-date geometry that caused v1.1.10 to misclassify ordinary events as D5.
- Any Offer detection is conservative: visible `$pay` or visible Claim/Acknowledge control in the Offers content area. The old structural heuristic is removed to prevent false `Offer 1` counts on an empty page.
- Offer -> sound/vibration/notification -> freeze until explicit Resume.
- Schedule supports weekdays, cross-midnight windows and temporary run.
- Schedule cannot auto-resume USER_PAUSED / OFFER_FROZEN / ERROR_PAUSED.
- Watchdog is active only while RUNNING + schedule allowed + Dasher Offers foreground.
- Overlay drag is header-only. Resume/Pause/Stop buttons retain their click handlers.
- Stop removes the overlay immediately and cannot be undone by the watchdog.
- Android Back exits and stops monitoring; Home/app-switch keeps monitoring. Swiping the task away also requests Stop.
- No amount/miles/$/mi/detail filter UI; final Claim remains manual.
