# DD Alert Watcher Pure — Stable Core v1.1.11

This release intentionally returns to the **v1.1.7 field-proven scan behavior** and avoids the v1.1.8–v1.1.10 scan-state rewrites.

## Kept from the v1.1.7 behavior baseline
- Fixed Samsung D1–D7 date-row scan order/coordinates.
- 800 ms self-generated date-event suppression.
- 3.5 s user/manual date-control yield.
- Bounded slow-load settle guard.
- Any real Offer freezes automatic date scanning immediately.
- Final Claim remains manual.

## Only targeted additions/changes
- Slightly shorter settle and round waits; no aggressive high-frequency loop.
- Pure Alert UI only: dates, sound, vibration, keep-awake, schedule, controls, test alert and compact logs.
- Removed amount/miles/$-per-mile/detail/filter UI.
- Compact critical-event log instead of per-date noise.
- Overlay buttons receive click events directly; only the header is draggable.
- Stop removes the overlay immediately.
- Back-to-exit and removing the app from Recents stop monitoring and remove the overlay; Home/app switching does not.
- Schedule supports weekdays, start/end, cross-midnight and temporary run minutes.
- Schedule never auto-launches DoorDash.

## Regression fixes from field logs
- Do not classify `TYPE_WINDOW_CONTENT_CHANGED` as a manual date tap.
- Suppress all delayed date-row events inside the v1.1.7 self-event window, not only the event whose mapped D-index matches the last auto tap.
- Offers-page recognition no longer requires extra `Schedule`/`Dash` text that some DoorDash builds do not expose.
- Offer detection no longer uses broad generic clickable-structure heuristics; it requires real pay/Claim evidence in the Offers content region, preventing the false `Offer 1` seen in v1.1.10.

Reference v1.1.7 APK SHA-256:
`60a087f9328ef70f8d04e51b0f16821f197ccdae35c76e2a19db286ef821bb07`
