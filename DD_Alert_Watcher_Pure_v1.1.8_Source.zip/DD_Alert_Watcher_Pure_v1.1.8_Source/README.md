# DD Alert Watcher v1.1.7 Core R1

This build deliberately returns to the verified v1.1.7 scanner core.

## What is frozen

`reference/v1.1.7/classes2.dex` is copied byte-for-byte from the verified v1.1.7 APK. The build checks its SHA-256 before packaging and verifies the packaged `classes2.dex` again afterward. The scanner, D1-D7 cycle logic, self-event filtering, date timing, offer handling, watchdog and original v1.1.7 control overlay are therefore not recompiled or rewritten in R1.

Core SHA-256: `f10d646a68f4fc77e65058f7a8261d94ac0f29249a4c0f393e157c47f9b40b0d`

## R1 changes outside the scanner core

- Replaces the old launcher UI with a small controller UI.
- Removes amount/miles/$/mi/date-wait/observe/stats/diagnostic controls from the visible UI.
- Shows only key logs; verbose scan logs remain in the original log file so scanner code is untouched.
- Adds daily start/end run time, including cross-midnight windows.
- Outside the configured run time it writes `enabled=false`; the original v1.1.7 watchdog removes its own overlay. At start it writes `enabled=true, paused=false`; the original watchdog restarts scanning when Dasher Offers is foreground.
- Back button asks whether to stop monitoring together or only close the controller UI.

## Important

Final Claim remains manual. The controller does not add anti-detection or automatic Claim logic.
