# DD Alert Watcher Pure v1.1.8 — PauseFix LiteUI

Behavioral baseline: v1.1.7 SelfEventFix, with v1.3.6.3 safe_offer_alert used as a reference for the scanning/offer-alert chain.

This revision intentionally keeps the architecture small and stable. It fixes manual pause/watchdog interaction, cancels pending polling work on pause, resets the watchdog baseline on resume, keeps the 3500 ms manual date-row hold, and lightly speeds empty-date polling. The visible UI removes amount/miles/$-per-mile controls; offer detection and alerting remain in the service.
