# DD Alert Watcher — Pure Alert v1.1.11 StableSchedule

This build deliberately returns to the validated v1.1.7 scan behavior as the design baseline and adds scheduling as an outer guard, instead of continuing the v1.1.9/v1.1.10 scan rewrites.

## Core behavior
- Scans selected D1–D7 date tabs on DoorDash Dasher > Schedule > Offers.
- Any strongly confirmed Offer signal triggers sound/vibration/notification and freezes scanning. Final Claim is always manual.
- Preserves the v1.1.7-style delayed self-event suppression window so automatic date taps are not misread as user taps.
- Manual-date detection only accepts explicit click/selection events from the tested date-row geometry, eliminating the broad false-positive detector used in v1.1.10.
- No amount threshold, mileage threshold, $/mi filtering, detail opening, Back, or Claim automation.

## Run-time limits
- Optional weekly schedule with configurable start/end time.
- Cross-midnight windows are supported.
- Temporary hard session limit in minutes; when the time expires, scanning stays ended until the user explicitly resumes.
- Schedule start never opens DoorDash automatically; it notifies the user to open Dasher Offers.
- Manual pause, Offer freeze, error pause, and explicit Stop are never auto-resumed by the schedule.

## Health / UI
- Watchdog runs only while RUNNING + allowed time + Dasher Offers is actually foreground.
- DoorDash Retry/error layer pauses monitoring and alerts.
- Overlay buttons use a non-draggable button area; only the header can be dragged.
- Stop removes the overlay and persists the stopped state.
- False Offer heuristic based only on generic page structure was removed; positive evidence is Claim or money plus distance/pickup/catering, confirmed on a second snapshot.
