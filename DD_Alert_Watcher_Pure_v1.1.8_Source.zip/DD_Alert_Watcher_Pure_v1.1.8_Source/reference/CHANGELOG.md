## v1.1.11 — Stable Core
- Return scanner behavior to v1.1.7 baseline model.
- Keep fixed D1–D7 Samsung scan path and v1.1.7 self-event/manual-yield behavior.
- Fix v1.1.10 false manual holds by ignoring content-change events and all date-row self events within 800 ms.
- Remove broad structure-only Offer detection that caused false Offer count.
- Slightly faster settle/round cadence without aggressive polling.
- Rebuild overlay lifecycle: header-only drag, functional Continue/Pause/Stop, Stop removes overlay.
- Exit via Back or Recents removal stops monitoring; Home/switching apps preserves it.
- Add weekly/cross-midnight/temporary scheduling as an outer gate, not a scanner rewrite.
- Remove unused Pure Alert filters and verbose per-date logs.
