# Stable117Rebase changelog

## v1.1.11

Rebased the runtime design around the verified v1.1.7 scanner behavior instead of continuing the v1.1.8–v1.1.10 reconstruction chain.

Key invariants:
- scanner core owns date cursor + settle only;
- external schedule never synthesizes user interaction;
- only TYPE_VIEW_CLICKED can be considered manual date input;
- all date-like events inside self-event grace are ignored;
- visible money/claim is required for Any-Offer confirmation;
- Stop is terminal until explicit Start/Resume;
- watchdog cannot run in manual pause, schedule wait, offer freeze, error pause or stop.
