## v1.1.9
- Fix overlay button touch interception.
- Stop now hides overlay and persists stopped state.
- Resume restores overlay and resets watchdog.
- Add main UI stop/close-overlay control.

# Changelog

## v1.1.8 — Scheduled Guard source baseline
- Created first clean, maintainable Android source project for Pure Alert branch.
- Added schedule start/end times, weekday selection, cross-midnight support, temporary run duration.
- Fixed watchdog state gating so USER_PAUSED / SCHEDULE_WAIT / SCHEDULE_ENDED / OFFER_FROZEN / ERROR_PAUSED cannot generate WATCHDOG_STALL.
- Added Retry/error-layer notification and safe pause.
- Kept 18-second real-stall watchdog with soft scanner restart.
- Kept 800 ms self-event suppression for delayed DoorDash Compose events.
- Removed amount/miles/\$/mi/detail parsing UI and filtering from Pure Alert.
- Offer detection freezes scan and requires explicit user Continue.
