# v1.1.11 StableCore

Built by stepping back to the v1.1.7-style stable scan cadence and applying only targeted fixes.

- Restored conservative date settle/recheck/round timing (650/160/1000/450 ms).
- Manual-date detection now ignores TYPE_VIEW_SELECTED and only accepts a clickable date-chip CLICKED event.
- Added a 1300 ms global self-event suppression window after every automatic date gesture, regardless of which chip Compose reports as the source.
- Rejects wide row/container nodes as manual date clicks.
- Removed broad structural Offer fallback that could false-positive on an empty Offers screen.
- Removed bare non-clickable `claim` as Offer evidence; exact clickable Claim/View Delivery controls remain strong evidence.
- Money + pickup/dropoff/delivery/miles remains strong Offer evidence.
- Alert-only behavior unchanged; no automatic Claim.
