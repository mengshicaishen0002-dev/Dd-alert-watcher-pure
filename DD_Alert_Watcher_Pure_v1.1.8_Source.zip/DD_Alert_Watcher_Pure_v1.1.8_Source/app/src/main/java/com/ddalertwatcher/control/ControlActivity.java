package com.ddalertwatcher.control;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class ControlActivity extends Activity {
    private static final String CORE_PREFS = "cfg";
    private static final String SCHED_PREFS = "control_schedule";
    private SharedPreferences core;
    private SharedPreferences sched;
    private TextView status;
    private CheckBox scheduleEnabled, sound, vibration, keepAwake;
    private Button startTime, endTime;
    private final CheckBox[] days = new CheckBox[7];

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        core = getSharedPreferences(CORE_PREFS, MODE_PRIVATE);
        sched = getSharedPreferences(SCHED_PREFS, MODE_PRIVATE);
        requestNotifications();
        setContentView(buildUi());
        refreshStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 24, 28, 40);
        scroll.addView(root);

        root.addView(text("DD Alert Watcher · v1.1.7 Core R1", 22));
        TextView locked = text("扫描核心：原 v1.1.7 二进制原样保留。这里只改控制界面、关键日志显示和运行时间。", 14);
        locked.setPadding(0, 6, 0, 12);
        root.addView(locked);

        status = text("状态读取中…", 16);
        status.setPadding(0, 8, 0, 12);
        root.addView(status);

        root.addView(button("打开无障碍设置", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("打开 Dasher", v -> openDasher()));

        TextView dtitle = text("扫描日期", 18); dtitle.setPadding(0, 18, 0, 6); root.addView(dtitle);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i=0;i<7;i++) {
            CheckBox cb = new CheckBox(this);
            cb.setText("D"+(i+1));
            cb.setChecked(core.getBoolean("d"+i, true));
            days[i]=cb;
            row.addView(cb, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        }
        root.addView(row);

        sound = check("声音提醒", core.getBoolean("soundAlert", true));
        vibration = check("震动提醒", core.getBoolean("vibrateAlert", true));
        keepAwake = check("监控时保持屏幕常亮", core.getBoolean("keepAwake", true));
        root.addView(sound); root.addView(vibration); root.addView(keepAwake);

        TextView ttitle = text("运行时间", 18); ttitle.setPadding(0, 18, 0, 6); root.addView(ttitle);
        scheduleEnabled = check("启用每天自动运行时间", sched.getBoolean("enabled", false));
        root.addView(scheduleEnabled);
        LinearLayout times = new LinearLayout(this); times.setOrientation(LinearLayout.HORIZONTAL);
        startTime = button("开始 " + timeText(sched.getInt("startMin", 630)), v -> pickTime(true));
        endTime = button("结束 " + timeText(sched.getInt("endMin", 1290)), v -> pickTime(false));
        times.addView(startTime, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        times.addView(endTime, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        root.addView(times);
        root.addView(text("支持跨午夜，例如 22:00 → 02:00。同一开始/结束时间按全天运行。", 13));

        root.addView(button("保存设置 / 应用运行时间", v -> save()));

        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.addView(button("立即开始", v -> { core.edit().putBoolean("enabled", true).putBoolean("paused", false).apply(); refreshStatus(); }), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT,1));
        controls.addView(button("暂停", v -> { core.edit().putBoolean("enabled", true).putBoolean("paused", true).apply(); refreshStatus(); }), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT,1));
        controls.addView(button("停止", v -> stopCore()), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT,1));
        root.addView(controls);

        root.addView(button("测试提醒", v -> testAlert()));
        root.addView(button("查看关键日志", v -> showKeyLogs()));
        root.addView(button("退出并停止监控", v -> { stopCore(); finish(); }));

        TextView note = text("已移除：最低金额、最大 miles、$/mi、扫描等待、观察模式、统计、诊断等控制项。它们不再占界面；v1.1.7 扫描核心本身没有重写。", 13);
        note.setPadding(0, 18, 0, 0);
        root.addView(note);
        return scroll;
    }

    private void save() {
        int selected=0;
        SharedPreferences.Editor e=core.edit();
        for(int i=0;i<7;i++){ if(days[i].isChecked()) selected++; e.putBoolean("d"+i, days[i].isChecked()); }
        if(selected==0){ Toast.makeText(this,"至少选择一个日期",Toast.LENGTH_SHORT).show(); return; }
        e.putBoolean("soundAlert", sound.isChecked())
         .putBoolean("vibrateAlert", vibration.isChecked())
         .putBoolean("keepAwake", keepAwake.isChecked())
         .apply();
        sched.edit().putBoolean("enabled", scheduleEnabled.isChecked()).apply();
        if(scheduleEnabled.isChecked()) ScheduleAlarmReceiver.applyCurrentWindow(this);
        ScheduleAlarmReceiver.scheduleNextBoundaries(this);
        Toast.makeText(this,"已保存",Toast.LENGTH_SHORT).show();
        refreshStatus();
    }

    private void pickTime(boolean start) {
        int cur=sched.getInt(start?"startMin":"endMin", start?630:1290);
        new TimePickerDialog(this,(v,h,m)->{
            int x=h*60+m;
            sched.edit().putInt(start?"startMin":"endMin",x).apply();
            (start?startTime:endTime).setText((start?"开始 ":"结束 ")+timeText(x));
        },cur/60,cur%60,true).show();
    }

    private void stopCore() {
        core.edit().putBoolean("enabled", false).putBoolean("paused", false).apply();
        refreshStatus();
        Toast.makeText(this,"已停止；v1.1.7 看门狗会移除悬浮窗",Toast.LENGTH_SHORT).show();
    }

    private void refreshStatus() {
        if(status==null)return;
        boolean acc=isAccessibilityEnabled();
        boolean en=core.getBoolean("enabled", false);
        boolean pa=core.getBoolean("paused", false);
        String s=!en?"已停止":(pa?"已暂停":"运行中");
        String sch=sched.getBoolean("enabled",false)?(" · 定时 "+timeText(sched.getInt("startMin",630))+"–"+timeText(sched.getInt("endMin",1290))):" · 定时关闭";
        status.setText("无障碍："+(acc?"已连接":"未连接")+" · 监控："+s+sch);
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager am=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
        if(am==null)return false;
        List<AccessibilityServiceInfo> list=am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        if(list==null)return false;
        for(AccessibilityServiceInfo info:list){
            if(info.getResolveInfo()!=null && info.getResolveInfo().serviceInfo!=null){
                String n=info.getResolveInfo().serviceInfo.name;
                if("com.ddalertwatcher.app.OfferAccessibilityService".equals(n) || n.endsWith(".OfferAccessibilityService")) return true;
            }
        }
        return false;
    }

    private void openDasher() {
        try {
            Intent i=getPackageManager().getLaunchIntentForPackage("com.doordash.driverapp");
            if(i==null) throw new Exception();
            startActivity(i);
        } catch(Throwable t){ Toast.makeText(this,"未找到 Dasher",Toast.LENGTH_SHORT).show(); }
    }

    private void showKeyLogs() {
        File f=new File(getExternalFilesDir(null),"dd_offer_monitor.log");
        ArrayList<String> kept=new ArrayList<>();
        if(f.exists()){
            try(BufferedReader br=new BufferedReader(new FileReader(f))){
                String line;
                while((line=br.readLine())!=null){ if(isKeyLog(line)) kept.add(line); }
            }catch(Throwable ignored){}
        }
        Collections.reverse(kept);
        if(kept.size()>80) kept=new ArrayList<>(kept.subList(0,80));
        String msg=kept.isEmpty()?"暂无关键日志":joinLines(kept);
        new AlertDialog.Builder(this).setTitle("关键日志").setMessage(msg).setPositiveButton("关闭",null).show();
    }

    private boolean isKeyLog(String s) {
        String[] keys={"SERVICE_CONNECTED","SERVICE_INTERRUPTED","USER_PAUSE","USER_RESUME","USER_STOP","MANUAL_DATE_OVERRIDE","MANUAL_DATE_ROW_CLICK","USER_INTERACTION_HOLD","CANDIDATE","NEW_OFFER","OBSERVE_OFFER","SAFETY_PAUSE","WATCHDOG_STALL","DATE_CLICK_FAIL","DATE_ROW_NOT_FOUND","CONTROL_OVERLAY_FAIL","RETRY","CLAIM_","BLOCKED_FINAL_ACTION"};
        for(String k:keys) if(s.contains(k)) return true;
        return false;
    }

    private String joinLines(List<String> lines){ StringBuilder b=new StringBuilder(); for(String s:lines){ if(b.length()>0)b.append('\n'); b.append(s);} return b.toString(); }

    private void testAlert() {
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        String ch="offer_alert";
        if(Build.VERSION.SDK_INT>=26 && nm!=null){ NotificationChannel c=new NotificationChannel(ch,"Offer alerts",NotificationManager.IMPORTANCE_HIGH); c.enableVibration(true); nm.createNotificationChannel(c); }
        try { Ringtone r=RingtoneManager.getRingtone(this,RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)); if(r!=null)r.play(); } catch(Throwable ignored){}
        try { Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE); if(v!=null){ if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createWaveform(new long[]{0,250,120,450},-1)); else v.vibrate(new long[]{0,250,120,450},-1);} }catch(Throwable ignored){}
        if(nm!=null){
            Intent i=new Intent(this,ControlActivity.class);
            PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,ch):new android.app.Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("DD Alert Watcher 测试").setContentText("声音、震动、通知正常").setContentIntent(pi).setAutoCancel(true);
            try{nm.notify(11717,b.build());}catch(Throwable ignored){}
        }
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("退出")
                .setMessage("要一起停止监控并关闭悬浮窗，还是只关闭控制界面？")
                .setPositiveButton("退出并停止",(d,w)->{ stopCore(); ControlActivity.super.onBackPressed(); })
                .setNegativeButton("只关界面",(d,w)-> ControlActivity.super.onBackPressed())
                .setNeutralButton("取消",null)
                .show();
    }

    private void requestNotifications(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},117); }
    private String timeText(int m){ return String.format(Locale.US,"%02d:%02d",m/60,m%60); }
    private TextView text(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); return t; }
    private CheckBox check(String s,boolean v){ CheckBox c=new CheckBox(this); c.setText(s); c.setChecked(v); return c; }
    private Button button(String s, View.OnClickListener l){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setOnClickListener(l); return b; }
}
