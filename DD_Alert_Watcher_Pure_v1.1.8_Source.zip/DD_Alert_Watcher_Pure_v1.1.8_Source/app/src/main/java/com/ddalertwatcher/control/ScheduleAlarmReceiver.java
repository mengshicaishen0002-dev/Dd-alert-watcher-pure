package com.ddalertwatcher.control;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;

public class ScheduleAlarmReceiver extends BroadcastReceiver {
    public static final String ACTION_START = "com.ddalertwatcher.control.SCHEDULE_START";
    public static final String ACTION_END = "com.ddalertwatcher.control.SCHEDULE_END";
    static final String SCHED_PREFS = "control_schedule";
    static final String CORE_PREFS = "cfg";

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_START.equals(action)) {
            setCoreRunning(context, true);
            notifyStart(context);
        } else if (ACTION_END.equals(action)) {
            setCoreRunning(context, false);
        }
        scheduleNextBoundaries(context);
    }

    static void setCoreRunning(Context context, boolean running) {
        SharedPreferences.Editor e = context.getSharedPreferences(CORE_PREFS, Context.MODE_PRIVATE).edit();
        if (running) {
            e.putBoolean("enabled", true).putBoolean("paused", false);
        } else {
            // v1.1.7 watchdog sees enabled=false and removes its own control overlay.
            e.putBoolean("enabled", false).putBoolean("paused", false);
        }
        e.apply();
    }

    static boolean isInsideWindow(Context context) {
        SharedPreferences p = context.getSharedPreferences(SCHED_PREFS, Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled", false)) return true;
        int start = p.getInt("startMin", 10 * 60 + 30);
        int end = p.getInt("endMin", 21 * 60 + 30);
        Calendar c = Calendar.getInstance();
        int now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        if (start == end) return true; // same time means 24h
        if (start < end) return now >= start && now < end;
        return now >= start || now < end; // cross midnight
    }

    static void applyCurrentWindow(Context context) {
        SharedPreferences p = context.getSharedPreferences(SCHED_PREFS, Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled", false)) return;
        setCoreRunning(context, isInsideWindow(context));
    }

    static void scheduleNextBoundaries(Context context) {
        SharedPreferences p = context.getSharedPreferences(SCHED_PREFS, Context.MODE_PRIVATE);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent ps = pi(context, ACTION_START, 11701);
        PendingIntent pe = pi(context, ACTION_END, 11702);
        am.cancel(ps); am.cancel(pe);
        if (!p.getBoolean("enabled", false)) return;
        int start = p.getInt("startMin", 10 * 60 + 30);
        int end = p.getInt("endMin", 21 * 60 + 30);
        schedule(am, nextOccurrence(start), ps);
        schedule(am, nextOccurrence(end), pe);
    }

    private static PendingIntent pi(Context c, String action, int code) {
        Intent i = new Intent(c, ScheduleAlarmReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static long nextOccurrence(int minuteOfDay) {
        Calendar now = Calendar.getInstance();
        Calendar t = (Calendar) now.clone();
        t.set(Calendar.HOUR_OF_DAY, minuteOfDay / 60);
        t.set(Calendar.MINUTE, minuteOfDay % 60);
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (!t.after(now)) t.add(Calendar.DAY_OF_YEAR, 1);
        return t.getTimeInMillis();
    }

    private static void schedule(AlarmManager am, long when, PendingIntent pi) {
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.set(AlarmManager.RTC_WAKEUP, when, pi);
    }

    private static void notifyStart(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        String ch = "schedule_notice";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nc = new NotificationChannel(ch, "运行时间提醒", NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(nc);
        }
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(c, ch)
                : new android.app.Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle("DD Alert Watcher 已进入运行时间")
                .setContentText("请保持/打开 Dasher → Schedule → Offers；不会自动 Claim。")
                .setAutoCancel(true);
        try { nm.notify(11701, b.build()); } catch (Throwable ignored) {}
    }
}
