package com.ddalertwatcher.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ScheduleBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        ScheduleAlarmReceiver.applyCurrentWindow(context);
        ScheduleAlarmReceiver.scheduleNextBoundaries(context);
    }
}
