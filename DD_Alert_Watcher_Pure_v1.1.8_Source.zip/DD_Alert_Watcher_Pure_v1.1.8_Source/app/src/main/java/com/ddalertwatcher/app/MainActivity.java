package com.ddalertwatcher.app;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    static final String PREFS = "dd_alert_prefs";
    private SharedPreferences prefs;
    private TextView status;
    private Button startTimeButton;
    private Button endTimeButton;
    private CheckBox scheduleEnabled;
    private final CheckBox[] dayChecks = new CheckBox[7];
    private final CheckBox[] scanDayChecks = new CheckBox[7];
    private CheckBox sound;
    private CheckBox vibrate;
    private CheckBox keepAwake;
    private EditText tempMinutes;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        requestNotificationPermission();
        setContentView(buildUi());
        refreshStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    @Override public void onBackPressed() {
        // Explicit Back = exit monitor. Home/Recents switch keeps monitoring.
        OfferAccessibilityService.requestStop(this);
        super.onBackPressed();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 24, 32, 48);
        scroll.addView(root);

        root.addView(text("DD Alert Watcher · Stable117Rebase v1.1.11", 22));
        root.addView(text("扫描核心重新以已验证的 v1.1.7 为基线；新增功能只包在扫描器外层。发现任何 Offer 后立即提醒并冻结，最终 Claim 完全人工。", 14));

        status = text("服务状态：读取中…", 16);
        status.setPadding(0, 16, 0, 16);
        root.addView(status);
        root.addView(button("打开无障碍设置", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        TextView scanTitle = text("扫描日期", 18);
        scanTitle.setPadding(0, 20, 0, 6);
        root.addView(scanTitle);
        LinearLayout scanRow = new LinearLayout(this);
        scanRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            CheckBox cb = new CheckBox(this);
            cb.setText("D" + (i + 1));
            cb.setChecked(prefs.getBoolean("scan_d" + (i + 1), true));
            scanDayChecks[i] = cb;
            scanRow.addView(cb, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(scanRow);

        sound = checkbox("Offer 声音提醒", prefs.getBoolean("sound", true));
        vibrate = checkbox("Offer 震动提醒", prefs.getBoolean("vibrate", true));
        keepAwake = checkbox("监控时保持屏幕常亮", prefs.getBoolean("keep_awake", true));
        root.addView(sound);
        root.addView(vibrate);
        root.addView(keepAwake);

        TextView scheduleTitle = text("运行时间", 18);
        scheduleTitle.setPadding(0, 20, 0, 6);
        root.addView(scheduleTitle);
        scheduleEnabled = checkbox("启用每周时间表", prefs.getBoolean("schedule_enabled", false));
        root.addView(scheduleEnabled);

        LinearLayout timeRow = new LinearLayout(this);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);
        startTimeButton = button("开始 " + prefs.getString("schedule_start", "10:30"), v -> pickTime(true));
        endTimeButton = button("结束 " + prefs.getString("schedule_end", "21:30"), v -> pickTime(false));
        timeRow.addView(startTimeButton, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
        timeRow.addView(endTimeButton, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(timeRow);

        LinearLayout week = new LinearLayout(this);
        week.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"一", "二", "三", "四", "五", "六", "日"};
        for (int i = 0; i < 7; i++) {
            CheckBox cb = new CheckBox(this);
            cb.setText(names[i]);
            cb.setChecked(prefs.getBoolean("schedule_day_" + i, true));
            dayChecks[i] = cb;
            week.addView(cb, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(week);
        root.addView(text("支持跨午夜，例如 22:00 → 02:00；到点不会自动打开 DoorDash，只会等待你进入 Offers。", 13));

        LinearLayout tempRow = new LinearLayout(this);
        tempRow.setOrientation(LinearLayout.HORIZONTAL);
        tempMinutes = new EditText(this);
        tempMinutes.setHint("临时运行分钟");
        tempMinutes.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        tempRow.addView(tempMinutes, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
        tempRow.addView(button("临时运行", v -> startTemporaryRun()));
        root.addView(tempRow);

        root.addView(button("保存设置", v -> saveSettings()));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.addView(button("开始/继续", v -> startOrResume()), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
        controls.addView(button("人工暂停", v -> OfferAccessibilityService.requestPause(this)), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(controls);
        root.addView(button("停止监控并关闭悬浮窗", v -> {
            OfferAccessibilityService.requestStop(this);
            refreshStatus();
        }));

        root.addView(button("测试 Offer 提醒", v -> OfferAccessibilityService.requestTestAlert(this)));
        root.addView(button("查看最近日志", v -> showLogs()));
        root.addView(button("清空日志/统计", v -> {
            prefs.edit().remove("logs").remove("stat_offer").remove("stat_error").remove("stat_stall").apply();
            Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show();
        }));

        root.addView(text("没有金额/里程/$/mi/详情过滤。按 Back 退出 App 会停止监控并关闭悬浮窗；按 Home 或切到 Dasher 不会停止。", 13));
        return scroll;
    }

    private void startOrResume() {
        prefs.edit().putBoolean("user_stopped", false).putBoolean("user_paused", false).apply();
        if (!OfferAccessibilityService.isServiceConnected()) {
            OfferAccessibilityService.requestResume(this);
            Toast.makeText(this, "无障碍服务未连接，请开启 DD Alert Watcher", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        OfferAccessibilityService.requestResume(this);
        Toast.makeText(this, "已开始/继续，请回到 Dasher Offers", Toast.LENGTH_SHORT).show();
        refreshStatus();
    }

    private void saveSettings() {
        SharedPreferences.Editor e = prefs.edit();
        e.putBoolean("sound", sound.isChecked());
        e.putBoolean("vibrate", vibrate.isChecked());
        e.putBoolean("keep_awake", keepAwake.isChecked());
        e.putBoolean("schedule_enabled", scheduleEnabled.isChecked());
        for (int i = 0; i < 7; i++) {
            e.putBoolean("scan_d" + (i + 1), scanDayChecks[i].isChecked());
            e.putBoolean("schedule_day_" + i, dayChecks[i].isChecked());
        }
        e.apply();
        OfferAccessibilityService.requestReload(this);
        Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
    }

    private void pickTime(boolean start) {
        String key = start ? "schedule_start" : "schedule_end";
        String current = prefs.getString(key, start ? "10:30" : "21:30");
        String[] p = current.split(":");
        int hour = Integer.parseInt(p[0]);
        int minute = Integer.parseInt(p[1]);
        new TimePickerDialog(this, (view, h, m) -> {
            String value = String.format(Locale.US, "%02d:%02d", h, m);
            prefs.edit().putString(key, value).apply();
            if (start) startTimeButton.setText("开始 " + value);
            else endTimeButton.setText("结束 " + value);
            OfferAccessibilityService.requestReload(this);
        }, hour, minute, true).show();
    }

    private void startTemporaryRun() {
        String s = tempMinutes.getText().toString().trim();
        if (s.isEmpty()) return;
        try {
            long minutes = Long.parseLong(s);
            if (minutes <= 0 || minutes > 1440) throw new NumberFormatException();
            prefs.edit()
                    .putLong("temp_until", System.currentTimeMillis() + minutes * 60_000L)
                    .putBoolean("user_stopped", false)
                    .putBoolean("user_paused", false)
                    .apply();
            OfferAccessibilityService.requestResume(this);
            Toast.makeText(this, "临时运行 " + minutes + " 分钟", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "请输入 1–1440 分钟", Toast.LENGTH_SHORT).show();
        }
    }

    private void showLogs() {
        String logs = prefs.getString("logs", "暂无日志");
        int offers = prefs.getInt("stat_offer", 0);
        int errors = prefs.getInt("stat_error", 0);
        int stalls = prefs.getInt("stat_stall", 0);
        new AlertDialog.Builder(this)
                .setTitle("最近日志 · Offer " + offers + " · Error " + errors + " · Stall " + stalls)
                .setMessage(logs)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void refreshStatus() {
        if (status == null) return;
        boolean enabled = isAccessibilityEnabled();
        boolean connected = OfferAccessibilityService.isServiceConnected();
        String actual = connected ? "无障碍已连接" : (enabled ? "无障碍已启用但尚未连接" : "无障碍未启用");
        status.setText("服务状态：" + prefs.getString("service_state", "未连接") + "\n实际状态：" + actual);
    }

    private boolean isAccessibilityEnabled() {
        try {
            AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            if (am == null) return false;
            for (AccessibilityServiceInfo info : am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
                if (info.getResolveInfo() == null || info.getResolveInfo().serviceInfo == null) continue;
                if (getPackageName().equals(info.getResolveInfo().serviceInfo.packageName) &&
                        info.getResolveInfo().serviceInfo.name != null &&
                        info.getResolveInfo().serviceInfo.name.contains("OfferAccessibilityService")) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
    }

    private TextView text(String value, int sp) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        return t;
    }

    private CheckBox checkbox(String label, boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setChecked(checked);
        return c;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(listener);
        return b;
    }
}
