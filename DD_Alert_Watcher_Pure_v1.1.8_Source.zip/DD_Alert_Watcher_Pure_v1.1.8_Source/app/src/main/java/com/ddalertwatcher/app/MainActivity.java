package com.ddalertwatcher.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    static final String PREFS = "dd_alert_prefs";
    private SharedPreferences prefs;
    private TextView status;
    private Button startTimeButton;
    private Button endTimeButton;
    private CheckBox scheduleEnabled;
    private final CheckBox[] dayChecks = new CheckBox[7];
    private final CheckBox[] scanDayChecks = new CheckBox[7];
    private CheckBox sound;
    private CheckBox vibrate;
    private CheckBox keepAwake;
    private EditText tempMinutes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        requestNotificationPermission();
        setContentView(buildUi());
        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 24, 32, 48);
        scroll.addView(root);

        TextView title = text("DD Alert Watcher · Pure Alert v1.1.10", 22);
        root.addView(title);
        TextView desc = text("只监控 DoorDash Offers：发现任何 Offer 立即提醒并冻结扫描，后续完全人工处理。", 15);
        root.addView(desc);

        status = text("服务状态：读取中…", 16);
        status.setPadding(0, 18, 0, 18);
        root.addView(status);

        Button accessibility = button("打开无障碍设置", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        TextView scanTitle = text("扫描日期", 18);
        scanTitle.setPadding(0, 22, 0, 8);
        root.addView(scanTitle);
        LinearLayout scanRow = new LinearLayout(this);
        scanRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            CheckBox cb = new CheckBox(this);
            cb.setText("D" + (i + 1));
            cb.setChecked(prefs.getBoolean("scan_d" + (i + 1), true));
            scanDayChecks[i] = cb;
            scanRow.addView(cb, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        }
        root.addView(scanRow);

        sound = checkbox("Offer 声音提醒", prefs.getBoolean("sound", true));
        vibrate = checkbox("Offer 震动提醒", prefs.getBoolean("vibrate", true));
        keepAwake = checkbox("监控时保持屏幕常亮", prefs.getBoolean("keep_awake", true));
        root.addView(sound);
        root.addView(vibrate);
        root.addView(keepAwake);

        TextView scheduleTitle = text("定时运行", 18);
        scheduleTitle.setPadding(0, 22, 0, 8);
        root.addView(scheduleTitle);
        scheduleEnabled = checkbox("启用每日/每周时间表", prefs.getBoolean("schedule_enabled", false));
        root.addView(scheduleEnabled);

        LinearLayout timeRow = new LinearLayout(this);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);
        startTimeButton = button("开始 " + prefs.getString("schedule_start", "10:30"), v -> pickTime(true));
        endTimeButton = button("结束 " + prefs.getString("schedule_end", "21:30"), v -> pickTime(false));
        timeRow.addView(startTimeButton, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        timeRow.addView(endTimeButton, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        root.addView(timeRow);

        LinearLayout weekRow = new LinearLayout(this);
        weekRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"一", "二", "三", "四", "五", "六", "日"};
        for (int i = 0; i < 7; i++) {
            CheckBox cb = new CheckBox(this);
            cb.setText(names[i]);
            cb.setChecked(prefs.getBoolean("schedule_day_" + i, true));
            dayChecks[i] = cb;
            weekRow.addView(cb, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        }
        root.addView(weekRow);

        TextView crossMidnight = text("支持跨午夜，例如 22:00 → 02:00。定时到点时不会自动打开 DoorDash。", 13);
        root.addView(crossMidnight);

        LinearLayout tempRow = new LinearLayout(this);
        tempRow.setOrientation(LinearLayout.HORIZONTAL);
        tempMinutes = new EditText(this);
        tempMinutes.setHint("临时运行分钟，例如 120");
        tempMinutes.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        tempRow.addView(tempMinutes, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        tempRow.addView(button("临时运行", v -> startTemporaryRun()));
        root.addView(tempRow);

        root.addView(button("保存设置", v -> saveSettings()));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(button("开始/继续监控", v -> startOrResumeMonitor()), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        actions.addView(button("人工暂停", v -> OfferAccessibilityService.requestPause(this)), new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1));
        root.addView(actions);

        root.addView(button("停止监控并关闭悬浮窗", v -> {
            OfferAccessibilityService.requestStop(this);
            Toast.makeText(this, "监控已停止，悬浮窗已关闭", Toast.LENGTH_SHORT).show();
        }));

        TextView exitNote = text("说明：切到 Dasher 或按 Home/返回时，悬浮窗会继续存在以便监控；只有点击“停止监控并关闭悬浮窗”才是真正退出监控。", 13);
        root.addView(exitNote);

        root.addView(button("测试 Offer 提醒", v -> OfferAccessibilityService.requestTestAlert(this)));
        root.addView(button("查看最近日志", v -> showLogs()));
        root.addView(button("清空日志/统计", v -> {
            prefs.edit().remove("logs").remove("stat_offer").remove("stat_error").remove("stat_stall").apply();
            Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show();
        }));

        TextView note = text("已移除最低金额、最大里程、$/mi、详情解析等 Pure Alert 不使用的设置。最终 Claim 永远由你手动完成。", 13);
        note.setPadding(0, 24, 0, 0);
        root.addView(note);
        return scroll;
    }

    private void startOrResumeMonitor() {
        // Clear a persisted Stop first. If Accessibility is not actually connected, do not
        // fail silently: send the user straight to the system page that can enable it.
        prefs.edit().putBoolean("user_stopped", false).apply();
        if (!OfferAccessibilityService.isServiceConnected()) {
            OfferAccessibilityService.requestResume(this);
            Toast.makeText(this, "无障碍监控服务未连接，请重新开启 DD Alert Watcher", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        OfferAccessibilityService.requestResume(this);
        Toast.makeText(this, "已请求开始监控，请回到 Dasher Offers", Toast.LENGTH_SHORT).show();
        refreshStatus();
    }

    private boolean isAccessibilityEnabled() {
        try {
            AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            if (am == null) return false;
            for (AccessibilityServiceInfo info : am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
                if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null) {
                    String pkg = info.getResolveInfo().serviceInfo.packageName;
                    String name = info.getResolveInfo().serviceInfo.name;
                    if (getPackageName().equals(pkg) && name != null && name.contains("OfferAccessibilityService")) return true;
                }
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private void saveSettings() {
        SharedPreferences.Editor e = prefs.edit();
        e.putBoolean("sound", sound.isChecked());
        e.putBoolean("vibrate", vibrate.isChecked());
        e.putBoolean("keep_awake", keepAwake.isChecked());
        e.putBoolean("schedule_enabled", scheduleEnabled.isChecked());
        for (int i = 0; i < 7; i++) {
            e.putBoolean("scan_d" + (i + 1), scanDayChecks[i].isChecked());
            e.putBoolean("schedule_day_" + i, dayChecks[i].isChecked());
        }
        e.apply();
        Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
        OfferAccessibilityService.requestReload(this);
    }

    private void pickTime(boolean start) {
        String key = start ? "schedule_start" : "schedule_end";
        String cur = prefs.getString(key, start ? "10:30" : "21:30");
        String[] p = cur.split(":");
        int h = Integer.parseInt(p[0]);
        int m = Integer.parseInt(p[1]);
        new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            String value = String.format(Locale.US, "%02d:%02d", hourOfDay, minute);
            prefs.edit().putString(key, value).apply();
            if (start) startTimeButton.setText("开始 " + value); else endTimeButton.setText("结束 " + value);
            OfferAccessibilityService.requestReload(this);
        }, h, m, true).show();
    }

    private void startTemporaryRun() {
        String s = tempMinutes.getText().toString().trim();
        if (s.isEmpty()) return;
        try {
            long minutes = Long.parseLong(s);
            if (minutes <= 0 || minutes > 1440) throw new NumberFormatException();
            long until = System.currentTimeMillis() + minutes * 60_000L;
            prefs.edit().putLong("temp_until", until).apply();
            OfferAccessibilityService.requestResume(this);
            Toast.makeText(this, "临时运行 " + minutes + " 分钟", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "请输入 1–1440 分钟", Toast.LENGTH_SHORT).show();
        }
    }

    private void showLogs() {
        String logs = prefs.getString("logs", "暂无日志");
        int offers = prefs.getInt("stat_offer", 0);
        int errors = prefs.getInt("stat_error", 0);
        int stalls = prefs.getInt("stat_stall", 0);
        new AlertDialog.Builder(this)
                .setTitle("最近日志 · Offer " + offers + " · Error " + errors + " · Stall " + stalls)
                .setMessage(logs)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void refreshStatus() {
        if (status == null) return;
        String state = prefs.getString("service_state", "未连接");
        boolean enabled = isAccessibilityEnabled();
        boolean connected = OfferAccessibilityService.isServiceConnected();
        String actual = connected ? "无障碍已连接" : (enabled ? "无障碍已启用但尚未连接" : "无障碍未启用");
        status.setText("服务状态：" + state + "\n实际状态：" + actual);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
    }

    private TextView text(String value, int sp) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        return t;
    }

    private CheckBox checkbox(String label, boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setChecked(checked);
        return c;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(listener);
        return b;
    }
}
