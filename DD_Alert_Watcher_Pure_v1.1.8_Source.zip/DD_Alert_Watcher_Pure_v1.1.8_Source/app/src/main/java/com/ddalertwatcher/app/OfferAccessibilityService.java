package com.ddalertwatcher.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Pure Alert v1.1.11 StableSchedule.
 *
 * Design rule: preserve the proven v1.1.7 scan rhythm and self-event suppression,
 * and put schedule/health/overlay controls around that scan core. Final Claim remains manual.
 */
public class OfferAccessibilityService extends AccessibilityService {
    private static volatile OfferAccessibilityService INSTANCE;

    private static final String DASHER_PACKAGE = "com.doordash.driverapp";
    private static final String PREFS = MainActivity.PREFS;
    private static final String CHANNEL_OFFER = "offer_alert";
    private static final String CHANNEL_ERROR = "monitor_error";

    // v1.1.7 behavior anchor: own date-tap events can arrive roughly 0.5–0.65s late.
    private static final long SELF_EVENT_WINDOW_MS = 900L;
    private static final long MANUAL_HOLD_MS = 3500L;

    // Conservative scan rhythm: obvious empty pages advance quickly; ambiguous pages get more time.
    private static final long FIRST_SETTLE_MS = 820L;
    private static final long AMBIGUOUS_RECHECK_MS = 430L;
    private static final long MAX_SETTLE_MS = 2300L;
    private static final long ROUND_PAUSE_MS = 850L;

    private static final long OFFER_CONFIRM_MS = 150L;
    private static final long OFFER_CONFIRM_MAX_MS = 1200L;
    private static final long WATCHDOG_STALL_MS = 18_000L;
    private static final long WATCHDOG_TICK_MS = 2_000L;

    private static final Pattern MONEY = Pattern.compile("(?s).*\\$\\s*\\d+(?:\\.\\d{1,2})?.*");
    private static final Pattern DISTANCE = Pattern.compile("(?s).*\\b\\d+(?:\\.\\d+)?\\s*(?:mi|mile|miles)\\b.*", Pattern.CASE_INSENSITIVE);

    private enum State {
        RUNNING,
        USER_PAUSED,
        SCHEDULE_WAIT,
        SCHEDULE_ENDED,
        TEMP_ENDED,
        OFFER_FROZEN,
        ERROR_PAUSED,
        STOPPED
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private State state = State.STOPPED;

    private WindowManager wm;
    private View overlay;
    private TextView overlayStatus;
    private WindowManager.LayoutParams overlayLp;

    private int currentDateIndex = 0;
    private int currentRoundScanned = 0;
    private long selfEventUntil = 0L;
    private int expectedAutoDateIndex = -1;
    private long manualHoldUntil = 0L;

    private long settleDeadlineAt = 0L;
    private boolean waitingForDateSettle = false;
    private long lastProgressAt = 0L;

    private int offerCandidateDate = -1;
    private long offerCandidateFirstAt = 0L;
    private long lastOfferAlertAt = 0L;
    private String lastOfferFingerprint = "";

    private boolean scanScheduled = false;
    private boolean scheduleDueNotified = false;
    private boolean errorNotified = false;

    private final Runnable scanRunnable = new Runnable() {
        @Override public void run() {
            scanScheduled = false;
            scanTick();
        }
    };

    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            try {
                processExternalCommand();
                evaluateSchedule();
                refreshOverlayIfNeeded();

                // Watchdog is eligible only while actively scanning an allowed Dasher Offers page.
                if (state == State.RUNNING && isRunWindowAllowedNow()) {
                    Snapshot snap = activeDasherSnapshot();
                    if (snap != null && snap.looksLikeOffersPage()) {
                        long now = System.currentTimeMillis();
                        if (lastProgressAt > 0L && now - lastProgressAt >= WATCHDOG_STALL_MS) {
                            log("WATCHDOG_STALL idleMs=" + (now - lastProgressAt));
                            increment("stat_stall");
                            alertError("监控停滞", "18秒没有扫描进展，已软重启扫描器。请确认仍停留在 Dasher Offers。" );
                            softRestartScanner();
                        }
                    }
                }
            } catch (Throwable t) {
                log("WATCHDOG_ERROR " + t.getClass().getSimpleName());
                increment("stat_error");
            } finally {
                handler.postDelayed(this, WATCHDOG_TICK_MS);
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannels();

        boolean userStopped = prefs.getBoolean("user_stopped", false);
        if (userStopped) state = State.STOPPED;
        else if (isRunWindowAllowedNow()) state = State.RUNNING;
        else state = State.SCHEDULE_WAIT;

        resetWatchdogClock();
        setServiceStateText();
        log("SERVICE_CONNECTED pure-alert-v1.1.11 state=" + state.name());

        if (state != State.STOPPED) ensureOverlay();
        handler.removeCallbacks(watchdog);
        handler.post(watchdog);
        if (state == State.RUNNING) scheduleScan(300L);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null || !DASHER_PACKAGE.contentEquals(pkg)) return;

        Snapshot snap = activeDasherSnapshot();
        if (snap == null) return;

        if (snap.hasErrorLayer()) {
            enterErrorPause("retry-layer");
            return;
        }

        if (state == State.RUNNING && snap.looksLikeOffersPage()) {
            handleManualDateEvent(event);
            if (detectOfferCandidate(snap)) return;
        }

        // If a schedule window has just opened while the user is already on Offers, start immediately.
        if ((state == State.SCHEDULE_WAIT || state == State.SCHEDULE_ENDED) &&
                isRunWindowAllowedNow() && snap.looksLikeOffersPage() && !prefs.getBoolean("user_stopped", false)) {
            state = State.RUNNING;
            scheduleDueNotified = false;
            resetScannerForResume();
            log("SCHEDULE_START_ON_EVENT");
            setServiceStateText();
            ensureOverlay();
            scheduleScan(120L);
        }
        updateOverlay();
    }

    @Override public void onInterrupt() {
        log("SERVICE_INTERRUPTED");
    }

    @Override public void onDestroy() {
        cancelPendingScan();
        handler.removeCallbacks(watchdog);
        removeOverlay();
        if (prefs != null) prefs.edit().putString("service_state", "服务已停止").apply();
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }

    private void scanTick() {
        evaluateSchedule();
        if (state != State.RUNNING) return;
        if (!isRunWindowAllowedNow()) return;

        long now = System.currentTimeMillis();
        if (now < manualHoldUntil) {
            scheduleScan(manualHoldUntil - now + 50L);
            return;
        }

        Snapshot snap = activeDasherSnapshot();
        if (snap == null || !snap.looksLikeOffersPage()) {
            // Never click outside the Dasher Offers screen.
            scheduleScan(700L);
            updateOverlay();
            return;
        }

        if (snap.hasErrorLayer()) {
            enterErrorPause("retry-layer-scan");
            return;
        }

        if (detectOfferCandidate(snap)) return;

        if (waitingForDateSettle) {
            if (snap.emptyPage) {
                log("DATE_EMPTY_FAST_SETTLED expected=D" + (expectedAutoDateIndex + 1));
                finishDateAndAdvance();
                return;
            }

            if (now >= settleDeadlineAt) {
                log("DATE_SETTLE_NO_SIGNAL expected=D" + (expectedAutoDateIndex + 1));
                finishDateAndAdvance();
                return;
            }

            scheduleScan(AMBIGUOUS_RECHECK_MS);
            return;
        }

        int next = findNextEnabledDate(currentDateIndex);
        if (next < 0) {
            state = State.USER_PAUSED;
            log("NO_SCAN_DAYS_ENABLED");
            alertError("未选择扫描日期", "请至少选择一个 D1–D7 日期。" );
            setServiceStateText();
            updateOverlay();
            return;
        }

        currentDateIndex = next;
        tapDate(currentDateIndex);
    }

    private Snapshot activeDasherSnapshot() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return null;
            CharSequence pkg = root.getPackageName();
            if (pkg == null || !DASHER_PACKAGE.contentEquals(pkg)) return null;
            return Snapshot.from(root);
        } catch (Throwable t) {
            log("ACTIVE_SNAPSHOT_FAIL " + t.getClass().getSimpleName());
            return null;
        }
    }

    private void tapDate(final int index) {
        int sw = getResources().getDisplayMetrics().widthPixels;
        float scale = sw / 1080f;
        float x = (101f + 135f * index) * scale;
        float y = 349f * scale;

        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, 60);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();

        expectedAutoDateIndex = index;
        selfEventUntil = System.currentTimeMillis() + SELF_EVENT_WINDOW_MS;
        waitingForDateSettle = true;
        settleDeadlineAt = System.currentTimeMillis() + MAX_SETTLE_MS;
        clearOfferCandidate();

        log("DATE_BUTTON_ROW_TAP D" + (index + 1) + " x=" + Math.round(x) + " y=" + Math.round(y));
        dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
                scheduleScan(FIRST_SETTLE_MS);
            }

            @Override public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
                log("DATE_CLICK_FAIL D" + (index + 1));
                increment("stat_error");
                waitingForDateSettle = false;
                settleDeadlineAt = 0L;
                markProgress();
                scheduleScan(500L);
            }
        }, null);
    }

    private void finishDateAndAdvance() {
        waitingForDateSettle = false;
        settleDeadlineAt = 0L;
        expectedAutoDateIndex = -1;
        selfEventUntil = 0L;
        clearOfferCandidate();
        markProgress();

        currentRoundScanned++;
        currentDateIndex = (currentDateIndex + 1) % 7;
        if (currentRoundScanned >= enabledDateCount()) {
            currentRoundScanned = 0;
            log("ROUND_PAUSE ms=" + ROUND_PAUSE_MS + " emptyRounds=1 hadMoney=false");
            scheduleScan(ROUND_PAUSE_MS);
        } else {
            scheduleScan(30L);
        }
        updateOverlay();
    }

    /**
     * Manual priority without the v1.1.10 false positives:
     * only explicit click/selection events whose source bounds really sit on the tested date row count.
     * All date-row events inside our own 900ms post-gesture window are ignored.
     */
    private void handleManualDateEvent(AccessibilityEvent event) {
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_VIEW_CLICKED && type != AccessibilityEvent.TYPE_VIEW_SELECTED) return;

        int eventDate = strictDateIndexFromNode(event.getSource());
        if (eventDate < 0) return;

        long now = System.currentTimeMillis();
        if (now <= selfEventUntil) return;

        manualHoldUntil = now + MANUAL_HOLD_MS;
        cancelPendingScan();
        waitingForDateSettle = false;
        settleDeadlineAt = 0L;
        expectedAutoDateIndex = -1;
        clearOfferCandidate();
        log("MANUAL_DATE_OVERRIDE D" + (eventDate + 1));
        log("USER_INTERACTION_HOLD yield=" + MANUAL_HOLD_MS + "ms");
        scheduleScan(MANUAL_HOLD_MS + 50L);
        updateOverlay();
    }

    private int strictDateIndexFromNode(AccessibilityNodeInfo node) {
        if (node == null) return -1;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.isEmpty()) return -1;

        int sw = getResources().getDisplayMetrics().widthPixels;
        float scale = sw / 1080f;
        float expectedY = 349f * scale;
        float cy = r.centerY();
        if (Math.abs(cy - expectedY) > 95f * scale) return -1;
        if (r.width() > 240f * scale || r.height() > 190f * scale) return -1;

        float first = 101f * scale;
        float step = 135f * scale;
        int idx = Math.round((r.centerX() - first) / step);
        if (idx < 0 || idx > 6) return -1;
        float center = first + step * idx;
        if (Math.abs(r.centerX() - center) > 68f * scale) return -1;
        return idx;
    }

    private boolean detectOfferCandidate(Snapshot snap) {
        if (state != State.RUNNING) return false;
        if (!snap.looksLikeOffersPage() || snap.emptyPage || snap.loadingLike || snap.errorLayer || !snap.offerCandidate) {
            clearOfferCandidate();
            return false;
        }

        long now = System.currentTimeMillis();
        if (offerCandidateDate != currentDateIndex || offerCandidateFirstAt == 0L || now - offerCandidateFirstAt > OFFER_CONFIRM_MAX_MS) {
            offerCandidateDate = currentDateIndex;
            offerCandidateFirstAt = now;
            log("OFFER_CANDIDATE date=D" + (currentDateIndex + 1) + " evidence=" + snap.offerEvidence);
            scheduleScan(OFFER_CONFIRM_MS);
            return true;
        }

        // Second independent snapshot on the same date confirms the signal.
        String fingerprint = snap.fingerprint();
        if (fingerprint.equals(lastOfferFingerprint) && now - lastOfferAlertAt < 60_000L) {
            state = State.OFFER_FROZEN;
            cancelPendingScan();
            setServiceStateText();
            updateOverlay();
            return true;
        }

        lastOfferFingerprint = fingerprint;
        lastOfferAlertAt = now;
        state = State.OFFER_FROZEN;
        cancelPendingScan();
        waitingForDateSettle = false;
        settleDeadlineAt = 0L;
        increment("stat_offer");
        log("OFFER_CONFIRMED source=" + snap.offerEvidence);
        log("ALERT_SENT");
        log("AUTO_SCAN_FROZEN reason=offer");
        sendOfferAlert("发现 Offer！", "请立即查看 Dasher。扫描已冻结；处理后手动点“继续”。");
        setServiceStateText();
        updateOverlay();
        return true;
    }

    private void clearOfferCandidate() {
        offerCandidateDate = -1;
        offerCandidateFirstAt = 0L;
    }

    private void enterErrorPause(String reason) {
        if (state == State.ERROR_PAUSED) return;
        state = State.ERROR_PAUSED;
        cancelPendingScan();
        waitingForDateSettle = false;
        settleDeadlineAt = 0L;
        clearOfferCandidate();
        log("DOORDASH_ERROR " + reason);
        increment("stat_error");
        if (!errorNotified) {
            errorNotified = true;
            alertError("DoorDash 页面异常", "检测到 Something went wrong / Retry。已暂停，请人工处理后点继续。" );
        }
        setServiceStateText();
        ensureOverlay();
        updateOverlay();
    }

    private void scheduleScan(long delayMs) {
        if (scanScheduled || state != State.RUNNING) return;
        scanScheduled = true;
        handler.postDelayed(scanRunnable, Math.max(0L, delayMs));
    }

    private void cancelPendingScan() {
        handler.removeCallbacks(scanRunnable);
        scanScheduled = false;
    }

    private int findNextEnabledDate(int start) {
        for (int i = 0; i < 7; i++) {
            int idx = (start + i) % 7;
            if (prefs.getBoolean("scan_d" + (idx + 1), true)) return idx;
        }
        return -1;
    }

    private int enabledDateCount() {
        int count = 0;
        for (int i = 0; i < 7; i++) if (prefs.getBoolean("scan_d" + (i + 1), true)) count++;
        return count;
    }

    private void markProgress() {
        lastProgressAt = System.currentTimeMillis();
    }

    private void resetWatchdogClock() {
        lastProgressAt = System.currentTimeMillis();
    }

    private void resetScannerForResume() {
        cancelPendingScan();
        waitingForDateSettle = false;
        settleDeadlineAt = 0L;
        expectedAutoDateIndex = -1;
        selfEventUntil = 0L;
        manualHoldUntil = 0L;
        currentRoundScanned = 0;
        clearOfferCandidate();
        errorNotified = false;
        resetWatchdogClock();
    }

    private void softRestartScanner() {
        resetScannerForResume();
        if (state == State.RUNNING) scheduleScan(300L);
    }

    /** Priority: Offer freeze > error pause > manual pause > schedule > automatic scan. */
    private void evaluateSchedule() {
        if (prefs == null) return;
        long now = System.currentTimeMillis();

        // Temporary run is a hard session limit. When it expires, it stays ended until the user resumes.
        boolean tempActive = prefs.getBoolean("temp_session", false);
        long tempUntil = prefs.getLong("temp_until", 0L);
        if (tempActive && tempUntil > 0L && now >= tempUntil) {
            prefs.edit().putBoolean("temp_session", false).remove("temp_until").apply();
            if (state == State.RUNNING || state == State.SCHEDULE_WAIT || state == State.SCHEDULE_ENDED) {
                state = State.TEMP_ENDED;
                cancelPendingScan();
                waitingForDateSettle = false;
                settleDeadlineAt = 0L;
                log("TEMP_RUN_END");
                notifyInfo("临时运行已结束", "已按设定时间停止扫描。", 3006);
                setServiceStateText();
                updateOverlay();
            }
            return;
        }

        // Higher-priority holds are never auto-resumed by the clock.
        if (state == State.STOPPED || state == State.USER_PAUSED || state == State.OFFER_FROZEN ||
                state == State.ERROR_PAUSED || state == State.TEMP_ENDED) return;

        boolean allowed = isRunWindowAllowedNow();
        if (!allowed && state == State.RUNNING) {
            state = State.SCHEDULE_ENDED;
            cancelPendingScan();
            waitingForDateSettle = false;
            settleDeadlineAt = 0L;
            clearOfferCandidate();
            log("SCHEDULE_END");
            notifyInfo("定时监控已结束", "已安全停止扫描。", 3005);
            setServiceStateText();
            updateOverlay();
            return;
        }

        if (allowed && (state == State.SCHEDULE_WAIT || state == State.SCHEDULE_ENDED)) {
            Snapshot snap = activeDasherSnapshot();
            if (snap != null && snap.looksLikeOffersPage()) {
                state = State.RUNNING;
                scheduleDueNotified = false;
                resetScannerForResume();
                log("SCHEDULE_START");
                setServiceStateText();
                ensureOverlay();
                scheduleScan(120L);
            } else if (!scheduleDueNotified) {
                scheduleDueNotified = true;
                notifyInfo("运行时间已到", "请打开 Dasher → Schedule → Offers。程序不会自动打开 DoorDash。", 3004);
            }
        }
    }

    private boolean isRunWindowAllowedNow() {
        if (prefs == null) return true;
        long now = System.currentTimeMillis();

        if (prefs.getBoolean("temp_session", false)) {
            long until = prefs.getLong("temp_until", 0L);
            return until > now;
        }

        if (!prefs.getBoolean("schedule_enabled", false)) return true;

        Calendar c = Calendar.getInstance();
        int minute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        int start = parseMinutes(prefs.getString("schedule_start", "10:30"));
        int end = parseMinutes(prefs.getString("schedule_end", "21:30"));

        if (start == end) return dayEnabled(c); // selected day = 24h window
        if (start < end) return dayEnabled(c) && minute >= start && minute < end;

        // Cross-midnight: 22:00→02:00 belongs to the weekday on which the window started.
        if (minute >= start) return dayEnabled(c);
        if (minute < end) {
            Calendar previous = (Calendar) c.clone();
            previous.add(Calendar.DAY_OF_YEAR, -1);
            return dayEnabled(previous);
        }
        return false;
    }

    private boolean dayEnabled(Calendar c) {
        int javaDow = c.get(Calendar.DAY_OF_WEEK);
        int idx = javaDow == Calendar.SUNDAY ? 6 : javaDow - Calendar.MONDAY;
        return prefs.getBoolean("schedule_day_" + idx, true);
    }

    private int parseMinutes(String hhmm) {
        try {
            String[] p = hhmm.split(":");
            int h = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            return Math.max(0, Math.min(1439, h * 60 + m));
        } catch (Throwable t) {
            return 0;
        }
    }

    private void processExternalCommand() {
        if (prefs == null) return;
        String cmd = prefs.getString("command", "");
        if (cmd == null || cmd.isEmpty()) return;
        prefs.edit().remove("command").apply();
        if ("pause".equals(cmd)) pauseByUser();
        else if ("resume".equals(cmd)) resumeByUser();
        else if ("stop".equals(cmd)) stopByUser();
        else if ("reload".equals(cmd)) {
            if (overlay != null) overlay.setKeepScreenOn(prefs.getBoolean("keep_awake", true));
            evaluateSchedule();
            updateOverlay();
        }
    }

    private void ensureOverlay() {
        if (overlay != null || wm == null || state == State.STOPPED) return;
        try {
            final LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(12, 8, 12, 8);
            box.setBackgroundColor(Color.argb(220, 35, 35, 35));
            box.setKeepScreenOn(prefs.getBoolean("keep_awake", true));

            overlayStatus = new TextView(this);
            overlayStatus.setTextColor(Color.WHITE);
            overlayStatus.setTextSize(13);
            overlayStatus.setPadding(8, 4, 8, 7);
            box.addView(overlayStatus);

            LinearLayout buttons = new LinearLayout(this);
            Button resume = new Button(this);
            resume.setText("继续");
            resume.setOnClickListener(v -> resumeByUser());
            Button pause = new Button(this);
            pause.setText("暂停");
            pause.setOnClickListener(v -> pauseByUser());
            Button stop = new Button(this);
            stop.setText("停止");
            stop.setOnClickListener(v -> stopByUser());
            buttons.addView(resume);
            buttons.addView(pause);
            buttons.addView(stop);
            box.addView(buttons);

            overlayLp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            overlayLp.gravity = Gravity.TOP | Gravity.START;

            int sw = getResources().getDisplayMetrics().widthPixels;
            int sh = getResources().getDisplayMetrics().heightPixels;
            int savedX = prefs.getInt("overlay_x", Math.max(0, sw - 560));
            int savedY = prefs.getInt("overlay_y", 650);
            overlayLp.x = Math.max(0, Math.min(savedX, Math.max(0, sw - 360)));
            overlayLp.y = Math.max(0, Math.min(savedY, Math.max(0, sh - 240)));

            // Only the header is draggable, so buttons receive normal click events.
            overlayStatus.setOnTouchListener(new View.OnTouchListener() {
                private float downX, downY;
                private int startX, startY;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downX = e.getRawX();
                            downY = e.getRawY();
                            startX = overlayLp.x;
                            startY = overlayLp.y;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            int sw = getResources().getDisplayMetrics().widthPixels;
                            int sh = getResources().getDisplayMetrics().heightPixels;
                            overlayLp.x = Math.max(0, Math.min(startX + Math.round(e.getRawX() - downX), Math.max(0, sw - 360)));
                            overlayLp.y = Math.max(0, Math.min(startY + Math.round(e.getRawY() - downY), Math.max(0, sh - 240)));
                            try { wm.updateViewLayout(box, overlayLp); } catch (Throwable ignored) {}
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            prefs.edit().putInt("overlay_x", overlayLp.x).putInt("overlay_y", overlayLp.y).apply();
                            return true;
                        default:
                            return false;
                    }
                }
            });

            wm.addView(box, overlayLp);
            overlay = box;
            log("OVERLAY_CREATED x=" + overlayLp.x + " y=" + overlayLp.y);
            updateOverlay();
        } catch (Throwable t) {
            overlay = null;
            overlayStatus = null;
            log("OVERLAY_CREATE_FAIL " + t.getClass().getSimpleName());
            increment("stat_error");
            alertError("悬浮窗异常", "悬浮窗创建失败，请检查无障碍服务。" );
        }
    }

    private void refreshOverlayIfNeeded() {
        if (state == State.STOPPED) {
            removeOverlay();
            return;
        }
        if (overlay == null) ensureOverlay();
        else updateOverlay();
    }

    private void removeOverlay() {
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Throwable ignored) {}
        }
        overlay = null;
        overlayStatus = null;
    }

    private void updateOverlay() {
        if (overlayStatus == null) return;
        String label;
        switch (state) {
            case RUNNING: label = "运行中"; break;
            case USER_PAUSED: label = "人工暂停"; break;
            case SCHEDULE_WAIT: label = "定时等待"; break;
            case SCHEDULE_ENDED: label = "定时结束"; break;
            case TEMP_ENDED: label = "临时运行结束"; break;
            case OFFER_FROZEN: label = "Offer已发现"; break;
            case ERROR_PAUSED: label = "异常暂停"; break;
            default: label = "已停止";
        }

        String window = "";
        if (prefs.getBoolean("temp_session", false)) {
            long until = prefs.getLong("temp_until", 0L);
            if (until > System.currentTimeMillis()) {
                String t = new SimpleDateFormat("HH:mm", Locale.US).format(new Date(until));
                window = " | 至" + t;
            }
        } else if (prefs.getBoolean("schedule_enabled", false)) {
            window = " | " + prefs.getString("schedule_start", "10:30") + "-" + prefs.getString("schedule_end", "21:30");
        }

        long age = lastProgressAt == 0L ? 0L : Math.max(0L, (System.currentTimeMillis() - lastProgressAt) / 1000L);
        overlayStatus.setText("DD Alert: " + label + " | D" + (currentDateIndex + 1) + window + "\n最后进展 " + age + "s 前");
    }

    private void pauseByUser() {
        if (state == State.STOPPED) return;
        state = State.USER_PAUSED;
        cancelPendingScan();
        waitingForDateSettle = false;
        settleDeadlineAt = 0L;
        clearOfferCandidate();
        log("USER_PAUSE");
        setServiceStateText();
        ensureOverlay();
        updateOverlay();
    }

    private void resumeByUser() {
        prefs.edit().putBoolean("user_stopped", false).apply();
        scheduleDueNotified = false;

        if (!isRunWindowAllowedNow()) {
            state = State.SCHEDULE_WAIT;
            resetScannerForResume();
            log("USER_RESUME_BLOCKED schedule");
            setServiceStateText();
            ensureOverlay();
            updateOverlay();
            return;
        }

        state = State.RUNNING;
        resetScannerForResume();
        log("USER_RESUME");
        setServiceStateText();
        ensureOverlay();
        updateOverlay();
        scheduleScan(120L);
    }

    private void stopByUser() {
        if (state != State.STOPPED) log("USER_STOP overlay");
        state = State.STOPPED;
        cancelPendingScan();
        waitingForDateSettle = false;
        settleDeadlineAt = 0L;
        expectedAutoDateIndex = -1;
        selfEventUntil = 0L;
        manualHoldUntil = 0L;
        clearOfferCandidate();
        prefs.edit()
                .putBoolean("user_stopped", true)
                .putBoolean("temp_session", false)
                .remove("temp_until")
                .putString("service_state", "已停止 · Pure Alert v1.1.11")
                .apply();
        removeOverlay();
    }

    private void setServiceStateText() {
        if (prefs == null) return;
        String label;
        switch (state) {
            case RUNNING: label = "运行中"; break;
            case USER_PAUSED: label = "人工暂停"; break;
            case SCHEDULE_WAIT: label = "定时等待"; break;
            case SCHEDULE_ENDED: label = "定时结束"; break;
            case TEMP_ENDED: label = "临时运行结束"; break;
            case OFFER_FROZEN: label = "Offer已发现"; break;
            case ERROR_PAUSED: label = "异常暂停"; break;
            default: label = "已停止";
        }
        prefs.edit().putString("service_state", label + " · Pure Alert v1.1.11").apply();
    }

    private void sendOfferAlert(String title, String body) {
        if (prefs.getBoolean("vibrate", true)) vibrate();
        if (prefs.getBoolean("sound", true)) playSound();
        notifyMessage(CHANNEL_OFFER, title, body, 2001);
    }

    private void alertError(String title, String body) {
        vibrate();
        notifyMessage(CHANNEL_ERROR, "DD Alert Watcher：" + title, body, 2002);
    }

    private void notifyInfo(String title, String body, int id) {
        notifyMessage(CHANNEL_ERROR, title, body, id);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel offer = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
        offer.enableVibration(true);
        offer.setDescription("Any Offer alerts from DD Alert Watcher");
        NotificationChannel error = new NotificationChannel(CHANNEL_ERROR, "Monitor Status", NotificationManager.IMPORTANCE_HIGH);
        error.enableVibration(true);
        nm.createNotificationChannel(offer);
        nm.createNotificationChannel(error);
    }

    private void notifyMessage(String channel, String title, String body, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(this, channel)
                : new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(id, b.build());
    }

    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            long[] pattern = new long[]{0, 350, 180, 350, 180, 700};
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            else v.vibrate(pattern, -1);
        } catch (Throwable ignored) {}
    }

    private void playSound() {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) {}
    }

    private void increment(String key) {
        if (prefs == null) return;
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply();
    }

    private void log(String msg) {
        if (prefs == null) return;
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = ts + " " + msg;
        String old = prefs.getString("logs", "");
        String all = line + (old.isEmpty() ? "" : "\n" + old);
        String[] lines = all.split("\n");
        StringBuilder sb = new StringBuilder();
        int max = Math.min(lines.length, 220);
        for (int i = 0; i < max; i++) {
            if (i > 0) sb.append('\n');
            sb.append(lines[i]);
        }
        prefs.edit().putString("logs", sb.toString()).apply();
    }

    public static boolean isServiceConnected() {
        return INSTANCE != null;
    }

    public static void requestPause(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.pauseByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "pause").apply();
    }

    public static void requestResume(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.resumeByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("user_stopped", false)
                .putString("command", "resume")
                .putString("service_state", "等待无障碍服务连接 · Pure Alert v1.1.11")
                .apply();
    }

    public static void requestStop(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.stopByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("user_stopped", true)
                .putBoolean("temp_session", false)
                .remove("temp_until")
                .putString("command", "stop")
                .putString("service_state", "已停止 · Pure Alert v1.1.11")
                .apply();
    }

    public static void requestReload(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) {
            if (s.overlay != null) s.overlay.setKeepScreenOn(s.prefs.getBoolean("keep_awake", true));
            s.evaluateSchedule();
            s.updateOverlay();
            return;
        }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "reload").apply();
    }

    public static void requestTestAlert(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }
        try {
            Vibrator v = (Vibrator) c.getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                long[] pattern = new long[]{0, 300, 150, 500};
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
                else v.vibrate(pattern, -1);
            }
            Ringtone r = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            if (r != null) r.play();
        } catch (Throwable ignored) {}

        Intent intent = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(c, CHANNEL_OFFER)
                : new android.app.Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("测试：发现 Offer！")
                .setContentText("声音、震动、通知链正常。这个按钮不会改变扫描状态。")
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(2099, b.build());
    }

    private static class Snapshot {
        final List<String> texts = new ArrayList<>();
        boolean emptyPage;
        boolean errorLayer;
        boolean loadingLike;
        boolean offerCandidate;
        String offerEvidence = "none";

        static Snapshot from(AccessibilityNodeInfo root) {
            Snapshot s = new Snapshot();
            if (root == null) return s;
            ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
            q.add(root);
            int guard = 0;
            while (!q.isEmpty() && guard++ < 1200) {
                AccessibilityNodeInfo n = q.removeFirst();
                String t = safe(n.getText());
                String d = safe(n.getContentDescription());
                if (!t.isEmpty()) s.texts.add(t);
                if (!d.isEmpty() && !d.equals(t)) s.texts.add(d);
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo child = n.getChild(i);
                    if (child != null) q.addLast(child);
                }
            }
            s.classify();
            return s;
        }

        void classify() {
            String all = String.join(" \n ", texts).toLowerCase(Locale.US);

            emptyPage = containsAny(all,
                    "there's nothing available to schedule today",
                    "there is nothing available to schedule today",
                    "nothing available to schedule",
                    "there's nothing available",
                    "there is nothing available",
                    "no offers available");

            errorLayer = (all.contains("something went wrong") || all.contains("unexpected error")) && all.contains("retry");
            loadingLike = all.contains("loading") || all.contains("please wait");
            if (emptyPage || errorLayer || loadingLike) return;

            boolean offersPage = looksLikeOffersText(all);
            if (!offersPage) return;

            boolean money = MONEY.matcher(all).matches();
            boolean distance = DISTANCE.matcher(all).matches();
            boolean claim = containsAny(all, "claim and schedule", "claim offer", "claim");
            boolean pickup = containsAny(all, "pickup", "pick up", "dropoff", "drop off");
            boolean catering = all.contains("catering");

            // No generic "structure" heuristic: that caused false Offer=1 reports with no visible offer.
            if (claim) {
                offerCandidate = true;
                offerEvidence = "claim";
            } else if (money && (distance || pickup || catering)) {
                offerCandidate = true;
                offerEvidence = distance ? "money+distance" : (pickup ? "money+pickup" : "money+catering");
            }
        }

        boolean looksLikeOffersPage() {
            String all = String.join(" ", texts).toLowerCase(Locale.US);
            return looksLikeOffersText(all);
        }

        boolean hasErrorLayer() { return errorLayer; }

        String fingerprint() {
            StringBuilder sb = new StringBuilder();
            int n = Math.min(texts.size(), 28);
            for (int i = 0; i < n; i++) sb.append(texts.get(i)).append('|');
            return Integer.toHexString(sb.toString().hashCode());
        }

        static boolean looksLikeOffersText(String all) {
            return all.contains("offers") && (all.contains("schedule") || all.contains("my schedule") || all.contains("dash"));
        }

        static String safe(CharSequence c) {
            return c == null ? "" : c.toString().trim();
        }

        static boolean containsAny(String s, String... parts) {
            for (String p : parts) if (s.contains(p)) return true;
            return false;
        }
    }
}
