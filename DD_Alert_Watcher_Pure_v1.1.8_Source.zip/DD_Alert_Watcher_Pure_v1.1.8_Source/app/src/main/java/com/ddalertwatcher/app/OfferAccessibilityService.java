package com.ddalertwatcher.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Pure Alert stable-core branch.
 *
 * Scan behavior intentionally follows the proven v1.1.7 field model:
 * - fixed D1-D7 Samsung date-row taps
 * - 800 ms self-event suppression
 * - manual interaction yields 3.5 s
 * - event-driven settle checks with bounded slow-load guard
 * - ANY real offer freezes automatic scanning; Claim remains manual
 *
 * v1.1.11 changes are kept outside that core as much as possible:
 * schedule gate, overlay lifecycle/buttons, compact logs and slightly shorter waits.
 */
public class OfferAccessibilityService extends AccessibilityService {
    private static volatile OfferAccessibilityService INSTANCE;
    private static final String DASHER_PACKAGE = "com.doordash.driverapp";
    private static final String PREFS = MainActivity.PREFS;
    private static final String CHANNEL_OFFER = "offer_alert";
    private static final String CHANNEL_ERROR = "monitor_error";

    // v1.1.7 behavior anchors. Only settle/round waits are slightly shortened.
    private static final long SELF_EVENT_WINDOW_MS = 800L;
    private static final long MANUAL_HOLD_MS = 3500L;
    private static final long FIRST_SETTLE_CHECK_MS = 620L;
    private static final long FOLLOWUP_SETTLE_MS = 430L;
    private static final long MAX_SETTLE_MS = 1900L;
    private static final long ROUND_PAUSE_MS = 550L;
    private static final long WATCHDOG_STALL_MS = 18_000L;
    private static final long WATCHDOG_TICK_MS = 2_000L;

    private enum State { RUNNING, USER_PAUSED, SCHEDULE_WAIT, OFFER_FROZEN, ERROR_PAUSED, STOPPED }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private WindowManager wm;
    private View overlay;
    private TextView overlayStatus;
    private WindowManager.LayoutParams overlayLp;
    private State state = State.STOPPED;

    // Scanner state. Keep this small and deterministic.
    private int currentDateIndex = -1;
    private int nextDateIndex = 0;
    private int scannedThisRound = 0;
    private long expectedAutoEventUntil = 0L;
    private int expectedAutoDateIndex = -1;
    private long manualHoldUntil = 0L;
    private long settleDeadlineAt = 0L;
    private String preTapDateSignature = "";
    private int settleChecks = 0;
    private boolean scanScheduled = false;
    private long scanDueAt = 0L;
    private long lastProgressAt = 0L;
    private boolean dasherForeground = false;
    private boolean onOffersPage = false;
    private boolean scheduleDueNotified = false;
    private long lastOfferAt = 0L;
    private String lastOfferFingerprint = "";

    private final Runnable scanRunnable = new Runnable() {
        @Override public void run() {
            scanScheduled = false;
            scanDueAt = 0L;
            scanTick();
        }
    };

    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            try {
                processExternalCommand();
                evaluateSchedule();
                refreshOverlayIfNeeded();
                if (state == State.RUNNING && isScheduleAllowedNow() && dasherForeground && onOffersPage) {
                    long now = System.currentTimeMillis();
                    if (lastProgressAt > 0 && now - lastProgressAt >= WATCHDOG_STALL_MS) {
                        increment("stat_stall");
                        logCritical("WATCHDOG_STALL " + ((now - lastProgressAt) / 1000L) + "s");
                        resetScannerCore();
                        resetWatchdogClock();
                        scheduleScan(80L);
                    }
                }
            } catch (Throwable t) {
                increment("stat_error");
                logCritical("WATCHDOG_ERROR " + t.getClass().getSimpleName());
            } finally {
                handler.postDelayed(this, WATCHDOG_TICK_MS);
            }
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannels();
        boolean stopped = prefs.getBoolean("user_stopped", false);
        state = stopped ? State.STOPPED : (isScheduleAllowedNow() ? State.RUNNING : State.SCHEDULE_WAIT);
        resetScannerCore();
        resetWatchdogClock();
        setServiceState(stopped ? "已停止" : (state == State.RUNNING ? "运行中" : "定时等待"));
        logCritical("SERVICE_CONNECTED v1.1.11");
        if (state != State.STOPPED) ensureOverlay();
        handler.removeCallbacks(watchdog);
        handler.post(watchdog);
        if (state == State.RUNNING) scheduleScan(180L);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || prefs == null) return;
        processExternalCommand();

        CharSequence pkg = event.getPackageName();
        boolean fromDasher = pkg != null && DASHER_PACKAGE.contentEquals(pkg);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        CharSequence rootPkg = root == null ? null : root.getPackageName();
        boolean rootDasher = rootPkg != null && DASHER_PACKAGE.contentEquals(rootPkg);

        // Ignore our own overlay/SystemUI events while Dasher remains the active root.
        if (!fromDasher && !rootDasher) {
            if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                dasherForeground = false;
                onOffersPage = false;
                updateOverlay();
            }
            return;
        }

        dasherForeground = true;
        Snapshot snap = Snapshot.from(root, getResources().getDisplayMetrics().heightPixels);
        onOffersPage = snap.looksLikeOffersPage();

        if (state == State.RUNNING && onOffersPage) {
            if (snap.errorLayer) {
                pauseForDoorDashError();
                return;
            }
            if (detectAndFreezeOffer(snap)) return;
            handleManualDateEvent(event);
            // A real content event can settle a date faster than waiting for the timer.
            if (settleDeadlineAt > 0L) scheduleScan(70L);
            else if (!scanScheduled) scheduleScan(90L);
        }

        if (state == State.SCHEDULE_WAIT && isScheduleAllowedNow() && onOffersPage) {
            state = State.RUNNING;
            scheduleDueNotified = false;
            resetScannerCore();
            resetWatchdogClock();
            setServiceState("运行中");
            logCritical("SCHEDULE_START");
            ensureOverlay();
            scheduleScan(100L);
        }
        updateOverlay();
    }

    @Override public void onInterrupt() { logCritical("SERVICE_INTERRUPTED"); }

    @Override public void onDestroy() {
        cancelPendingScan();
        handler.removeCallbacks(watchdog);
        removeOverlay(false);
        if (prefs != null) setServiceState("服务已停止");
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }

    /** Swiping DD Alert Watcher away from Recents means a real exit. */
    @Override public void onTaskRemoved(Intent rootIntent) {
        if (prefs != null) stopByUser("task-removed");
        super.onTaskRemoved(rootIntent);
    }

    private void handleManualDateEvent(AccessibilityEvent event) {
        int type = event.getEventType();
        // v1.1.10 regression: WINDOW_CONTENT_CHANGED was incorrectly treated as a finger tap.
        // Manual date ownership only comes from actual click/selection events.
        if (type != AccessibilityEvent.TYPE_VIEW_CLICKED && type != AccessibilityEvent.TYPE_VIEW_SELECTED) return;
        AccessibilityNodeInfo src = event.getSource();
        if (src == null || !looksLikeDateRowNode(src)) return;

        long now = System.currentTimeMillis();
        // v1.1.7 SelfEventFix: suppress ALL delayed date-row events in this window,
        // not only the event that happens to map to expectedAutoDateIndex.
        if (now <= expectedAutoEventUntil) return;

        int idx = dateIndexFromNode(src);
        manualHoldUntil = now + MANUAL_HOLD_MS;
        expectedAutoDateIndex = -1;
        expectedAutoEventUntil = 0L;
        settleDeadlineAt = 0L;
        cancelPendingScan();
        logCritical(idx >= 0 ? "MANUAL_DATE D" + (idx + 1) : "MANUAL_DATE");
        scheduleScan(MANUAL_HOLD_MS + 60L);
    }

    private void scanTick() {
        processExternalCommand();
        evaluateSchedule();
        if (state != State.RUNNING || !isScheduleAllowedNow()) return;

        long now = System.currentTimeMillis();
        if (now < manualHoldUntil) {
            scheduleScan(manualHoldUntil - now + 60L);
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        CharSequence rootPkg = root == null ? null : root.getPackageName();
        dasherForeground = rootPkg != null && DASHER_PACKAGE.contentEquals(rootPkg);
        if (!dasherForeground) {
            onOffersPage = false;
            updateOverlay();
            scheduleScan(850L);
            return;
        }

        Snapshot snap = Snapshot.from(root, getResources().getDisplayMetrics().heightPixels);
        onOffersPage = snap.looksLikeOffersPage();
        if (!onOffersPage) {
            updateOverlay();
            scheduleScan(700L);
            return;
        }
        if (snap.errorLayer) {
            pauseForDoorDashError();
            return;
        }
        if (detectAndFreezeOffer(snap)) return;

        if (settleDeadlineAt > 0L) {
            if (snap.emptyPage) {
                finishDateAndAdvance();
                return;
            }
            String sig = snap.dateStateSignature();
            if (!sig.isEmpty() && !sig.equals(preTapDateSignature)) {
                // Date selection/content changed. Give one short follow-up read for a late offer card.
                if (settleChecks == 0) {
                    settleChecks = 1;
                    scheduleScan(180L);
                    return;
                }
                finishDateAndAdvance();
                return;
            }
            if (now >= settleDeadlineAt) {
                finishDateAndAdvance();
                return;
            }
            settleChecks++;
            scheduleScan(FOLLOWUP_SETTLE_MS);
            return;
        }

        int enabled = countEnabledDates();
        if (enabled <= 0) {
            state = State.USER_PAUSED;
            setServiceState("人工暂停 · 未选择日期");
            logCritical("NO_SCAN_DAYS");
            updateOverlay();
            return;
        }

        int idx = findEnabledFrom(nextDateIndex);
        if (idx < 0) return;
        tapDate(idx, snap.dateStateSignature());
    }

    private void tapDate(int index, String beforeSignature) {
        // Exact v1.1.7 Galaxy A15 coordinates observed in working logs.
        float x = 101f + 135f * index;
        float y = 349f;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 55L);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();

        currentDateIndex = index;
        expectedAutoDateIndex = index;
        expectedAutoEventUntil = System.currentTimeMillis() + SELF_EVENT_WINDOW_MS;
        preTapDateSignature = beforeSignature == null ? "" : beforeSignature;
        settleDeadlineAt = System.currentTimeMillis() + MAX_SETTLE_MS;
        settleChecks = 0;

        boolean sent = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
                scheduleScan(FIRST_SETTLE_CHECK_MS);
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
                finishDateAndAdvance();
            }
        }, null);
        if (!sent) finishDateAndAdvance();
    }

    private void finishDateAndAdvance() {
        settleDeadlineAt = 0L;
        settleChecks = 0;
        expectedAutoDateIndex = -1;
        // Keep the suppression time itself intact until it expires; delayed Compose events are expected.
        markProgress();
        scannedThisRound++;
        nextDateIndex = (currentDateIndex + 1) % 7;

        int enabled = countEnabledDates();
        if (scannedThisRound >= enabled) {
            scannedThisRound = 0;
            increment("stat_round");
            logCritical("ROUND " + prefs.getInt("stat_round", 0) + " complete");
            scheduleScan(ROUND_PAUSE_MS);
        } else {
            scheduleScan(35L);
        }
        updateOverlay();
    }

    private boolean detectAndFreezeOffer(Snapshot snap) {
        if (snap.emptyPage || snap.loadingLike || snap.errorLayer || !snap.offerCandidate) return false;
        long now = System.currentTimeMillis();
        String fp = snap.offerFingerprint();
        if (fp.equals(lastOfferFingerprint) && now - lastOfferAt < 8_000L) return true;
        lastOfferFingerprint = fp;
        lastOfferAt = now;
        state = State.OFFER_FROZEN;
        cancelPendingScan();
        increment("stat_offer");
        logCritical("OFFER_FOUND D" + (Math.max(0, currentDateIndex) + 1));
        setServiceState("Offer 已发现 · 已冻结");
        sendOfferAlert();
        ensureOverlay();
        updateOverlay();
        return true;
    }

    private void pauseForDoorDashError() {
        if (state == State.ERROR_PAUSED) return;
        state = State.ERROR_PAUSED;
        cancelPendingScan();
        increment("stat_error");
        logCritical("DOORDASH_RETRY_ERROR");
        setServiceState("异常暂停");
        alertError("DoorDash 页面异常", "检测到 Retry/错误页面，已暂停。处理后手动点继续。", 2102);
        ensureOverlay();
        updateOverlay();
    }

    private void scheduleScan(long delayMs) {
        if (state != State.RUNNING) return;
        long due = System.currentTimeMillis() + Math.max(0L, delayMs);
        if (scanScheduled) {
            // Allow real Accessibility events to wake an existing long settle timer early.
            if (scanDueAt > 0L && due + 20L < scanDueAt) {
                handler.removeCallbacks(scanRunnable);
            } else {
                return;
            }
        }
        scanScheduled = true;
        scanDueAt = due;
        handler.postDelayed(scanRunnable, Math.max(0L, delayMs));
    }

    private void cancelPendingScan() {
        handler.removeCallbacks(scanRunnable);
        scanScheduled = false;
        scanDueAt = 0L;
    }

    private void resetScannerCore() {
        cancelPendingScan();
        currentDateIndex = -1;
        nextDateIndex = 0;
        scannedThisRound = 0;
        expectedAutoDateIndex = -1;
        expectedAutoEventUntil = 0L;
        manualHoldUntil = 0L;
        settleDeadlineAt = 0L;
        preTapDateSignature = "";
        settleChecks = 0;
    }

    private int findEnabledFrom(int start) {
        for (int i = 0; i < 7; i++) {
            int idx = (start + i) % 7;
            if (prefs.getBoolean("scan_d" + (idx + 1), true)) return idx;
        }
        return -1;
    }

    private int countEnabledDates() {
        int n = 0;
        for (int i = 0; i < 7; i++) if (prefs.getBoolean("scan_d" + (i + 1), true)) n++;
        return n;
    }

    private void markProgress() { lastProgressAt = System.currentTimeMillis(); }
    private void resetWatchdogClock() { lastProgressAt = System.currentTimeMillis(); }

    // ---------------- Schedule wrapper ----------------

    private void evaluateSchedule() {
        if (prefs == null || state == State.STOPPED || state == State.USER_PAUSED ||
                state == State.OFFER_FROZEN || state == State.ERROR_PAUSED) return;

        boolean allowed = isScheduleAllowedNow();
        if (!allowed && state == State.RUNNING) {
            state = State.SCHEDULE_WAIT;
            cancelPendingScan();
            resetScannerCore();
            setServiceState("定时等待");
            logCritical("SCHEDULE_END");
            updateOverlay();
            return;
        }
        if (allowed && state == State.SCHEDULE_WAIT) {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            CharSequence p = root == null ? null : root.getPackageName();
            boolean dd = p != null && DASHER_PACKAGE.contentEquals(p);
            Snapshot snap = dd ? Snapshot.from(root, getResources().getDisplayMetrics().heightPixels) : new Snapshot();
            if (dd && snap.looksLikeOffersPage()) {
                state = State.RUNNING;
                dasherForeground = true;
                onOffersPage = true;
                scheduleDueNotified = false;
                resetScannerCore();
                resetWatchdogClock();
                setServiceState("运行中");
                logCritical("SCHEDULE_START");
                ensureOverlay();
                scheduleScan(100L);
            } else if (!scheduleDueNotified) {
                scheduleDueNotified = true;
                notifyInfo("DD Alert 定时开始", "运行时间已到，请打开 Dasher → Schedule → Offers。", 2201);
            }
        }
    }

    private boolean isScheduleAllowedNow() {
        if (prefs == null) return true;
        long now = System.currentTimeMillis();
        long tempUntil = prefs.getLong("temp_until", 0L);
        if (tempUntil > now) return true;
        if (tempUntil > 0L && tempUntil <= now) prefs.edit().remove("temp_until").apply();
        if (!prefs.getBoolean("schedule_enabled", false)) return true;

        Calendar c = Calendar.getInstance();
        int minute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        int start = parseMinutes(prefs.getString("schedule_start", "10:30"));
        int end = parseMinutes(prefs.getString("schedule_end", "21:30"));
        if (start == end) return scheduleDayEnabled(c);
        if (start < end) return minute >= start && minute < end && scheduleDayEnabled(c);
        // Cross-midnight: after midnight belongs to the previous start day.
        if (minute >= start) return scheduleDayEnabled(c);
        if (minute < end) {
            Calendar prev = (Calendar) c.clone();
            prev.add(Calendar.DAY_OF_YEAR, -1);
            return scheduleDayEnabled(prev);
        }
        return false;
    }

    private boolean scheduleDayEnabled(Calendar c) {
        // Calendar: Sun=1..Sat=7; UI prefs: Mon=0..Sun=6.
        int dow = c.get(Calendar.DAY_OF_WEEK);
        int idx = dow == Calendar.SUNDAY ? 6 : dow - Calendar.MONDAY;
        return prefs.getBoolean("schedule_day_" + idx, true);
    }

    private int parseMinutes(String hhmm) {
        try {
            String[] p = hhmm.split(":");
            return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
        } catch (Throwable ignored) { return 0; }
    }

    // ---------------- Overlay ----------------

    private void ensureOverlay() {
        if (state == State.STOPPED || overlay != null || wm == null) return;
        try {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(10, 8, 10, 8);
            box.setBackgroundColor(0xDD202124);
            box.setKeepScreenOn(prefs.getBoolean("keep_awake", true));

            overlayStatus = new TextView(this);
            overlayStatus.setTextColor(Color.WHITE);
            overlayStatus.setTextSize(13);
            overlayStatus.setPadding(8, 6, 8, 8);
            box.addView(overlayStatus);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            Button resume = overlayButton("继续", v -> resumeByUser());
            Button pause = overlayButton("暂停", v -> pauseByUser());
            Button stop = overlayButton("停止", v -> stopByUser("overlay"));
            row.addView(resume);
            row.addView(pause);
            row.addView(stop);
            box.addView(row);

            overlayLp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            overlayLp.gravity = Gravity.TOP | Gravity.START;
            int sw = getResources().getDisplayMetrics().widthPixels;
            int sh = getResources().getDisplayMetrics().heightPixels;
            overlayLp.x = clamp(prefs.getInt("overlay_x", Math.max(8, sw / 2 - 20)), 0, Math.max(0, sw - 360));
            overlayLp.y = clamp(prefs.getInt("overlay_y", Math.max(80, sh / 3)), 0, Math.max(0, sh - 260));

            // Only header is draggable; buttons get untouched click events.
            overlayStatus.setOnTouchListener(new View.OnTouchListener() {
                float downX, downY; int startX, startY; boolean moved;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downX = e.getRawX(); downY = e.getRawY(); startX = overlayLp.x; startY = overlayLp.y; moved = false; return true;
                        case MotionEvent.ACTION_MOVE:
                            int nx = startX + Math.round(e.getRawX() - downX);
                            int ny = startY + Math.round(e.getRawY() - downY);
                            if (Math.abs(nx - startX) > 5 || Math.abs(ny - startY) > 5) moved = true;
                            overlayLp.x = clamp(nx, 0, Math.max(0, sw - 260));
                            overlayLp.y = clamp(ny, 0, Math.max(0, sh - 150));
                            try { wm.updateViewLayout(box, overlayLp); } catch (Throwable ignored) {}
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            prefs.edit().putInt("overlay_x", overlayLp.x).putInt("overlay_y", overlayLp.y).apply();
                            return true;
                    }
                    return false;
                }
            });

            wm.addView(box, overlayLp);
            overlay = box;
            logCritical("OVERLAY_CREATED");
            updateOverlay();
        } catch (Throwable t) {
            increment("stat_error");
            logCritical("OVERLAY_FAIL " + t.getClass().getSimpleName());
        }
    }

    private Button overlayButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(14, 0, 14, 0);
        b.setOnClickListener(l);
        return b;
    }

    private void refreshOverlayIfNeeded() {
        if (state == State.STOPPED) { if (overlay != null) removeOverlay(false); return; }
        if (overlay == null) ensureOverlay(); else updateOverlay();
    }

    private void removeOverlay(boolean record) {
        if (wm != null && overlay != null) {
            try { wm.removeViewImmediate(overlay); } catch (Throwable t) {
                try { wm.removeView(overlay); } catch (Throwable ignored) {}
            }
        }
        overlay = null;
        overlayStatus = null;
        if (record && prefs != null) logCritical("OVERLAY_REMOVED");
    }

    private void updateOverlay() {
        if (overlayStatus == null) return;
        String label;
        switch (state) {
            case RUNNING: label = "运行中"; break;
            case USER_PAUSED: label = "人工暂停"; break;
            case SCHEDULE_WAIT: label = "定时等待"; break;
            case OFFER_FROZEN: label = "发现 Offer · 已冻结"; break;
            case ERROR_PAUSED: label = "异常暂停"; break;
            default: label = "已停止";
        }
        String day = currentDateIndex >= 0 ? "D" + (currentDateIndex + 1) : "D-";
        String time = prefs.getBoolean("schedule_enabled", false)
                ? " | " + prefs.getString("schedule_start", "10:30") + "-" + prefs.getString("schedule_end", "21:30") : "";
        overlayStatus.setText("DD Alert  " + label + " | " + day + time);
    }

    private void pauseByUser() {
        if (state == State.STOPPED || state == State.USER_PAUSED) return;
        state = State.USER_PAUSED;
        cancelPendingScan();
        setServiceState("人工暂停");
        logCritical("USER_PAUSE");
        ensureOverlay();
        updateOverlay();
    }

    private void resumeByUser() {
        if (prefs == null) return;
        prefs.edit().putBoolean("user_stopped", false).apply();
        if (!isScheduleAllowedNow()) {
            state = State.SCHEDULE_WAIT;
            setServiceState("定时等待");
            logCritical("USER_RESUME_WAIT_SCHEDULE");
            ensureOverlay();
            updateOverlay();
            return;
        }
        state = State.RUNNING;
        resetScannerCore();
        resetWatchdogClock();
        setServiceState("运行中");
        logCritical("USER_RESUME");
        ensureOverlay();
        updateOverlay();
        scheduleScan(100L);
    }

    private void stopByUser(String source) {
        if (prefs == null) return;
        state = State.STOPPED;
        resetScannerCore();
        prefs.edit().putBoolean("user_stopped", true).apply();
        setServiceState("已停止");
        logCritical("USER_STOP " + source);
        removeOverlay(true);
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(v, hi)); }

    // ---------------- Notifications / settings / commands ----------------

    private void processExternalCommand() {
        if (prefs == null) return;
        String cmd = prefs.getString("command", "");
        if (cmd == null || cmd.isEmpty()) return;
        prefs.edit().remove("command").apply();
        if ("pause".equals(cmd)) pauseByUser();
        else if ("resume".equals(cmd)) resumeByUser();
        else if ("stop".equals(cmd)) stopByUser("main");
        else if ("reload".equals(cmd)) {
            if (overlay != null) overlay.setKeepScreenOn(prefs.getBoolean("keep_awake", true));
            evaluateSchedule();
            updateOverlay();
        }
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel offer = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
        offer.enableVibration(true);
        NotificationChannel error = new NotificationChannel(CHANNEL_ERROR, "Monitor Status", NotificationManager.IMPORTANCE_HIGH);
        error.enableVibration(true);
        nm.createNotificationChannel(offer);
        nm.createNotificationChannel(error);
    }

    private void sendOfferAlert() {
        if (prefs.getBoolean("vibrate", true)) vibrate();
        if (prefs.getBoolean("sound", true)) playSound();
        notifyMessage(CHANNEL_OFFER, "发现 DoorDash Offer！", "扫描已冻结。请立即查看 Dasher，处理后手动点继续。", 2101);
    }

    private void alertError(String title, String body, int id) {
        vibrate();
        notifyMessage(CHANNEL_ERROR, title, body, id);
    }

    private void notifyInfo(String title, String body, int id) { notifyMessage(CHANNEL_ERROR, title, body, id); }

    private void notifyMessage(String channel, String title, String body, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent launch = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, id, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(this, channel)
                : new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title).setContentText(body)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi).setAutoCancel(true);
        nm.notify(id, b.build());
    }

    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 280, 120, 380, 120, 650}, -1));
            else v.vibrate(new long[]{0, 280, 120, 380, 120, 650}, -1);
        } catch (Throwable ignored) {}
    }

    private void playSound() {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) {}
    }

    private void setServiceState(String s) { prefs.edit().putString("service_state", s + " · v1.1.11").apply(); }
    private void increment(String key) { prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply(); }

    private void logCritical(String msg) {
        if (prefs == null) return;
        String ts = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(new Date());
        String line = ts + "  " + msg;
        String old = prefs.getString("logs", "");
        String all = line + (old.isEmpty() ? "" : "\n" + old);
        String[] lines = all.split("\n");
        StringBuilder sb = new StringBuilder();
        int max = Math.min(lines.length, 80);
        for (int i = 0; i < max; i++) {
            if (i > 0) sb.append('\n');
            sb.append(lines[i]);
        }
        prefs.edit().putString("logs", sb.toString()).apply();
    }

    private int dateIndexFromNode(AccessibilityNodeInfo node) {
        if (node == null) return -1;
        Rect r = new Rect(); node.getBoundsInScreen(r);
        if (r.isEmpty()) return -1;
        int h = getResources().getDisplayMetrics().heightPixels;
        if (r.centerY() < h * 0.18f || r.centerY() > h * 0.43f) return -1;
        // Map to the exact v1.1.7 centers on the user's phone.
        int best = -1, bestDist = Integer.MAX_VALUE;
        for (int i = 0; i < 7; i++) {
            int d = Math.abs(r.centerX() - (101 + 135 * i));
            if (d < bestDist) { bestDist = d; best = i; }
        }
        return bestDist <= 95 ? best : -1;
    }

    private boolean looksLikeDateRowNode(AccessibilityNodeInfo node) {
        Rect r = new Rect(); node.getBoundsInScreen(r);
        int h = getResources().getDisplayMetrics().heightPixels;
        return !r.isEmpty() && r.centerY() > h * 0.18f && r.centerY() < h * 0.43f;
    }

    public static boolean isServiceConnected() { return INSTANCE != null; }

    public static void requestPause(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.pauseByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "pause").apply();
    }

    public static void requestResume(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.resumeByUser(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("user_stopped", false).putString("command", "resume").apply();
    }

    public static void requestStop(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.stopByUser("main"); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("user_stopped", true).putString("command", "stop").putString("service_state", "已停止 · v1.1.11").apply();
    }

    public static void requestReload(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) { s.processExternalCommand(); s.evaluateSchedule(); s.updateOverlay(); return; }
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "reload").apply();
    }

    public static void requestTestAlert(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, MODE_PRIVATE);
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true); nm.createNotificationChannel(ch);
        }
        if (p.getBoolean("vibrate", true)) {
            try {
                Vibrator v = (Vibrator) c.getSystemService(VIBRATOR_SERVICE);
                if (v != null) {
                    if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 250, 120, 450}, -1));
                    else v.vibrate(new long[]{0, 250, 120, 450}, -1);
                }
            } catch (Throwable ignored) {}
        }
        if (p.getBoolean("sound", true)) {
            try {
                Ringtone r = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
                if (r != null) r.play();
            } catch (Throwable ignored) {}
        }
        Intent intent = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 2099, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, CHANNEL_OFFER) : new android.app.Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("测试：发现 Offer！")
                .setContentText("提醒链正常。真实 Offer 会冻结 D1-D7 扫描，最终操作仍由你手动完成。")
                .setContentIntent(pi).setAutoCancel(true);
        nm.notify(2099, b.build());
    }

    // ---------------- Minimal snapshot: no miles / $/mi / detail parsing ----------------

    private static class Snapshot {
        private static final Pattern MONEY = Pattern.compile("\\$\\s*\\d+(?:\\.\\d{1,2})?");
        final List<String> texts = new ArrayList<>();
        final List<Node> nodes = new ArrayList<>();
        boolean emptyPage;
        boolean loadingLike;
        boolean errorLayer;
        boolean offersTitle;
        boolean offerCandidate;
        String moneyEvidence = "";
        int dateBandNodes = 0;
        int screenHeight = 1600;

        static Snapshot from(AccessibilityNodeInfo root, int height) {
            Snapshot s = new Snapshot();
            s.screenHeight = Math.max(1, height);
            if (root == null) return s;
            ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
            q.add(root);
            int guard = 0;
            while (!q.isEmpty() && guard++ < 1200) {
                AccessibilityNodeInfo n = q.removeFirst();
                String t = safe(n.getText());
                String d = safe(n.getContentDescription());
                Rect r = new Rect(); n.getBoundsInScreen(r);
                boolean selected = n.isSelected();
                boolean checked = n.isCheckable() && n.isChecked();
                if (!t.isEmpty()) s.texts.add(t);
                if (!d.isEmpty() && !d.equals(t)) s.texts.add(d);
                s.nodes.add(new Node(t, d, n.isClickable(), selected, checked, r));
                if (!r.isEmpty() && r.centerY() > s.screenHeight * 0.18f && r.centerY() < s.screenHeight * 0.43f) s.dateBandNodes++;
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) q.addLast(c);
                }
            }
            s.classify();
            return s;
        }

        void classify() {
            String all = String.join(" ", texts).toLowerCase(Locale.US);
            emptyPage = containsAny(all, "nothing available to schedule", "there's nothing available", "there is nothing available", "no offers available");
            loadingLike = containsAny(all, "loading", "please wait");
            errorLayer = containsAny(all, "something went wrong", "unexpected error") && all.contains("retry");
            offersTitle = all.contains("offers");

            if (emptyPage || loadingLike || errorLayer) return;

            boolean claimInContent = false;
            for (Node n : nodes) {
                if (n.bounds.isEmpty()) continue;
                float cy = n.bounds.centerY();
                if (cy < screenHeight * 0.34f || cy > screenHeight * 0.92f) continue;
                String s = (n.text + " " + n.desc).trim();
                if (s.isEmpty()) continue;
                if (MONEY.matcher(s).find()) {
                    moneyEvidence = s;
                    offerCandidate = true;
                    break;
                }
                String low = s.toLowerCase(Locale.US);
                if (low.contains("claim") || low.contains("claim and schedule")) claimInContent = true;
            }
            if (!offerCandidate && claimInContent) offerCandidate = true;
        }

        boolean looksLikeOffersPage() {
            // v1.1.10 was too strict (required Schedule/Dash words). The proven page can expose
            // only the Offers title plus date controls/empty message/card content.
            return emptyPage || offersTitle;
        }

        String dateStateSignature() {
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Node n : nodes) {
                if (n.bounds.isEmpty()) continue;
                float cy = n.bounds.centerY();
                if (cy < screenHeight * 0.18f || cy > screenHeight * 0.43f) continue;
                if (count++ > 50) break;
                sb.append(n.bounds.centerX()).append(':').append(n.selected ? 'S' : '-').append(n.checked ? 'C' : '-')
                        .append(':').append(n.text).append(':').append(n.desc).append('|');
            }
            return Integer.toHexString(sb.toString().hashCode());
        }

        String offerFingerprint() {
            StringBuilder sb = new StringBuilder();
            for (Node n : nodes) {
                if (n.bounds.isEmpty()) continue;
                float cy = n.bounds.centerY();
                if (cy < screenHeight * 0.34f || cy > screenHeight * 0.92f) continue;
                String s = (n.text + " " + n.desc).trim();
                if (!s.isEmpty()) sb.append(s).append('|');
                if (sb.length() > 600) break;
            }
            return Integer.toHexString(sb.toString().hashCode());
        }

        static String safe(CharSequence c) { return c == null ? "" : c.toString().trim(); }
        static boolean containsAny(String s, String... parts) {
            for (String p : parts) if (s.contains(p)) return true;
            return false;
        }
    }

    private static class Node {
        final String text, desc;
        final boolean clickable, selected, checked;
        final Rect bounds;
        Node(String text, String desc, boolean clickable, boolean selected, boolean checked, Rect bounds) {
            this.text = text; this.desc = desc; this.clickable = clickable; this.selected = selected; this.checked = checked; this.bounds = new Rect(bounds);
        }
    }
}
