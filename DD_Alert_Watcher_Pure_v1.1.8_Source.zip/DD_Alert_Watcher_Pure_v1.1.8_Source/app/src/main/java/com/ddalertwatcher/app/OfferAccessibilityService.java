package com.ddalertwatcher.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * v1.1.11 Stable117Rebase
 *
 * Scanner core intentionally follows the field-proven v1.1.7 behavior:
 * fixed D1-D7 row coordinates, one date at a time, bounded settle, any-offer freeze,
 * and self-event suppression. Schedule/watchdog/overlay controls are wrappers around
 * the scanner; they do not participate in date selection or offer classification.
 */
public class OfferAccessibilityService extends AccessibilityService {
    private static volatile OfferAccessibilityService INSTANCE;

    private static final String DASHER_PACKAGE = "com.doordash.driverapp";
    private static final String PREFS = MainActivity.PREFS;
    private static final String CHANNEL_OFFER = "offer_alert";
    private static final String CHANNEL_ERROR = "monitor_error";

    // Stable v1.1.7-ish scan timing: one full D1-D7 round is roughly 8-12 seconds.
    private static final long SELF_EVENT_GRACE_MS = 900L;
    private static final long USER_YIELD_MS = 3500L;
    private static final long DATE_FIRST_READ_MS = 650L;
    private static final long DATE_RECHECK_MS = 300L;
    private static final long DATE_SETTLE_MAX_MS = 2100L;
    private static final long ROUND_PAUSE_MS = 700L;

    private static final long CONTROL_TICK_MS = 1000L;
    private static final long WATCHDOG_STALL_MS = 18_000L;

    private enum State {
        RUNNING,
        USER_PAUSED,
        SCHEDULE_WAIT,
        OFFER_FROZEN,
        ERROR_PAUSED,
        STOPPED
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private State state = State.STOPPED;

    // Scanner state. Keep this small and independent from schedule/overlay logic.
    private int dateCursor = 0;
    private int scannedThisRound = 0;
    private boolean waitingDateSettle = false;
    private int settlingDate = -1;
    private long settleDeadline = 0L;
    private long selfEventUntil = 0L;
    private int selfDate = -1;
    private long userYieldUntil = 0L;
    private boolean scanQueued = false;
    private long lastProgressAt = 0L;

    // Foreground/page state is observational only; it never creates a fake user click.
    private boolean dasherForeground = false;
    private boolean onOffersPage = false;
    private boolean startNoticeSent = false;

    // Offer de-dupe.
    private String lastOfferFingerprint = "";
    private long lastOfferAt = 0L;

    // Overlay.
    private WindowManager wm;
    private View overlay;
    private TextView overlayStatus;
    private WindowManager.LayoutParams overlayLp;

    private final Runnable scanRunnable = new Runnable() {
        @Override public void run() {
            scanQueued = false;
            scanTick();
        }
    };

    private final Runnable controlRunnable = new Runnable() {
        @Override public void run() {
            try {
                processExternalCommand();
                applyScheduleGate();
                refreshForegroundObservation();
                maintainOverlay();
                checkWatchdog();
            } catch (Throwable t) {
                log("CONTROL_ERROR " + t.getClass().getSimpleName());
                increment("stat_error");
            } finally {
                handler.postDelayed(this, CONTROL_TICK_MS);
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannels();

        boolean stopped = prefs.getBoolean("user_stopped", false);
        boolean paused = prefs.getBoolean("user_paused", false);
        if (stopped) state = State.STOPPED;
        else if (paused) state = State.USER_PAUSED;
        else if (!isScheduleAllowedNow()) state = State.SCHEDULE_WAIT;
        else state = State.RUNNING;

        resetScannerTransient();
        resetWatchdogClock();
        setServiceStateText();
        log("SERVICE_CONNECTED Stable117Rebase v1.1.11 state=" + state.name());

        if (state != State.STOPPED) ensureOverlay();
        handler.removeCallbacks(controlRunnable);
        handler.post(controlRunnable);
        if (state == State.RUNNING) queueScan(250L);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence pkg = event.getPackageName();
        boolean fromDasher = pkg != null && DASHER_PACKAGE.contentEquals(pkg);
        if (!fromDasher) return;

        dasherForeground = true;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        Snapshot snap = Snapshot.from(root, getResources().getDisplayMetrics().heightPixels);
        onOffersPage = snap.looksLikeOffersPage();

        if (snap.errorLayer) {
            enterErrorPause("DOORDASH_ERROR event");
            return;
        }

        // Real-user yield is deliberately narrow. v1.1.10 failed because content/selected
        // events and broad Y-bands were treated as human date taps. Here ONLY a real
        // TYPE_VIEW_CLICKED event in the exact date row can yield, and every event during
        // our own post-click grace window is ignored regardless of which D-index it resembles.
        maybeYieldForRealUserDateTap(event);

        if (state == State.RUNNING && onOffersPage) {
            if (detectOfferAndFreeze(snap)) return;
            queueScan(50L); // event wake-up only; queue coalescing prevents busy loops
        }
        updateOverlay();
    }

    @Override
    public void onInterrupt() {
        log("SERVICE_INTERRUPTED");
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Swiping the app away from Recents is treated as an explicit exit.
        log("APP_TASK_REMOVED");
        stopByUser();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        cancelScan();
        handler.removeCallbacks(controlRunnable);
        removeOverlay();
        if (prefs != null) prefs.edit().putString("service_state", "服务已停止").apply();
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }

    // -------------------------------------------------------------------------
    // Stable scanner core
    // -------------------------------------------------------------------------

    private void scanTick() {
        if (state != State.RUNNING) return;
        if (!isScheduleAllowedNow()) {
            applyScheduleGate();
            return;
        }

        long now = System.currentTimeMillis();
        if (now < userYieldUntil) {
            queueScan(Math.min(600L, userYieldUntil - now + 30L));
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        CharSequence rootPkg = root == null ? null : root.getPackageName();
        if (rootPkg == null || !DASHER_PACKAGE.contentEquals(rootPkg)) {
            dasherForeground = false;
            onOffersPage = false;
            updateOverlay();
            queueScan(700L);
            return;
        }

        dasherForeground = true;
        Snapshot snap = Snapshot.from(root, getResources().getDisplayMetrics().heightPixels);
        onOffersPage = snap.looksLikeOffersPage();
        if (!onOffersPage) {
            updateOverlay();
            queueScan(700L);
            return;
        }

        if (snap.errorLayer) {
            enterErrorPause("DOORDASH_ERROR scan");
            return;
        }
        if (detectOfferAndFreeze(snap)) return;

        if (waitingDateSettle) {
            if (snap.emptyPage) {
                log("DATE_EMPTY_FAST_SETTLED expected=D" + (settlingDate + 1));
                finishCurrentDate();
                return;
            }
            // A card with visible pay is handled above as an Offer. If page is neither
            // empty nor an offer, wait only until the bounded v1.1.7-style settle deadline.
            if (now >= settleDeadline) {
                log("DATE_SETTLE_NO_SIGNAL expected=D" + (settlingDate + 1));
                finishCurrentDate();
                return;
            }
            queueScan(DATE_RECHECK_MS);
            return;
        }

        int next = nextEnabledDate(dateCursor);
        if (next < 0) {
            state = State.USER_PAUSED;
            prefs.edit().putBoolean("user_paused", true).apply();
            cancelScan();
            log("NO_SCAN_DAYS_ENABLED");
            alertError("未选择扫描日期", "请至少选择一个 D1–D7 日期。", false);
            setServiceStateText();
            updateOverlay();
            return;
        }
        dateCursor = next;
        tapDateStable117(next);
    }

    private void tapDateStable117(final int index) {
        // Keep the exact field-proven Samsung coordinates from v1.1.7.
        final float x = 101f + 135f * index;
        final float y = 349f;

        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0L, 60L);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();

        selfDate = index;
        selfEventUntil = System.currentTimeMillis() + SELF_EVENT_GRACE_MS;
        waitingDateSettle = true;
        settlingDate = index;
        settleDeadline = System.currentTimeMillis() + DATE_SETTLE_MAX_MS;
        log("DATE_BUTTON_ROW_TAP D" + (index + 1) + " x=" + Math.round(x) + " y=" + Math.round(y));

        boolean submitted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                markProgress();
                queueScan(DATE_FIRST_READ_MS);
            }

            @Override public void onCancelled(GestureDescription gestureDescription) {
                waitingDateSettle = false;
                settlingDate = -1;
                log("DATE_CLICK_FAIL D" + (index + 1));
                increment("stat_error");
                queueScan(500L);
            }
        }, null);

        if (!submitted) {
            waitingDateSettle = false;
            settlingDate = -1;
            log("DATE_CLICK_FAIL D" + (index + 1) + " dispatch=false");
            increment("stat_error");
            queueScan(500L);
        }
        updateOverlay();
    }

    private void finishCurrentDate() {
        markProgress();
        waitingDateSettle = false;
        settlingDate = -1;
        settleDeadline = 0L;
        scannedThisRound++;
        dateCursor = (dateCursor + 1) % 7;

        int enabled = enabledDateCount();
        if (scannedThisRound >= enabled) {
            scannedThisRound = 0;
            log("ROUND_PAUSE ms=" + ROUND_PAUSE_MS);
            queueScan(ROUND_PAUSE_MS);
        } else {
            queueScan(20L);
        }
        updateOverlay();
    }

    private void maybeYieldForRealUserDateTap(AccessibilityEvent event) {
        if (state != State.RUNNING) return;
        if (event.getEventType() != AccessibilityEvent.TYPE_VIEW_CLICKED) return;

        long now = System.currentTimeMillis();
        if (now <= selfEventUntil) return; // critical v1.1.7 self-event behavior

        AccessibilityNodeInfo src = event.getSource();
        int idx = strictDateIndex(src);
        if (idx < 0) return;

        userYieldUntil = now + USER_YIELD_MS;
        waitingDateSettle = false;
        settlingDate = -1;
        settleDeadline = 0L;
        selfDate = -1;
        cancelScan();
        log("MANUAL_DATE_OVERRIDE D" + (idx + 1));
        log("USER_INTERACTION_HOLD yield=" + USER_YIELD_MS + "ms");
        queueScan(USER_YIELD_MS + 50L);
        updateOverlay();
    }

    private int strictDateIndex(AccessibilityNodeInfo node) {
        if (node == null) return -1;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.isEmpty()) return -1;

        // Exact row around y=349 on the user's Samsung. Avoid the broad 20-43% band that
        // caused v1.1.10 to misclassify ordinary content events as D5/date taps.
        int cy = r.centerY();
        if (cy < 285 || cy > 425) return -1;
        if (r.height() > 180 || r.width() > 190) return -1;

        float nearest = (r.centerX() - 101f) / 135f;
        int idx = Math.round(nearest);
        if (idx < 0 || idx > 6) return -1;
        float center = 101f + 135f * idx;
        if (Math.abs(r.centerX() - center) > 55f) return -1;
        return idx;
    }

    private int nextEnabledDate(int start) {
        for (int i = 0; i < 7; i++) {
            int idx = (start + i) % 7;
            if (prefs.getBoolean("scan_d" + (idx + 1), true)) return idx;
        }
        return -1;
    }

    private int enabledDateCount() {
        int count = 0;
        for (int i = 0; i < 7; i++) {
            if (prefs.getBoolean("scan_d" + (i + 1), true)) count++;
        }
        return count;
    }

    private void queueScan(long delayMs) {
        if (state != State.RUNNING) return;
        if (scanQueued) return;
        scanQueued = true;
        handler.postDelayed(scanRunnable, Math.max(0L, delayMs));
    }

    private void cancelScan() {
        handler.removeCallbacks(scanRunnable);
        scanQueued = false;
    }

    private void resetScannerTransient() {
        cancelScan();
        waitingDateSettle = false;
        settlingDate = -1;
        settleDeadline = 0L;
        selfEventUntil = 0L;
        selfDate = -1;
        userYieldUntil = 0L;
        scannedThisRound = 0;
    }

    private void markProgress() {
        lastProgressAt = System.currentTimeMillis();
    }

    private void resetWatchdogClock() {
        lastProgressAt = System.currentTimeMillis();
    }

    private void softRestartScanner() {
        resetScannerTransient();
        resetWatchdogClock();
        if (state == State.RUNNING) queueScan(250L);
    }

    // -------------------------------------------------------------------------
    // Any-offer detection: visible pay/claim only; no structural heuristic.
    // -------------------------------------------------------------------------

    private boolean detectOfferAndFreeze(Snapshot snap) {
        if (state != State.RUNNING) return false;
        if (!snap.looksLikeOffersPage() || snap.emptyPage || snap.loadingLike || snap.errorLayer) return false;
        if (!snap.offerCandidate) return false;

        String fp = snap.offerFingerprint();
        long now = System.currentTimeMillis();
        if (fp.equals(lastOfferFingerprint) && now - lastOfferAt < 60_000L) {
            // Keep frozen if it is the same already-confirmed offer.
            state = State.OFFER_FROZEN;
            cancelScan();
            updateOverlay();
            return true;
        }

        lastOfferFingerprint = fp;
        lastOfferAt = now;
        state = State.OFFER_FROZEN;
        cancelScan();
        increment("stat_offer");
        log("OFFER_CANDIDATE date=D" + (dateCursor + 1) + " evidence=" + snap.offerEvidence);
        log("OFFER_CONFIRMED");
        log("ALERT_SENT");
        log("AUTO_SCAN_FROZEN reason=offer");
        sendOfferAlert("发现 Offer！", "请立即查看 Dasher。扫描已冻结；处理后手动点继续。", true);
        setServiceStateText();
        updateOverlay();
        return true;
    }

    // -------------------------------------------------------------------------
    // Schedule wrapper. It gates the scanner; it never mutates date/offer logic.
    // -------------------------------------------------------------------------

    private void applyScheduleGate() {
        if (prefs == null) return;
        if (state == State.STOPPED || state == State.USER_PAUSED ||
                state == State.OFFER_FROZEN || state == State.ERROR_PAUSED) return;

        boolean allowed = isScheduleAllowedNow();
        if (!allowed) {
            if (state != State.SCHEDULE_WAIT) {
                state = State.SCHEDULE_WAIT;
                cancelScan();
                resetScannerTransient();
                log("SCHEDULE_WAIT");
                setServiceStateText();
                updateOverlay();
            }
            return;
        }

        if (state == State.SCHEDULE_WAIT) {
            refreshForegroundObservation();
            if (dasherForeground && onOffersPage) {
                state = State.RUNNING;
                startNoticeSent = false;
                resetScannerTransient();
                resetWatchdogClock();
                log("SCHEDULE_START");
                setServiceStateText();
                ensureOverlay();
                queueScan(150L);
            } else if (!startNoticeSent) {
                startNoticeSent = true;
                notifyInfo("DD Alert Watcher 运行时间已到", "请打开 Dasher → Schedule → Offers；不会自动打开 DoorDash。", 3101);
            }
        }
    }

    private boolean isScheduleAllowedNow() {
        if (prefs == null) return true;

        // Temporary run overrides the regular schedule only while active.
        long tempUntil = prefs.getLong("temp_until", 0L);
        if (tempUntil > System.currentTimeMillis()) return true;
        if (tempUntil > 0L && tempUntil <= System.currentTimeMillis()) {
            prefs.edit().remove("temp_until").apply();
            // If there is no regular schedule, temporary mode ends in STOP rather than
            // silently becoming 24/7 monitoring.
            if (!prefs.getBoolean("schedule_enabled", false)) {
                prefs.edit().putBoolean("user_stopped", true).apply();
                state = State.STOPPED;
                cancelScan();
                removeOverlay();
                log("TEMP_RUN_END");
                setServiceStateText();
                return false;
            }
        }

        if (!prefs.getBoolean("schedule_enabled", false)) return true;

        int start = parseMinutes(prefs.getString("schedule_start", "10:30"));
        int end = parseMinutes(prefs.getString("schedule_end", "21:30"));
        Calendar c = Calendar.getInstance();
        int nowMin = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);

        if (start == end) return isScheduleDayEnabled(toMonZero(c.get(Calendar.DAY_OF_WEEK)));

        if (start < end) {
            return nowMin >= start && nowMin < end &&
                    isScheduleDayEnabled(toMonZero(c.get(Calendar.DAY_OF_WEEK)));
        }

        // Cross-midnight: early-morning portion belongs to the previous start day.
        if (nowMin >= start) {
            return isScheduleDayEnabled(toMonZero(c.get(Calendar.DAY_OF_WEEK)));
        }
        if (nowMin < end) {
            Calendar prev = (Calendar) c.clone();
            prev.add(Calendar.DAY_OF_YEAR, -1);
            return isScheduleDayEnabled(toMonZero(prev.get(Calendar.DAY_OF_WEEK)));
        }
        return false;
    }

    private int parseMinutes(String value) {
        try {
            String[] p = value.split(":");
            return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private int toMonZero(int calendarDay) {
        // Calendar: Sun=1 ... Sat=7 -> Mon=0 ... Sun=6
        return (calendarDay + 5) % 7;
    }

    private boolean isScheduleDayEnabled(int monZero) {
        return prefs.getBoolean("schedule_day_" + monZero, true);
    }

    // -------------------------------------------------------------------------
    // Foreground observation + watchdog
    // -------------------------------------------------------------------------

    private void refreshForegroundObservation() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            CharSequence pkg = root == null ? null : root.getPackageName();
            if (pkg != null && DASHER_PACKAGE.contentEquals(pkg)) {
                dasherForeground = true;
                Snapshot s = Snapshot.from(root, getResources().getDisplayMetrics().heightPixels);
                onOffersPage = s.looksLikeOffersPage();
            } else {
                dasherForeground = false;
                onOffersPage = false;
            }
        } catch (Throwable t) {
            dasherForeground = false;
            onOffersPage = false;
        }
    }

    private void checkWatchdog() {
        if (state != State.RUNNING) return;
        if (!isScheduleAllowedNow()) return;
        if (!dasherForeground || !onOffersPage) return;
        long idle = System.currentTimeMillis() - lastProgressAt;
        if (lastProgressAt > 0L && idle >= WATCHDOG_STALL_MS) {
            log("WATCHDOG_STALL idleMs=" + idle);
            increment("stat_stall");
            alertError("监控停滞", "18秒没有扫描进展，已重启扫描循环。", true);
            softRestartScanner();
        }
    }

    private void enterErrorPause(String reason) {
        if (state == State.ERROR_PAUSED) return;
        state = State.ERROR_PAUSED;
        cancelScan();
        resetScannerTransient();
        log(reason);
        increment("stat_error");
        alertError("DoorDash 页面异常", "检测到 Something went wrong / Retry。请人工处理后点继续。", true);
        setServiceStateText();
        ensureOverlay();
        updateOverlay();
    }

    // -------------------------------------------------------------------------
    // Overlay controls
    // -------------------------------------------------------------------------

    private void ensureOverlay() {
        if (state == State.STOPPED || overlay != null || wm == null) return;
        try {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(10, 8, 10, 8);
            box.setBackgroundColor(Color.argb(220, 25, 25, 25));

            overlayStatus = new TextView(this);
            overlayStatus.setTextColor(Color.WHITE);
            overlayStatus.setTextSize(14f);
            overlayStatus.setPadding(8, 5, 8, 7);
            box.addView(overlayStatus);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            Button resume = overlayButton("继续", v -> resumeByUser());
            Button pause = overlayButton("暂停", v -> pauseByUser());
            Button stop = overlayButton("停止", v -> stopByUser());
            row.addView(resume, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(pause, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(stop, new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f));
            box.addView(row);

            overlayLp = new WindowManager.LayoutParams(
                    520,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            overlayLp.gravity = Gravity.TOP | Gravity.START;
            overlayLp.x = prefs.getInt("overlay_x", 520);
            overlayLp.y = prefs.getInt("overlay_y", 650);
            if (prefs.getBoolean("keep_awake", true)) {
                overlayLp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            }

            // IMPORTANT: drag listener is on the header only, never on the button container.
            overlayStatus.setOnTouchListener(new View.OnTouchListener() {
                float downX, downY;
                int startX, startY;
                boolean moved;

                @Override public boolean onTouch(View v, MotionEvent e) {
                    if (overlayLp == null || wm == null || overlay == null) return false;
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downX = e.getRawX();
                            downY = e.getRawY();
                            startX = overlayLp.x;
                            startY = overlayLp.y;
                            moved = false;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            int dx = Math.round(e.getRawX() - downX);
                            int dy = Math.round(e.getRawY() - downY);
                            if (Math.abs(dx) + Math.abs(dy) > 8) moved = true;
                            overlayLp.x = Math.max(0, startX + dx);
                            overlayLp.y = Math.max(0, startY + dy);
                            try { wm.updateViewLayout(overlay, overlayLp); } catch (Throwable ignored) {}
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            if (moved) prefs.edit().putInt("overlay_x", overlayLp.x).putInt("overlay_y", overlayLp.y).apply();
                            return true;
                    }
                    return false;
                }
            });

            wm.addView(box, overlayLp);
            overlay = box;
            log("OVERLAY_CREATED");
            updateOverlay();
        } catch (Throwable t) {
            overlay = null;
            overlayStatus = null;
            log("OVERLAY_CREATE_FAIL " + t.getClass().getSimpleName());
            increment("stat_error");
        }
    }

    private Button overlayButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12f);
        b.setOnClickListener(listener);
        return b;
    }

    private void maintainOverlay() {
        if (state == State.STOPPED) {
            removeOverlay();
            return;
        }
        if (overlay == null) ensureOverlay();
        else updateOverlay();
    }

    private void removeOverlay() {
        if (wm != null && overlay != null) {
            try { wm.removeViewImmediate(overlay); } catch (Throwable ignored) {
                try { wm.removeView(overlay); } catch (Throwable ignored2) {}
            }
        }
        overlay = null;
        overlayStatus = null;
        overlayLp = null;
    }

    private void updateOverlay() {
        if (overlayStatus == null) return;
        String label;
        switch (state) {
            case RUNNING: label = "运行中"; break;
            case USER_PAUSED: label = "人工暂停"; break;
            case SCHEDULE_WAIT: label = "定时等待"; break;
            case OFFER_FROZEN: label = "Offer已发现"; break;
            case ERROR_PAUSED: label = "异常暂停"; break;
            default: label = "已停止"; break;
        }
        long age = Math.max(0L, (System.currentTimeMillis() - lastProgressAt) / 1000L);
        String page = onOffersPage ? "Offers✓" : (dasherForeground ? "Dasher" : "等待Dasher");
        overlayStatus.setText("DD Alert " + label + " | D" + (dateCursor + 1) + " | " + page + "\n最后进展 " + age + "s");
    }

    // -------------------------------------------------------------------------
    // User commands / persistence
    // -------------------------------------------------------------------------

    private void processExternalCommand() {
        if (prefs == null) return;
        String cmd = prefs.getString("command", "");
        if (cmd == null || cmd.isEmpty()) return;
        prefs.edit().remove("command").apply();
        if ("pause".equals(cmd)) pauseByUser();
        else if ("resume".equals(cmd)) resumeByUser();
        else if ("stop".equals(cmd)) stopByUser();
        else if ("reload".equals(cmd)) {
            if (overlayLp != null && overlay != null) {
                if (prefs.getBoolean("keep_awake", true)) overlayLp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                else overlayLp.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                try { wm.updateViewLayout(overlay, overlayLp); } catch (Throwable ignored) {}
            }
            applyScheduleGate();
            updateOverlay();
        }
    }

    private void pauseByUser() {
        if (state == State.STOPPED) return;
        state = State.USER_PAUSED;
        prefs.edit().putBoolean("user_paused", true).putBoolean("user_stopped", false).apply();
        cancelScan();
        resetScannerTransient();
        log("USER_PAUSE");
        setServiceStateText();
        ensureOverlay();
        updateOverlay();
    }

    private void resumeByUser() {
        prefs.edit().putBoolean("user_paused", false).putBoolean("user_stopped", false).apply();
        startNoticeSent = false;
        resetScannerTransient();
        resetWatchdogClock();

        if (!isScheduleAllowedNow()) {
            state = State.SCHEDULE_WAIT;
            log("USER_RESUME schedule-wait");
            setServiceStateText();
            ensureOverlay();
            updateOverlay();
            return;
        }

        state = State.RUNNING;
        log("USER_RESUME");
        setServiceStateText();
        ensureOverlay();
        updateOverlay();
        queueScan(120L);
    }

    private void stopByUser() {
        if (state != State.STOPPED) log("USER_STOP overlay");
        state = State.STOPPED;
        prefs.edit().putBoolean("user_stopped", true).putBoolean("user_paused", false).remove("temp_until").apply();
        cancelScan();
        resetScannerTransient();
        setServiceStateText();
        removeOverlay();
    }

    private void setServiceStateText() {
        if (prefs == null) return;
        String s;
        switch (state) {
            case RUNNING: s = "运行中 · Stable117Rebase v1.1.11"; break;
            case USER_PAUSED: s = "人工暂停 · Stable117Rebase v1.1.11"; break;
            case SCHEDULE_WAIT: s = "定时等待 · Stable117Rebase v1.1.11"; break;
            case OFFER_FROZEN: s = "Offer已发现 · Stable117Rebase v1.1.11"; break;
            case ERROR_PAUSED: s = "异常暂停 · Stable117Rebase v1.1.11"; break;
            default: s = "已停止 · Stable117Rebase v1.1.11"; break;
        }
        prefs.edit().putString("service_state", s).apply();
    }

    public static boolean isServiceConnected() {
        return INSTANCE != null;
    }

    public static void requestPause(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) s.pauseByUser();
        else c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "pause").apply();
    }

    public static void requestResume(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) s.resumeByUser();
        else c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("user_stopped", false)
                .putBoolean("user_paused", false)
                .putString("command", "resume").apply();
    }

    public static void requestStop(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) s.stopByUser();
        else c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("user_stopped", true)
                .putBoolean("user_paused", false)
                .putString("command", "stop")
                .putString("service_state", "已停止 · Stable117Rebase v1.1.11").apply();
    }

    public static void requestReload(Context c) {
        OfferAccessibilityService s = INSTANCE;
        if (s != null) {
            s.processExternalCommand();
            s.applyScheduleGate();
            s.updateOverlay();
        } else {
            c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("command", "reload").apply();
        }
    }

    public static void requestTestAlert(Context c) {
        createChannelsStatic(c);
        Vibrator v = (Vibrator) c.getSystemService(VIBRATOR_SERVICE);
        if (v != null) {
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 300, 150, 500}, -1));
            else v.vibrate(new long[]{0, 300, 150, 500}, -1);
        }
        try {
            Ringtone r = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            if (r != null) r.play();
        } catch (Throwable ignored) {}
        notifyStatic(c, CHANNEL_OFFER, "测试：发现 Offer！", "提醒链正常。真实 Offer 会冻结扫描等待人工处理。", 2099);
    }

    // -------------------------------------------------------------------------
    // Notifications / logs
    // -------------------------------------------------------------------------

    private void createChannels() {
        createChannelsStatic(this);
    }

    private static void createChannelsStatic(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel offer = new NotificationChannel(CHANNEL_OFFER, "Offer Alerts", NotificationManager.IMPORTANCE_HIGH);
        offer.enableVibration(true);
        NotificationChannel error = new NotificationChannel(CHANNEL_ERROR, "Monitor Errors", NotificationManager.IMPORTANCE_HIGH);
        error.enableVibration(true);
        nm.createNotificationChannel(offer);
        nm.createNotificationChannel(error);
    }

    private void sendOfferAlert(String title, String body, boolean forceOverlay) {
        if (prefs.getBoolean("vibrate", true)) vibrate();
        if (prefs.getBoolean("sound", true)) playSound();
        notifyStatic(this, CHANNEL_OFFER, title, body, 2001);
        if (forceOverlay) ensureOverlay();
    }

    private void alertError(String title, String body, boolean vibrate) {
        if (vibrate) vibrate();
        notifyStatic(this, CHANNEL_ERROR, "DD Alert Watcher：" + title, body, 2002);
    }

    private void notifyInfo(String title, String body, int id) {
        notifyStatic(this, CHANNEL_ERROR, title, body, id);
    }

    private static void notifyStatic(Context c, String channel, String title, String body, int id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        Intent intent = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(c, channel)
                : new android.app.Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true);
        nm.notify(id, b.build());
    }

    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 350, 160, 350, 160, 650}, -1));
            else v.vibrate(new long[]{0, 350, 160, 350, 160, 650}, -1);
        } catch (Throwable ignored) {}
    }

    private void playSound() {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) {}
    }

    private void increment(String key) {
        if (prefs != null) prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply();
    }

    private void log(String msg) {
        if (prefs == null) return;
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = ts + " " + msg;
        String old = prefs.getString("logs", "");
        String all = line + (old.isEmpty() ? "" : "\n" + old);
        String[] lines = all.split("\n");
        StringBuilder sb = new StringBuilder();
        int max = Math.min(lines.length, 240);
        for (int i = 0; i < max; i++) {
            if (i > 0) sb.append('\n');
            sb.append(lines[i]);
        }
        prefs.edit().putString("logs", sb.toString()).apply();
    }

    // -------------------------------------------------------------------------
    // Snapshot. Any-offer = visible money/claim in the Offer content area.
    // -------------------------------------------------------------------------

    private static class Snapshot {
        private static final Pattern MONEY = Pattern.compile("\\$\\s*\\d+(?:\\.\\d{1,2})?");
        final List<Node> nodes = new ArrayList<>();
        final List<String> texts = new ArrayList<>();
        boolean emptyPage;
        boolean loadingLike;
        boolean errorLayer;
        boolean offerCandidate;
        String offerEvidence = "none";
        int screenHeight;

        static Snapshot from(AccessibilityNodeInfo root, int screenHeight) {
            Snapshot s = new Snapshot();
            s.screenHeight = screenHeight;
            if (root == null) return s;
            ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
            q.add(root);
            int guard = 0;
            while (!q.isEmpty() && guard++ < 1200) {
                AccessibilityNodeInfo n = q.removeFirst();
                String t = safe(n.getText());
                String d = safe(n.getContentDescription());
                Rect r = new Rect();
                n.getBoundsInScreen(r);
                boolean visible;
                try { visible = n.isVisibleToUser(); } catch (Throwable e) { visible = true; }
                if (!t.isEmpty()) s.texts.add(t);
                if (!d.isEmpty() && !d.equals(t)) s.texts.add(d);
                s.nodes.add(new Node(t, d, visible, r));
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) q.addLast(c);
                }
            }
            s.classify();
            return s;
        }

        void classify() {
            String all = String.join(" ", texts).toLowerCase(Locale.US);
            emptyPage = containsAny(all,
                    "nothing available to schedule",
                    "there's nothing available",
                    "there is nothing available",
                    "no offers available");
            loadingLike = containsAny(all, "loading", "please wait", "refreshing offers");
            errorLayer = (containsAny(all, "something went wrong", "unexpected error") && all.contains("retry"));
            if (emptyPage || loadingLike || errorLayer) return;
            if (!looksLikeOffersPage()) return;

            boolean visibleMoney = false;
            boolean visibleClaim = false;
            for (Node n : nodes) {
                if (!n.visible || n.bounds.isEmpty()) continue;
                int cy = n.bounds.centerY();
                // Date row is at ~349. Only count actual content below it; ignore bottom nav.
                if (cy < 390 || cy > Math.max(500, screenHeight - 180)) continue;
                String s = (n.text + " " + n.desc).toLowerCase(Locale.US);
                if (MONEY.matcher(s).find()) visibleMoney = true;
                if (containsAny(s, "claim and schedule", "claim", "acknowledge")) visibleClaim = true;
            }
            if (visibleMoney) {
                offerCandidate = true;
                offerEvidence = "visible-money";
            } else if (visibleClaim) {
                offerCandidate = true;
                offerEvidence = "visible-claim";
            }
        }

        boolean looksLikeOffersPage() {
            String all = String.join(" ", texts).toLowerCase(Locale.US);
            if (!all.contains("offers")) return false;
            // DoorDash variants differ on whether "Schedule" remains in the tree.
            // The Offers label plus the seven-date-row geometry is enough here.
            int dateLike = 0;
            for (Node n : nodes) {
                if (!n.visible || n.bounds.isEmpty()) continue;
                int cy = n.bounds.centerY();
                if (cy >= 285 && cy <= 425 && n.bounds.width() <= 220) dateLike++;
            }
            return all.contains("schedule") || all.contains("my schedule") || dateLike >= 5;
        }

        String offerFingerprint() {
            StringBuilder b = new StringBuilder();
            int count = 0;
            for (Node n : nodes) {
                if (!n.visible || n.bounds.isEmpty()) continue;
                int cy = n.bounds.centerY();
                if (cy < 390 || cy > Math.max(500, screenHeight - 180)) continue;
                String s = (n.text + " " + n.desc).trim();
                if (s.isEmpty()) continue;
                b.append(s).append('|');
                if (++count >= 18) break;
            }
            return Integer.toHexString(b.toString().hashCode());
        }

        private static String safe(CharSequence c) {
            return c == null ? "" : c.toString().trim();
        }

        private static boolean containsAny(String s, String... parts) {
            for (String p : parts) if (s.contains(p)) return true;
            return false;
        }
    }

    private static class Node {
        final String text;
        final String desc;
        final boolean visible;
        final Rect bounds;

        Node(String text, String desc, boolean visible, Rect bounds) {
            this.text = text;
            this.desc = desc;
            this.visible = visible;
            this.bounds = new Rect(bounds);
        }
    }
}
